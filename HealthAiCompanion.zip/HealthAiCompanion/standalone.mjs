var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";
import multer from "multer";

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  appointmentSlots: () => appointmentSlots,
  appointments: () => appointments,
  appointmentsRelations: () => appointmentsRelations,
  conversations: () => conversations,
  conversationsRelations: () => conversationsRelations,
  forgotPasswordSchema: () => forgotPasswordSchema,
  healthRecords: () => healthRecords,
  healthRecordsRelations: () => healthRecordsRelations,
  insertAppointmentSchema: () => insertAppointmentSchema,
  insertAppointmentSlotSchema: () => insertAppointmentSlotSchema,
  insertConversationSchema: () => insertConversationSchema,
  insertHealthRecordSchema: () => insertHealthRecordSchema,
  insertMedicationReminderSchema: () => insertMedicationReminderSchema,
  insertMedicationSchema: () => insertMedicationSchema,
  insertMessageSchema: () => insertMessageSchema,
  insertUserSchema: () => insertUserSchema,
  loginSchema: () => loginSchema,
  medicationReminders: () => medicationReminders,
  medicationRemindersRelations: () => medicationRemindersRelations,
  medications: () => medications,
  medicationsRelations: () => medicationsRelations,
  messages: () => messages,
  messagesRelations: () => messagesRelations,
  registerSchema: () => registerSchema,
  resetPasswordSchema: () => resetPasswordSchema,
  sessions: () => sessions,
  users: () => users,
  usersRelations: () => usersRelations,
  verifyEmailSchema: () => verifyEmailSchema
});
import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";
var sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull()
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);
var users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id),
  role: varchar("role").notNull(),
  // 'user' or 'assistant'
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow()
});
var healthRecords = pgTable("health_records", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  fileName: varchar("file_name").notNull(),
  originalName: varchar("original_name").notNull(),
  fileType: varchar("file_type").notNull(),
  fileSize: integer("file_size").notNull(),
  filePath: varchar("file_path").notNull(),
  description: text("description"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  isVerified: boolean("is_verified").default(false)
});
var medications = pgTable("medications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  name: varchar("name").notNull(),
  dosage: varchar("dosage").notNull(),
  frequency: varchar("frequency").notNull(),
  timeOfDay: varchar("time_of_day").array(),
  // Array of times like ['08:00', '20:00']
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow()
});
var medicationReminders = pgTable("medication_reminders", {
  id: serial("id").primaryKey(),
  medicationId: integer("medication_id").notNull().references(() => medications.id),
  scheduledTime: timestamp("scheduled_time").notNull(),
  takenAt: timestamp("taken_at"),
  isTaken: boolean("is_taken").default(false),
  isMissed: boolean("is_missed").default(false),
  createdAt: timestamp("created_at").defaultNow()
});
var appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  appointmentDate: timestamp("appointment_date").notNull(),
  duration: integer("duration").default(30),
  // duration in minutes
  location: varchar("location", { length: 255 }),
  doctorName: varchar("doctor_name", { length: 100 }),
  doctorSpecialty: varchar("doctor_specialty", { length: 100 }),
  status: varchar("status", { length: 20 }).default("scheduled"),
  // scheduled, cancelled, completed, rescheduled
  reminderSent: boolean("reminder_sent").default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var appointmentSlots = pgTable("appointment_slots", {
  id: serial("id").primaryKey(),
  doctorName: varchar("doctor_name", { length: 100 }).notNull(),
  doctorSpecialty: varchar("doctor_specialty", { length: 100 }).notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  slotDate: timestamp("slot_date").notNull(),
  duration: integer("duration").default(30),
  // duration in minutes
  isAvailable: boolean("is_available").default(true),
  createdAt: timestamp("created_at").defaultNow()
});
var usersRelations = relations(users, ({ many }) => ({
  conversations: many(conversations),
  healthRecords: many(healthRecords),
  medications: many(medications),
  appointments: many(appointments)
}));
var conversationsRelations = relations(conversations, ({ one, many }) => ({
  user: one(users, {
    fields: [conversations.userId],
    references: [users.id]
  }),
  messages: many(messages)
}));
var messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id]
  })
}));
var healthRecordsRelations = relations(healthRecords, ({ one }) => ({
  user: one(users, {
    fields: [healthRecords.userId],
    references: [users.id]
  })
}));
var medicationsRelations = relations(medications, ({ one, many }) => ({
  user: one(users, {
    fields: [medications.userId],
    references: [users.id]
  }),
  reminders: many(medicationReminders)
}));
var medicationRemindersRelations = relations(medicationReminders, ({ one }) => ({
  medication: one(medications, {
    fields: [medicationReminders.medicationId],
    references: [medications.id]
  })
}));
var appointmentsRelations = relations(appointments, ({ one }) => ({
  user: one(users, {
    fields: [appointments.userId],
    references: [users.id]
  })
}));
var insertUserSchema = createInsertSchema(users);
var insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  timestamp: true
});
var insertHealthRecordSchema = createInsertSchema(healthRecords).omit({
  id: true,
  uploadedAt: true,
  isVerified: true
});
var insertMedicationSchema = createInsertSchema(medications).omit({
  id: true,
  createdAt: true,
  isActive: true
}).extend({
  startDate: z.coerce.date(),
  endDate: z.coerce.date().optional()
});
var insertMedicationReminderSchema = createInsertSchema(medicationReminders).omit({
  id: true,
  createdAt: true,
  isTaken: true,
  isMissed: true
});
var insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  reminderSent: true
}).extend({
  appointmentDate: z.coerce.date()
});
var insertAppointmentSlotSchema = createInsertSchema(appointmentSlots).omit({
  id: true,
  createdAt: true
});
var registerSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required")
});
var loginSchema = z.object({
  email: z.string().email("Please enter a valid email address")
});
var verifyEmailSchema = z.object({
  token: z.string().min(1, "Verification token is required")
});
var forgotPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address")
});
var resetPasswordSchema = z.object({
  token: z.string().min(1, "Reset token is required")
});

// server/db.ts
import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
neonConfig.webSocketConstructor = ws;
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?"
  );
}
var pool = new Pool({ connectionString: process.env.DATABASE_URL });
var db = drizzle({ client: pool, schema: schema_exports });

// server/storage.ts
import { eq, desc, and, gte, lte } from "drizzle-orm";
var DatabaseStorage = class {
  // User operations for email/password auth
  async getUser(id) {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  async upsertUser(userData) {
    const [user] = await db.insert(users).values(userData).onConflictDoUpdate({
      target: users.id,
      set: {
        ...userData,
        updatedAt: /* @__PURE__ */ new Date()
      }
    }).returning();
    return user;
  }
  async getUserByEmail(email) {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  async getUserByVerificationToken(token) {
    return void 0;
  }
  async getUserByResetToken(token) {
    return void 0;
  }
  async createUser(userData) {
    const [user] = await db.insert(users).values({
      ...userData,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    }).returning();
    return user;
  }
  async verifyUserEmail(id) {
  }
  async setPasswordResetToken(id, token, expires) {
  }
  async resetUserPassword(id, password) {
  }
  async updateVerificationToken(id, token, expires) {
  }
  // Conversation operations
  async createConversation(conversation) {
    const [result] = await db.insert(conversations).values(conversation).returning();
    return result;
  }
  async getConversations(userId) {
    return await db.select().from(conversations).where(eq(conversations.userId, userId)).orderBy(desc(conversations.updatedAt));
  }
  async getConversation(id) {
    const [conversation] = await db.select().from(conversations).where(eq(conversations.id, id));
    return conversation;
  }
  // Message operations
  async createMessage(message) {
    const [result] = await db.insert(messages).values(message).returning();
    return result;
  }
  async getMessages(conversationId) {
    return await db.select().from(messages).where(eq(messages.conversationId, conversationId)).orderBy(messages.timestamp);
  }
  // Health record operations
  async createHealthRecord(record) {
    const [result] = await db.insert(healthRecords).values(record).returning();
    return result;
  }
  async getHealthRecords(userId) {
    return await db.select().from(healthRecords).where(eq(healthRecords.userId, userId)).orderBy(desc(healthRecords.uploadedAt));
  }
  async deleteHealthRecord(id, userId) {
    await db.delete(healthRecords).where(and(eq(healthRecords.id, id), eq(healthRecords.userId, userId)));
  }
  // Medication operations
  async createMedication(medication) {
    const [result] = await db.insert(medications).values(medication).returning();
    return result;
  }
  async getMedications(userId) {
    return await db.select().from(medications).where(and(eq(medications.userId, userId), eq(medications.isActive, true))).orderBy(medications.name);
  }
  async updateMedication(id, medication) {
    const [result] = await db.update(medications).set(medication).where(eq(medications.id, id)).returning();
    return result;
  }
  async deleteMedication(id, userId) {
    await db.update(medications).set({ isActive: false }).where(and(eq(medications.id, id), eq(medications.userId, userId)));
  }
  // Medication reminder operations
  async createMedicationReminder(reminder) {
    const [result] = await db.insert(medicationReminders).values(reminder).returning();
    return result;
  }
  async getMedicationReminders(userId, startDate, endDate) {
    return await db.select({
      id: medicationReminders.id,
      medicationId: medicationReminders.medicationId,
      scheduledTime: medicationReminders.scheduledTime,
      takenAt: medicationReminders.takenAt,
      isTaken: medicationReminders.isTaken,
      isMissed: medicationReminders.isMissed,
      createdAt: medicationReminders.createdAt,
      medication: medications
    }).from(medicationReminders).innerJoin(medications, eq(medicationReminders.medicationId, medications.id)).where(
      and(
        eq(medications.userId, userId),
        gte(medicationReminders.scheduledTime, startDate),
        lte(medicationReminders.scheduledTime, endDate)
      )
    ).orderBy(medicationReminders.scheduledTime);
  }
  async updateMedicationReminder(id, reminder) {
    const [result] = await db.update(medicationReminders).set(reminder).where(eq(medicationReminders.id, id)).returning();
    return result;
  }
  // Appointment operations
  async createAppointment(appointmentData) {
    const [appointment] = await db.insert(appointments).values({
      ...appointmentData,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    }).returning();
    return appointment;
  }
  async getAppointments(userId) {
    return await db.select().from(appointments).where(eq(appointments.userId, userId)).orderBy(desc(appointments.appointmentDate));
  }
  async getAppointment(id) {
    const [appointment] = await db.select().from(appointments).where(eq(appointments.id, id));
    return appointment;
  }
  async updateAppointment(id, appointmentData) {
    const [updated] = await db.update(appointments).set({ ...appointmentData, updatedAt: /* @__PURE__ */ new Date() }).where(eq(appointments.id, id)).returning();
    return updated;
  }
  async deleteAppointment(id, userId) {
    await db.delete(appointments).where(and(eq(appointments.id, id), eq(appointments.userId, userId)));
  }
  // Appointment slot operations
  async createAppointmentSlot(slotData) {
    const [slot] = await db.insert(appointmentSlots).values({
      ...slotData,
      createdAt: /* @__PURE__ */ new Date()
    }).returning();
    return slot;
  }
  async getAvailableSlots(doctorSpecialty, startDate, endDate) {
    let whereConditions = [eq(appointmentSlots.isAvailable, true)];
    if (doctorSpecialty) {
      whereConditions.push(eq(appointmentSlots.doctorSpecialty, doctorSpecialty));
    }
    if (startDate && endDate) {
      whereConditions.push(
        gte(appointmentSlots.slotDate, startDate),
        lte(appointmentSlots.slotDate, endDate)
      );
    }
    return await db.select().from(appointmentSlots).where(and(...whereConditions)).orderBy(appointmentSlots.slotDate);
  }
  async updateAppointmentSlot(id, slotData) {
    const [updated] = await db.update(appointmentSlots).set(slotData).where(eq(appointmentSlots.id, id)).returning();
    return updated;
  }
};
var storage = new DatabaseStorage();

// server/replitAuth.ts
import * as client from "openid-client";
import { Strategy } from "openid-client/passport";
import passport from "passport";
import session from "express-session";
import memoize from "memoizee";
import connectPg from "connect-pg-simple";
if (!process.env.REPLIT_DOMAINS) {
  throw new Error("Environment variable REPLIT_DOMAINS not provided");
}
var getOidcConfig = memoize(
  async () => {
    return await client.discovery(
      new URL(process.env.ISSUER_URL ?? "https://replit.com/oidc"),
      process.env.REPL_ID
    );
  },
  { maxAge: 3600 * 1e3 }
);
function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1e3;
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions"
  });
  return session({
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: sessionTtl,
      sameSite: "lax"
    }
  });
}
function updateUserSession(user, tokens) {
  user.claims = tokens.claims();
  user.access_token = tokens.access_token;
  user.refresh_token = tokens.refresh_token;
  user.expires_at = user.claims?.exp;
}
async function upsertUser(claims) {
  await storage.upsertUser({
    id: claims["sub"],
    email: claims["email"],
    firstName: claims["first_name"],
    lastName: claims["last_name"],
    profileImageUrl: claims["profile_image_url"]
  });
}
async function setupAuth(app2) {
  app2.set("trust proxy", 1);
  app2.use(getSession());
  app2.use(passport.initialize());
  app2.use(passport.session());
  const config = await getOidcConfig();
  console.log("[AUTH] REPLIT_DOMAINS:", process.env.REPLIT_DOMAINS);
  console.log("[AUTH] NODE_ENV:", process.env.NODE_ENV);
  const verify = async (tokens, verified) => {
    try {
      console.log("[AUTH] Verifying user with claims:", tokens.claims());
      const user = {};
      updateUserSession(user, tokens);
      await upsertUser(tokens.claims());
      console.log("[AUTH] User verification successful");
      verified(null, user);
    } catch (error) {
      console.error("[AUTH] Error during user verification:", error);
      verified(error, null);
    }
  };
  const domains = process.env.REPLIT_DOMAINS.split(",");
  const allDomains = [...domains, "localhost", "healthaicompanion.replit.app"];
  for (const domain of allDomains) {
    const protocol = domain === "localhost" ? "http" : "https";
    const port = domain === "localhost" ? ":5000" : "";
    const strategyName = `replitauth:${domain}`;
    const strategy = new Strategy(
      {
        name: strategyName,
        config,
        scope: "openid email profile offline_access",
        callbackURL: `${protocol}://${domain}${port}/api/callback`
      },
      verify
    );
    passport.use(strategy);
    console.log(`[AUTH] Registered strategy: ${strategyName} for callback: ${protocol}://${domain}${port}/api/callback`);
  }
  passport.serializeUser((user, cb) => cb(null, user));
  passport.deserializeUser((user, cb) => cb(null, user));
  app2.get("/api/login", (req, res, next) => {
    const strategyName = `replitauth:${req.hostname}`;
    console.log(`[AUTH] Login request for hostname: ${req.hostname}, strategy: ${strategyName}`);
    console.log(`[AUTH] Available strategies: ${Object.keys(passport._strategies || {}).join(", ")}`);
    passport.authenticate(strategyName, {
      prompt: "login consent",
      scope: ["openid", "email", "profile", "offline_access"]
    })(req, res, next);
  });
  app2.get("/api/callback", (req, res, next) => {
    const strategyName = `replitauth:${req.hostname}`;
    console.log(`[AUTH] Callback request for hostname: ${req.hostname}, strategy: ${strategyName}`);
    console.log(`[AUTH] Available strategies: ${Object.keys(passport._strategies || {}).join(", ")}`);
    passport.authenticate(strategyName, {
      successReturnToOrRedirect: "/",
      failureRedirect: "/api/login"
    })(req, res, next);
  });
  app2.get("/api/logout", (req, res) => {
    req.logout(() => {
      res.redirect(
        client.buildEndSessionUrl(config, {
          client_id: process.env.REPL_ID,
          post_logout_redirect_uri: `${req.protocol}://${req.hostname}`
        }).href
      );
    });
  });
}
var isAuthenticated = async (req, res, next) => {
  const user = req.user;
  if (!req.isAuthenticated() || !user.expires_at) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const now = Math.floor(Date.now() / 1e3);
  if (now <= user.expires_at) {
    return next();
  }
  const refreshToken = user.refresh_token;
  if (!refreshToken) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
  try {
    const config = await getOidcConfig();
    const tokenResponse = await client.refreshTokenGrant(config, refreshToken);
    updateUserSession(user, tokenResponse);
    return next();
  } catch (error) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
};

// server/openai.ts
import OpenAI from "openai";
var openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});
async function chatWithAI(message) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a helpful health assistant AI. Provide informative, accurate health information while always emphasizing that you are not a substitute for professional medical advice. Always recommend consulting with healthcare providers for medical concerns. Keep responses concise but helpful. Focus on general health education and wellness guidance.

IMPORTANT DISCLAIMERS TO INCLUDE:
- Always include appropriate disclaimers about seeking professional medical care when discussing symptoms or health conditions
- Remind users that AI analysis might not always be accurate
- Emphasize that this is general information only, not personalized medical advice
- For medication questions, always recommend consulting pharmacists or doctors

MEDICATION-SPECIFIC GUIDANCE:
- When discussing medications, remind users to check with their pharmacist about interactions
- Suggest setting up pill reminders and tracking systems
- Mention the importance of taking medications as prescribed
- Remind about refill schedules and running out of medications

Keep responses helpful but always prioritize safety and professional medical guidance.`
        },
        {
          role: "user",
          content: message
        }
      ],
      max_tokens: 500,
      temperature: 0.7
    });
    return response.choices[0].message.content || "I'm sorry, I couldn't process your request. Please try again.";
  } catch (error) {
    console.error("Error with OpenAI API:", error);
    throw new Error("Failed to get AI response");
  }
}
async function generateMedicationReminders(medicationId, medication) {
  try {
    if (!medication.timeOfDay || medication.timeOfDay.length === 0) {
      return;
    }
    const startDate = new Date(medication.startDate);
    const endDate = medication.endDate ? new Date(medication.endDate) : new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3);
    const reminders = [];
    const currentDate = new Date(startDate);
    while (currentDate <= endDate) {
      for (const timeStr of medication.timeOfDay) {
        const [hours, minutes] = timeStr.split(":").map(Number);
        const reminderTime = new Date(currentDate);
        reminderTime.setHours(hours, minutes, 0, 0);
        if (reminderTime >= /* @__PURE__ */ new Date()) {
          reminders.push({
            medicationId,
            scheduledTime: reminderTime
          });
        }
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }
    for (const reminder of reminders) {
      await storage.createMedicationReminder(reminder);
    }
  } catch (error) {
    console.error("Error generating medication reminders:", error);
    throw new Error("Failed to generate medication reminders");
  }
}
async function analyzeMedicationInteractions(medications2) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a pharmaceutical information assistant. Analyze potential drug interactions for the given medications. Provide general information about common interactions, but always emphasize the importance of consulting with pharmacists or healthcare providers for personalized advice. Always include disclaimers that AI analysis might not be accurate and that professional consultation is essential."
        },
        {
          role: "user",
          content: `Please analyze potential interactions between these medications: ${medications2.join(", ")}. Provide general information about any known interactions, timing considerations, and suggestions for pharmacy consultation.`
        }
      ],
      max_tokens: 400,
      temperature: 0.3
    });
    return response.choices[0].message.content || "Unable to analyze interactions. Please consult with your pharmacist or healthcare provider.";
  } catch (error) {
    console.error("Error analyzing medication interactions:", error);
    throw new Error("Failed to analyze medication interactions");
  }
}
async function generateMedicationAdvice(medicationName, symptoms) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a helpful health assistant specializing in medication guidance. Provide general educational information about medications and their effects. Always emphasize that:
          - This is general information only, not personalized medical advice
          - Users should consult their pharmacist or doctor for specific medication questions
          - AI analysis might not always be accurate
          - Never stop or change medications without professional guidance
          - Side effects should be reported to healthcare providers immediately`
        },
        {
          role: "user",
          content: `I'm taking ${medicationName} and experiencing ${symptoms}. Can you provide general information about this medication and suggest when I should contact my healthcare provider?`
        }
      ],
      max_tokens: 400,
      temperature: 0.3
    });
    return response.choices[0].message.content || "Please consult with your pharmacist or healthcare provider for medication-related concerns.";
  } catch (error) {
    console.error("Error generating medication advice:", error);
    throw new Error("Failed to generate medication advice");
  }
}
async function generateRefillReminder(medication) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a helpful medication reminder assistant. Generate friendly, clear reminders about medication refills and pharmacy visits. Always include practical tips and emphasize the importance of not running out of medications."
        },
        {
          role: "user",
          content: `Generate a helpful reminder message for refilling ${medication.name} (${medication.dosage}, taken ${medication.frequency}). Include tips about timing and pharmacy considerations.`
        }
      ],
      max_tokens: 200,
      temperature: 0.7
    });
    return response.choices[0].message.content || `Time to refill your ${medication.name}! Contact your pharmacy or doctor to avoid running out.`;
  } catch (error) {
    console.error("Error generating refill reminder:", error);
    return `Time to refill your ${medication.name}! Contact your pharmacy or doctor to avoid running out.`;
  }
}

// server/routes.ts
async function registerRoutes(app2) {
  await setupAuth(app2);
  const upload = multer({
    dest: "uploads/",
    limits: {
      fileSize: 10 * 1024 * 1024
      // files can be up to 10MB
    },
    fileFilter: (req, file, cb) => {
      const allowedTypes = [
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "image/jpeg",
        "image/png",
        "image/jpg"
      ];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error("Invalid file type. Only PDF, DOC, DOCX, JPG, PNG files are allowed."));
      }
    }
  });
  app2.get("/api/auth/user", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  app2.get("/api/debug/auth", (req, res) => {
    res.json({
      isAuthenticated: req.isAuthenticated(),
      user: req.user ? {
        claims: req.user.claims,
        expires_at: req.user.expires_at
      } : null,
      hostname: req.hostname,
      sessionID: req.sessionID
    });
  });
  app2.get("/api/conversations", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversations2 = await storage.getConversations(userId);
      res.json(conversations2);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });
  app2.post("/api/conversations", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversationData = insertConversationSchema.parse({
        ...req.body,
        userId
      });
      const conversation = await storage.createConversation(conversationData);
      res.json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });
  app2.get("/api/conversations/:id/messages", isAuthenticated, async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages2 = await storage.getMessages(conversationId);
      res.json(messages2);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  app2.post("/api/chat", isAuthenticated, async (req, res) => {
    try {
      const { message, conversationId } = req.body;
      if (!message || !conversationId) {
        return res.status(400).json({ message: "Message and conversation ID are required" });
      }
      await storage.createMessage({
        conversationId,
        role: "user",
        content: message
      });
      const aiResponse = await chatWithAI(message);
      const savedResponse = await storage.createMessage({
        conversationId,
        role: "assistant",
        content: aiResponse
      });
      res.json(savedResponse);
    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });
  app2.get("/api/messages/:conversationId", isAuthenticated, async (req, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      const messages2 = await storage.getMessages(conversationId);
      res.json(messages2);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  app2.get("/api/conversations/:id/messages", isAuthenticated, async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages2 = await storage.getMessages(conversationId);
      res.json(messages2);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  app2.get("/api/health-records", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const records = await storage.getHealthRecords(userId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching health records:", error);
      res.status(500).json({ message: "Failed to fetch health records" });
    }
  });
  app2.post("/api/health-records", isAuthenticated, upload.single("file"), async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const file = req.file;
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      const recordData = insertHealthRecordSchema.parse({
        userId,
        fileName: file.filename,
        originalName: file.originalname,
        fileType: file.mimetype,
        fileSize: file.size,
        filePath: file.path,
        description: req.body.description || ""
      });
      const record = await storage.createHealthRecord(recordData);
      res.json(record);
    } catch (error) {
      console.error("Error uploading health record:", error);
      res.status(500).json({ message: "Failed to upload health record" });
    }
  });
  app2.delete("/api/health-records/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const recordId = parseInt(req.params.id);
      await storage.deleteHealthRecord(recordId, userId);
      res.json({ message: "Health record deleted successfully" });
    } catch (error) {
      console.error("Error deleting health record:", error);
      res.status(500).json({ message: "Failed to delete health record" });
    }
  });
  app2.get("/api/medications", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const medications2 = await storage.getMedications(userId);
      res.json(medications2);
    } catch (error) {
      console.error("Error fetching medications:", error);
      res.status(500).json({ message: "Failed to fetch medications" });
    }
  });
  app2.post("/api/medications", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const medicationData = insertMedicationSchema.parse({
        ...req.body,
        userId
      });
      const medication = await storage.createMedication(medicationData);
      await generateMedicationReminders(medication.id, medication);
      res.json(medication);
    } catch (error) {
      console.error("Error creating medication:", error);
      if (error.name === "ZodError") {
        return res.status(400).json({
          message: "Validation error",
          errors: error.errors
        });
      }
      res.status(500).json({ message: "Failed to create medication" });
    }
  });
  app2.put("/api/medications/:id", isAuthenticated, async (req, res) => {
    try {
      const medicationId = parseInt(req.params.id);
      const medicationData = insertMedicationSchema.parse(req.body);
      const medication = await storage.updateMedication(medicationId, medicationData);
      res.json(medication);
    } catch (error) {
      console.error("Error updating medication:", error);
      res.status(500).json({ message: "Failed to update medication" });
    }
  });
  app2.delete("/api/medications/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const medicationId = parseInt(req.params.id);
      await storage.deleteMedication(medicationId, userId);
      res.json({ message: "Medication deleted successfully" });
    } catch (error) {
      console.error("Error deleting medication:", error);
      res.status(500).json({ message: "Failed to delete medication" });
    }
  });
  app2.get("/api/medication-reminders", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const startDate = new Date(req.query.startDate);
      const endDate = new Date(req.query.endDate);
      const reminders = await storage.getMedicationReminders(userId, startDate, endDate);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching medication reminders:", error);
      res.status(500).json({ message: "Failed to fetch medication reminders" });
    }
  });
  app2.put("/api/medication-reminders/:id", isAuthenticated, async (req, res) => {
    try {
      const reminderId = parseInt(req.params.id);
      const reminderData = req.body;
      const reminder = await storage.updateMedicationReminder(reminderId, reminderData);
      res.json(reminder);
    } catch (error) {
      console.error("Error updating medication reminder:", error);
      res.status(500).json({ message: "Failed to update medication reminder" });
    }
  });
  app2.post("/api/medications/analyze-interactions", isAuthenticated, async (req, res) => {
    try {
      const { medications: medications2 } = req.body;
      if (!medications2 || !Array.isArray(medications2) || medications2.length === 0) {
        return res.status(400).json({ message: "Please provide an array of medication names" });
      }
      const analysis = await analyzeMedicationInteractions(medications2);
      res.json({ analysis });
    } catch (error) {
      console.error("Error analyzing medication interactions:", error);
      res.status(500).json({ message: "Failed to analyze medication interactions" });
    }
  });
  app2.post("/api/medications/advice", isAuthenticated, async (req, res) => {
    try {
      const { medicationName, symptoms } = req.body;
      if (!medicationName || !symptoms) {
        return res.status(400).json({ message: "Please provide medication name and symptoms" });
      }
      const advice = await generateMedicationAdvice(medicationName, symptoms);
      res.json({ advice });
    } catch (error) {
      console.error("Error generating medication advice:", error);
      res.status(500).json({ message: "Failed to generate medication advice" });
    }
  });
  app2.post("/api/medications/:id/refill-reminder", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const medicationId = parseInt(req.params.id);
      const medications2 = await storage.getMedications(userId);
      const medication = medications2.find((med) => med.id === medicationId);
      if (!medication) {
        return res.status(404).json({ message: "Medication not found" });
      }
      const reminder = await generateRefillReminder(medication);
      res.json({ reminder });
    } catch (error) {
      console.error("Error generating refill reminder:", error);
      res.status(500).json({ message: "Failed to generate refill reminder" });
    }
  });
  app2.get("/api/health-records/:id/download", isAuthenticated, async (req, res) => {
    try {
      const recordId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const records = await storage.getHealthRecords(userId);
      const record = records.find((r) => r.id === recordId);
      if (!record) {
        return res.status(404).json({ message: "Health record not found" });
      }
      const filePath = record.filePath;
      const originalName = record.originalName;
      const fs2 = await import("fs");
      if (!fs2.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found" });
      }
      res.setHeader("Content-Disposition", `attachment; filename="${originalName}"`);
      res.setHeader("Content-Type", record.fileType);
      const path3 = await import("path");
      res.sendFile(path3.resolve(filePath));
    } catch (error) {
      console.error("Error downloading health record:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });
  app2.get("/api/appointments", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const appointments2 = await storage.getAppointments(userId);
      res.json(appointments2);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });
  app2.post("/api/appointments", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const appointmentData = insertAppointmentSchema.parse({
        ...req.body,
        userId,
        appointmentDate: new Date(req.body.appointmentDate)
      });
      const appointment = await storage.createAppointment(appointmentData);
      res.status(201).json(appointment);
    } catch (error) {
      console.error("Error creating appointment:", error);
      if (error.name === "ZodError") {
        return res.status(400).json({
          message: "Validation error",
          errors: error.errors
        });
      }
      res.status(500).json({ message: "Failed to create appointment" });
    }
  });
  app2.put("/api/appointments/:id", isAuthenticated, async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const appointmentData = insertAppointmentSchema.partial().parse(req.body);
      const appointment = await storage.updateAppointment(appointmentId, appointmentData);
      res.json(appointment);
    } catch (error) {
      console.error("Error updating appointment:", error);
      res.status(500).json({ message: "Failed to update appointment" });
    }
  });
  app2.delete("/api/appointments/:id", isAuthenticated, async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      await storage.deleteAppointment(appointmentId, userId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting appointment:", error);
      res.status(500).json({ message: "Failed to delete appointment" });
    }
  });
  app2.get("/api/appointment-slots", isAuthenticated, async (req, res) => {
    try {
      const { specialty, startDate, endDate } = req.query;
      const slots = await storage.getAvailableSlots(
        specialty,
        startDate ? new Date(startDate) : void 0,
        endDate ? new Date(endDate) : void 0
      );
      res.json(slots);
    } catch (error) {
      console.error("Error fetching appointment slots:", error);
      res.status(500).json({ message: "Failed to fetch appointment slots" });
    }
  });
  app2.post("/api/appointment-slots", isAuthenticated, async (req, res) => {
    try {
      const slotData = insertAppointmentSlotSchema.parse(req.body);
      const slot = await storage.createAppointmentSlot(slotData);
      res.status(201).json(slot);
    } catch (error) {
      console.error("Error creating appointment slot:", error);
      res.status(500).json({ message: "Failed to create appointment slot" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.get("/health", (_req, res) => {
  res.status(200).json({ status: "ok", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
});
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = 5e3;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
