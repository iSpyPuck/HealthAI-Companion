import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email").unique().notNull(),
  password: varchar("password").notNull(),
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  profileImageUrl: varchar("profile_image_url"),
  isEmailVerified: boolean("is_email_verified").default(false),
  emailVerificationToken: varchar("email_verification_token"),
  emailVerificationExpires: timestamp("email_verification_expires"),
  passwordResetToken: varchar("password_reset_token"),
  passwordResetExpires: timestamp("password_reset_expires"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Conversations table for chat history
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Messages table for chat messages
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id),
  role: varchar("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Health records table for uploaded documents
export const healthRecords = pgTable("health_records", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  fileName: varchar("file_name").notNull(),
  originalName: varchar("original_name").notNull(),
  fileType: varchar("file_type").notNull(),
  fileSize: integer("file_size").notNull(),
  filePath: varchar("file_path").notNull(),
  description: text("description"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  isVerified: boolean("is_verified").default(false),
});

// Medications table for medication tracking
export const medications = pgTable("medications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: varchar("name").notNull(),
  dosage: varchar("dosage").notNull(),
  frequency: varchar("frequency").notNull(),
  timeOfDay: varchar("time_of_day").array(), // Array of times like ['08:00', '20:00']
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Medication reminders table for tracking doses
export const medicationReminders = pgTable("medication_reminders", {
  id: serial("id").primaryKey(),
  medicationId: integer("medication_id").notNull().references(() => medications.id),
  scheduledTime: timestamp("scheduled_time").notNull(),
  takenAt: timestamp("taken_at"),
  isTaken: boolean("is_taken").default(false),
  isMissed: boolean("is_missed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Appointments table
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  appointmentDate: timestamp("appointment_date").notNull(),
  duration: integer("duration").default(30), // duration in minutes
  location: varchar("location", { length: 255 }),
  doctorName: varchar("doctor_name", { length: 100 }),
  doctorSpecialty: varchar("doctor_specialty", { length: 100 }),
  status: varchar("status", { length: 20 }).default("scheduled"), // scheduled, cancelled, completed, rescheduled
  reminderSent: boolean("reminder_sent").default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Available appointment slots for scheduling
export const appointmentSlots = pgTable("appointment_slots", {
  id: serial("id").primaryKey(),
  doctorName: varchar("doctor_name", { length: 100 }).notNull(),
  doctorSpecialty: varchar("doctor_specialty", { length: 100 }).notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  slotDate: timestamp("slot_date").notNull(),
  duration: integer("duration").default(30), // duration in minutes
  isAvailable: boolean("is_available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Symptom analysis table for AI-powered symptom analysis
export const symptomAnalyses = pgTable("symptom_analyses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  selectedBodyParts: varchar("selected_body_parts").array().notNull(), // Array of body part IDs
  symptoms: text("symptoms").notNull(),
  severity: integer("severity").notNull(), // 1-10 scale
  duration: varchar("duration").notNull(),
  analysis: text("analysis").notNull(),
  recommendations: text("recommendations").array().notNull(),
  urgencyLevel: varchar("urgency_level").notNull(), // 'low', 'medium', 'high', 'urgent'
  possibleConditions: varchar("possible_conditions").array().notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Gamified habit tracker tables
export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name").notNull(),
  description: text("description"),
  icon: varchar("icon").notNull(), // emoji or icon name
  color: varchar("color").notNull(), // hex color
  frequency: varchar("frequency").notNull(), // 'daily', 'weekly', 'monthly'
  targetCount: integer("target_count").default(1), // how many times per frequency period
  category: varchar("category").notNull(), // 'fitness', 'nutrition', 'sleep', 'mental', 'medical'
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const habitLogs = pgTable("habit_logs", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").notNull().references(() => habits.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  completedAt: timestamp("completed_at").defaultNow(),
  notes: text("notes"),
  streak: integer("streak").default(0),
});

export const userCharacter = pgTable("user_character", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }).unique(),
  characterType: varchar("character_type").default("bunny"), // 'bunny', 'cat', 'dog', 'dragon'
  level: integer("level").default(1),
  experience: integer("experience").default(0),
  totalHabitsCompleted: integer("total_habits_completed").default(0),
  currentStreak: integer("current_streak").default(0),
  longestStreak: integer("longest_streak").default(0),
  mood: varchar("mood").default("happy"), // 'happy', 'excited', 'motivated', 'sleepy', 'sad'
  lastActivity: timestamp("last_activity").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  icon: varchar("icon").notNull(),
  category: varchar("category").notNull(), // 'streak', 'completion', 'variety', 'milestone'
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

// Body symptoms table for interactive body mapping
export const bodySymptoms = pgTable("body_symptoms", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  bodyPart: varchar("body_part", { length: 100 }).notNull(),
  symptomType: varchar("symptom_type", { length: 100 }).notNull(),
  severity: integer("severity").notNull(), // 1-10 scale
  description: text("description"),
  xPosition: integer("x_position").notNull(), // Percentage position on image
  yPosition: integer("y_position").notNull(), // Percentage position on image
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  conversations: many(conversations),
  healthRecords: many(healthRecords),
  medications: many(medications),
  appointments: many(appointments),
  symptomAnalyses: many(symptomAnalyses),
  habits: many(habits),
  habitLogs: many(habitLogs),
  character: one(userCharacter),
  achievements: many(achievements),
  bodySymptoms: many(bodySymptoms),
}));

export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  user: one(users, {
    fields: [conversations.userId],
    references: [users.id],
  }),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
}));

export const healthRecordsRelations = relations(healthRecords, ({ one }) => ({
  user: one(users, {
    fields: [healthRecords.userId],
    references: [users.id],
  }),
}));

export const medicationsRelations = relations(medications, ({ one, many }) => ({
  user: one(users, {
    fields: [medications.userId],
    references: [users.id],
  }),
  reminders: many(medicationReminders),
}));

export const medicationRemindersRelations = relations(medicationReminders, ({ one }) => ({
  medication: one(medications, {
    fields: [medicationReminders.medicationId],
    references: [medications.id],
  }),
}));

export const appointmentsRelations = relations(appointments, ({ one }) => ({
  user: one(users, {
    fields: [appointments.userId],
    references: [users.id],
  }),
}));

export const symptomAnalysesRelations = relations(symptomAnalyses, ({ one }) => ({
  user: one(users, {
    fields: [symptomAnalyses.userId],
    references: [users.id],
  }),
}));

export const habitsRelations = relations(habits, ({ one, many }) => ({
  user: one(users, {
    fields: [habits.userId],
    references: [users.id],
  }),
  logs: many(habitLogs),
}));

export const habitLogsRelations = relations(habitLogs, ({ one }) => ({
  habit: one(habits, {
    fields: [habitLogs.habitId],
    references: [habits.id],
  }),
  user: one(users, {
    fields: [habitLogs.userId],
    references: [users.id],
  }),
}));

export const userCharacterRelations = relations(userCharacter, ({ one }) => ({
  user: one(users, {
    fields: [userCharacter.userId],
    references: [users.id],
  }),
}));

export const achievementsRelations = relations(achievements, ({ one }) => ({
  user: one(users, {
    fields: [achievements.userId],
    references: [users.id],
  }),
}));

export const bodySymptomsRelations = relations(bodySymptoms, ({ one }) => ({
  user: one(users, {
    fields: [bodySymptoms.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users);
export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  timestamp: true,
});
export const insertHealthRecordSchema = createInsertSchema(healthRecords).omit({
  id: true,
  uploadedAt: true,
  isVerified: true,
});
export const insertMedicationSchema = createInsertSchema(medications).omit({
  id: true,
  createdAt: true,
  isActive: true,
}).extend({
  startDate: z.coerce.date(),
  endDate: z.coerce.date().optional()
});
export const insertMedicationReminderSchema = createInsertSchema(medicationReminders).omit({
  id: true,
  createdAt: true,
  isTaken: true,
  isMissed: true,
});
export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  reminderSent: true,
}).extend({
  appointmentDate: z.coerce.date()
});
export const insertAppointmentSlotSchema = createInsertSchema(appointmentSlots).omit({
  id: true,
  createdAt: true,
});
export const insertSymptomAnalysisSchema = createInsertSchema(symptomAnalyses).omit({
  id: true,
  createdAt: true,
});

export const insertHabitSchema = createInsertSchema(habits).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  isActive: true,
});

export const insertHabitLogSchema = createInsertSchema(habitLogs).omit({
  id: true,
  completedAt: true,
  streak: true,
});

export const insertUserCharacterSchema = createInsertSchema(userCharacter).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastActivity: true,
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  unlockedAt: true,
});

export const insertBodySymptomSchema = createInsertSchema(bodySymptoms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
// Auth schemas - not used with Replit Auth, kept for backward compatibility
export const registerSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
});

export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

export const verifyEmailSchema = z.object({
  token: z.string().min(1, "Verification token is required"),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, "Reset token is required"),
});

export type User = typeof users.$inferSelect;

// Health Tips System
export const healthTips = pgTable("health_tips", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  category: varchar("category", { length: 50 }).notNull(), // Primary category: 'hydration', 'nutrition', 'exercise', 'sleep', 'mental_health', 'habits', 'preventive_care', 'social_wellness', 'completed'
  categories: text("categories").array(), // Multiple categories support
  difficulty: varchar("difficulty", { length: 20 }).notNull().default("easy"),
  points: integer("points").notNull().default(10),
  tags: text("tags").array(),
  estimatedTime: integer("estimated_time").default(5), // minutes
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userHealthTipCompletions = pgTable("user_health_tip_completions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  healthTipId: integer("health_tip_id").notNull().references(() => healthTips.id, { onDelete: "cascade" }),
  completedAt: timestamp("completed_at").defaultNow(),
  pointsEarned: integer("points_earned").notNull(),
});

export const dailyChallenges = pgTable("daily_challenges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  difficulty: varchar("difficulty", { length: 20 }).notNull().default("medium"),
  points: integer("points").notNull().default(50),
  dateGenerated: timestamp("date_generated").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  isCompleted: boolean("is_completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
  proofText: text("proof_text"),
  aiGenerated: boolean("ai_generated").notNull().default(true),
  tags: text("tags").array(),
});

export type HealthTip = typeof healthTips.$inferSelect;
export type InsertHealthTip = typeof healthTips.$inferInsert;
export type UserHealthTipCompletion = typeof userHealthTipCompletions.$inferSelect;
export type InsertUserHealthTipCompletion = typeof userHealthTipCompletions.$inferInsert;
export type InsertUser = typeof users.$inferInsert;
export type UpsertUser = typeof users.$inferInsert;
export type RegisterUser = z.infer<typeof registerSchema>;
export type LoginUser = z.infer<typeof loginSchema>;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertHealthRecord = z.infer<typeof insertHealthRecordSchema>;
export type HealthRecord = typeof healthRecords.$inferSelect;
export type InsertMedication = z.infer<typeof insertMedicationSchema>;
export type Medication = typeof medications.$inferSelect;
export type InsertMedicationReminder = z.infer<typeof insertMedicationReminderSchema>;
export type MedicationReminder = typeof medicationReminders.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointmentSlot = z.infer<typeof insertAppointmentSlotSchema>;
export type AppointmentSlot = typeof appointmentSlots.$inferSelect;
export type InsertSymptomAnalysis = z.infer<typeof insertSymptomAnalysisSchema>;
export type SymptomAnalysis = typeof symptomAnalyses.$inferSelect;

export type InsertHabit = z.infer<typeof insertHabitSchema>;
export type Habit = typeof habits.$inferSelect;
export type InsertHabitLog = z.infer<typeof insertHabitLogSchema>;
export type HabitLog = typeof habitLogs.$inferSelect;
export type InsertUserCharacter = z.infer<typeof insertUserCharacterSchema>;
export type UserCharacter = typeof userCharacter.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

export type DailyChallenge = typeof dailyChallenges.$inferSelect;
export type InsertDailyChallenge = typeof dailyChallenges.$inferInsert;

export type BodySymptom = typeof bodySymptoms.$inferSelect;
export type InsertBodySymptom = z.infer<typeof insertBodySymptomSchema>;

// Emergency Contacts System
export const emergencyContacts = pgTable("emergency_contacts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  relationship: varchar("relationship", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  email: varchar("email", { length: 255 }),
  address: text("address"),
  isPrimary: boolean("is_primary").default(false),
  medicalContact: boolean("medical_contact").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;

// Support Tickets System
export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("open"), // 'open', 'in_progress', 'resolved', 'closed'
  priority: varchar("priority", { length: 10 }).notNull().default("medium"), // 'low', 'medium', 'high', 'urgent'
  category: varchar("category", { length: 50 }).notNull().default("general"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertSupportTicketSchema = createInsertSchema(supportTickets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = z.infer<typeof insertSupportTicketSchema>;
