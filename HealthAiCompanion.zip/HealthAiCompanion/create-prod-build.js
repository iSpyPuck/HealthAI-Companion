#!/usr/bin/env node

import { execSync } from 'child_process';
import { existsSync, mkdirSync, writeFileSync } from 'fs';
import path from 'path';

console.log('🚀 Creating production build...');

// Build frontend with Vite first
console.log('📦 Building React frontend...');
execSync('vite build', { stdio: 'inherit' });

// Create public directory and ensure it exists for both dev and prod
if (!existsSync('public')) {
  mkdirSync('public', { recursive: true });
}

// Also create the directory structure that the dev server expects
if (!existsSync('/home/runner/public')) {
  mkdirSync('/home/runner/public', { recursive: true });
}

// Copy dist contents to public directory for deployment
console.log('📁 Copying build files...');
execSync('cp -r dist/* public/', { stdio: 'inherit' });
execSync('cp -r dist/* /home/runner/public/', { stdio: 'inherit' });

// Build backend
console.log('⚙️  Building backend...');
execSync('esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outfile=standalone.mjs', { stdio: 'inherit' });

// Verify files were created
if (!existsSync('standalone.mjs')) {
  throw new Error('standalone.mjs was not created during build');
}

if (!existsSync('public/index.html')) {
  throw new Error('public/index.html was not created during build');
}

console.log('✅ Production build completed successfully!');
console.log('   - Frontend: React app built and deployed ✓');
console.log('   - Backend: standalone.mjs ✓');
console.log('   - Static files: Copied to public/ ✓');
console.log('   - Health check: /health endpoint available');