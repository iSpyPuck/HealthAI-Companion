#!/usr/bin/env node

import { execSync } from 'child_process';
import { existsSync, mkdirSync } from 'fs';
import path from 'path';

console.log('🚀 Starting build process...');

// Ensure dist directory exists
if (!existsSync('dist')) {
  mkdirSync('dist', { recursive: true });
}

try {
  // Build frontend first
  console.log('📦 Building frontend...');
  execSync('vite build', { stdio: 'inherit' });
  
  // Copy built frontend files to the location expected by standalone.cjs
  console.log('📁 Copying frontend files to deployment location...');
  if (existsSync('dist/public')) {
    execSync('cp -r dist/public ./public', { stdio: 'inherit' });
    console.log('   - Frontend files copied to ./public/');
  } else {
    console.warn('   - Warning: dist/public directory not found, skipping copy');
  }
  
  // Build backend as standalone.mjs (using ESM format for import.meta compatibility)
  console.log('⚙️  Building backend...');
  execSync('esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outfile=standalone.mjs', { stdio: 'inherit' });
  
  console.log('✅ Build completed successfully!');
  console.log('   - Frontend: dist/public/ → ./public/');
  console.log('   - Backend: standalone.mjs');
  
} catch (error) {
  console.error('❌ Build failed:', error.message);
  process.exit(1);
}