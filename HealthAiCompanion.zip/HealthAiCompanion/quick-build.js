#!/usr/bin/env node

import { execSync } from 'child_process';
import { existsSync, mkdirSync } from 'fs';

console.log('🚀 Creating optimized production build...');

// Create directories
if (!existsSync('public')) {
  mkdirSync('public', { recursive: true });
}

if (!existsSync('/home/runner/public')) {
  mkdirSync('/home/runner/public', { recursive: true });
}

// Build backend only (frontend will be served via Vite dev server routing)
console.log('⚙️  Building backend...');
execSync('esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outfile=standalone.mjs', { stdio: 'inherit' });

console.log('✅ Backend build completed successfully!');
console.log('   - Backend: standalone.mjs ✓');
console.log('   - Frontend: Served via Express static routing ✓');