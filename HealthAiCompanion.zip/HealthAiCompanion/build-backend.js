#!/usr/bin/env node

import { execSync } from 'child_process';
import { existsSync } from 'fs';

console.log('⚙️  Building backend only...');

try {
  // Build backend as standalone.mjs (using ESM format for import.meta compatibility)
  execSync('esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outfile=standalone.mjs', { stdio: 'inherit' });
  
  // Verify standalone.mjs was created
  if (!existsSync('standalone.mjs')) {
    throw new Error('standalone.mjs was not created during build');
  }
  
  console.log('✅ Backend build completed successfully!');
  console.log('   - Backend: standalone.mjs ✓');
  
} catch (error) {
  console.error('❌ Backend build failed:', error.message);
  process.exit(1);
}