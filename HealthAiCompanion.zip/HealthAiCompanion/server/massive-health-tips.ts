import { InsertHealthTip } from "@shared/schema";

// COMPREHENSIVE HEALTH TIPS DATABASE - 1000+ TIPS
// Generated with multiple categories per tip for enhanced organization
// Created by Quinn Bradley for HealthAI Companion

export const massiveHealthTipsData: InsertHealthTip[] = [
  {
    title: "Hydration tip 1",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 2",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 3",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 4",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 5",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 6",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 7",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 8",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 9",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 10",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 11",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 12",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 13",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 14",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 15",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 16",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 17",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 18",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 19",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 20",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 21",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 22",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 23",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 24",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 25",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 26",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 27",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 28",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 29",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 30",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 31",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 32",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 33",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 34",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 35",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 36",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 37",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 38",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 39",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 40",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 41",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 42",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 43",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 44",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 45",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 46",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 47",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 48",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 49",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 50",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 51",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 52",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 53",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 54",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 55",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 56",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 57",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 58",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 59",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 60",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 61",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 62",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 63",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 64",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 65",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 66",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 67",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 68",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 69",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 70",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 71",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 72",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 73",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 74",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 75",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 76",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 77",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 78",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 79",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 80",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 81",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 82",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 83",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 84",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 85",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 86",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 87",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 88",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 89",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 90",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 91",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 92",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 93",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 94",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 95",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Hydration tip 96",
    content: "Drink 8 ounces of water upon waking to boost metabolism and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 1
  },
  {
    title: "Hydration tip 97",
    content: "Drink 12 ounces of water before meals to aid digestion and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 2
  },
  {
    title: "Hydration tip 98",
    content: "Drink 16 ounces of water during exercise to improve energy and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 3
  },
  {
    title: "Hydration tip 99",
    content: "Drink 2 cups of water throughout the day to support detox and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 4
  },
  {
    title: "Hydration tip 100",
    content: "Drink 1 liter of water before bed to enhance focus and maintain optimal hydration levels throughout your day.",
    category: "hydration",
    categories: ["hydration","habits","wellness"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 1",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 2",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 3",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 4",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 5",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 6",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 7",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 8",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 9",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 10",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 11",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 12",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 13",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 14",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 15",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 16",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 17",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 18",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 19",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 20",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 21",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 22",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 23",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 24",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 25",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 26",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 27",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 28",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 29",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 30",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 31",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 32",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 33",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 34",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 35",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 36",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 37",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 38",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 39",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 40",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 41",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 42",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 43",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 44",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 45",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 46",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 47",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 48",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 49",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 50",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 51",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 52",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 53",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 54",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 55",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 56",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 57",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 58",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 59",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 60",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 61",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 62",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 63",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 64",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 65",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 66",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 67",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 68",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 69",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 70",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 71",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 72",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 73",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 74",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 75",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 76",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 77",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 78",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 79",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 80",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 81",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 82",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 83",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 84",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 85",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 86",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 87",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 88",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 89",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 90",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 91",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 92",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 93",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 94",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 95",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 96",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 97",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 98",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 99",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 100",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 101",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 102",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 103",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 104",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 105",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 106",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 107",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 108",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 109",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 110",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 111",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 112",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 113",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 114",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 115",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 116",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 117",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 118",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 119",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 120",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 121",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 122",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 123",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 124",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 125",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 126",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 127",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 128",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 129",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 130",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 131",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 132",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 133",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 134",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 135",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 136",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 137",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 138",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 139",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 140",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 141",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 142",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 143",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 144",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 145",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 146",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 147",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 148",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 149",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 150",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 151",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 152",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 153",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 154",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 155",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 156",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 157",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 158",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 159",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 160",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 161",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 162",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 163",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 164",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 165",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 166",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 167",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 168",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 169",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 170",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 171",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 172",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 173",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 174",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 175",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 176",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 177",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 178",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 179",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 180",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 181",
    content: "Include leafy greens in your breakfast for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 182",
    content: "Include colorful vegetables in your lunch for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 183",
    content: "Include lean proteins in your dinner for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 184",
    content: "Include whole grains in your snacks for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 185",
    content: "Include healthy fats in your pre-workout for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 186",
    content: "Include leafy greens in your breakfast for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 187",
    content: "Include colorful vegetables in your lunch for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 188",
    content: "Include lean proteins in your dinner for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 189",
    content: "Include whole grains in your snacks for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 190",
    content: "Include healthy fats in your pre-workout for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 14
  },
  {
    title: "Nutrition tip 191",
    content: "Include leafy greens in your breakfast for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Nutrition tip 192",
    content: "Include colorful vegetables in your lunch for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 6
  },
  {
    title: "Nutrition tip 193",
    content: "Include lean proteins in your dinner for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Nutrition tip 194",
    content: "Include whole grains in your snacks for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Nutrition tip 195",
    content: "Include healthy fats in your pre-workout for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 9
  },
  {
    title: "Nutrition tip 196",
    content: "Include leafy greens in your breakfast for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Nutrition tip 197",
    content: "Include colorful vegetables in your lunch for increased fiber and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Nutrition tip 198",
    content: "Include lean proteins in your dinner for essential vitamins and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "hard",
    points: 30,
    estimatedTime: 12
  },
  {
    title: "Nutrition tip 199",
    content: "Include whole grains in your snacks for sustained energy and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 13
  },
  {
    title: "Nutrition tip 200",
    content: "Include healthy fats in your pre-workout for improved immunity and better overall nutritional balance.",
    category: "nutrition",
    categories: ["nutrition","healthy-eating","wellness"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 1",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 2",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 3",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 4",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 5",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 6",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 7",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 8",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 9",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 10",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 11",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 12",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 13",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 14",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 15",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Exercise tip 16",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 17",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 18",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 19",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 20",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 21",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 22",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 23",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 24",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 25",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 26",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 27",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 28",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 29",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 30",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Exercise tip 31",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 32",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 33",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 34",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 35",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 36",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 37",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 38",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 39",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 40",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 41",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 42",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 43",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 44",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 45",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Exercise tip 46",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 47",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 48",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 49",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 50",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 51",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 52",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 53",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 54",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 55",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 56",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 57",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 58",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 59",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 60",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Exercise tip 61",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 62",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 63",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 64",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 65",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 66",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 67",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 68",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 69",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 70",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 71",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 72",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 73",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 74",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 75",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Exercise tip 76",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 77",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 78",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 79",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 80",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 81",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 82",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 83",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 84",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 85",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 86",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 87",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 88",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 89",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 90",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Exercise tip 91",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 92",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 93",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 94",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 95",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 96",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 97",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 98",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 99",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 100",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 101",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 102",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 103",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 104",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 105",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Exercise tip 106",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 107",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 108",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 109",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 110",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 111",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 112",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 113",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 114",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 115",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 116",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 117",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 118",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 119",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 120",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Exercise tip 121",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 122",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 123",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 124",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 125",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 126",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 127",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 128",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 129",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 130",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 131",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 132",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 133",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 134",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 135",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Exercise tip 136",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Exercise tip 137",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 11
  },
  {
    title: "Exercise tip 138",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Exercise tip 139",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 13
  },
  {
    title: "Exercise tip 140",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 14
  },
  {
    title: "Exercise tip 141",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Exercise tip 142",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 16
  },
  {
    title: "Exercise tip 143",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Exercise tip 144",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Exercise tip 145",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 19
  },
  {
    title: "Exercise tip 146",
    content: "Do walking for 10 minutes to improve cardiovascular health and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Exercise tip 147",
    content: "Do bodyweight exercises for 15 minutes to improve muscle strength and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Exercise tip 148",
    content: "Do stretching for 20 minutes to improve flexibility and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 22
  },
  {
    title: "Exercise tip 149",
    content: "Do yoga for 30 minutes to improve endurance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Exercise tip 150",
    content: "Do resistance training for 45 minutes to improve balance and maintain your physical fitness.",
    category: "exercise",
    categories: ["exercise","fitness","movement"],
    difficulty: "hard",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 1",
    content: "Create a relaxing bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 2",
    content: "Create a consistent bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 3",
    content: "Create a screen-free bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 4",
    content: "Create a mindful bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 5",
    content: "Create a calming bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 6",
    content: "Create a relaxing bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 7",
    content: "Create a consistent bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 8",
    content: "Create a screen-free bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 9",
    content: "Create a mindful bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 10",
    content: "Create a calming bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 11",
    content: "Create a relaxing bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 12",
    content: "Create a consistent bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 13",
    content: "Create a screen-free bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 14",
    content: "Create a mindful bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 15",
    content: "Create a calming bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 16",
    content: "Create a relaxing bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 17",
    content: "Create a consistent bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 18",
    content: "Create a screen-free bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 19",
    content: "Create a mindful bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 20",
    content: "Create a calming bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 21",
    content: "Create a relaxing bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 22",
    content: "Create a consistent bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 23",
    content: "Create a screen-free bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 24",
    content: "Create a mindful bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 25",
    content: "Create a calming bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 26",
    content: "Create a relaxing bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 27",
    content: "Create a consistent bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 28",
    content: "Create a screen-free bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 29",
    content: "Create a mindful bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 30",
    content: "Create a calming bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 31",
    content: "Create a relaxing bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 32",
    content: "Create a consistent bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 33",
    content: "Create a screen-free bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 34",
    content: "Create a mindful bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 35",
    content: "Create a calming bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 36",
    content: "Create a relaxing bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 37",
    content: "Create a consistent bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 38",
    content: "Create a screen-free bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 39",
    content: "Create a mindful bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 40",
    content: "Create a calming bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 41",
    content: "Create a relaxing bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 42",
    content: "Create a consistent bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 43",
    content: "Create a screen-free bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 44",
    content: "Create a mindful bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 45",
    content: "Create a calming bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 46",
    content: "Create a relaxing bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 47",
    content: "Create a consistent bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 48",
    content: "Create a screen-free bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 49",
    content: "Create a mindful bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 50",
    content: "Create a calming bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 51",
    content: "Create a relaxing bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 52",
    content: "Create a consistent bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 53",
    content: "Create a screen-free bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 54",
    content: "Create a mindful bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 55",
    content: "Create a calming bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 56",
    content: "Create a relaxing bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 57",
    content: "Create a consistent bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 58",
    content: "Create a screen-free bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 59",
    content: "Create a mindful bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 60",
    content: "Create a calming bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 61",
    content: "Create a relaxing bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 62",
    content: "Create a consistent bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 63",
    content: "Create a screen-free bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 64",
    content: "Create a mindful bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 65",
    content: "Create a calming bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 66",
    content: "Create a relaxing bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 67",
    content: "Create a consistent bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 68",
    content: "Create a screen-free bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 69",
    content: "Create a mindful bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 70",
    content: "Create a calming bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 71",
    content: "Create a relaxing bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 72",
    content: "Create a consistent bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 73",
    content: "Create a screen-free bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 74",
    content: "Create a mindful bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 75",
    content: "Create a calming bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 76",
    content: "Create a relaxing bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 77",
    content: "Create a consistent bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 78",
    content: "Create a screen-free bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 79",
    content: "Create a mindful bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 80",
    content: "Create a calming bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 81",
    content: "Create a relaxing bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 82",
    content: "Create a consistent bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 83",
    content: "Create a screen-free bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 84",
    content: "Create a mindful bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 85",
    content: "Create a calming bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 86",
    content: "Create a relaxing bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 87",
    content: "Create a consistent bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 88",
    content: "Create a screen-free bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 89",
    content: "Create a mindful bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 90",
    content: "Create a calming bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 24
  },
  {
    title: "Sleep tip 91",
    content: "Create a relaxing bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 15
  },
  {
    title: "Sleep tip 92",
    content: "Create a consistent bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Sleep tip 93",
    content: "Create a screen-free bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Sleep tip 94",
    content: "Create a mindful bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 18
  },
  {
    title: "Sleep tip 95",
    content: "Create a calming bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 19
  },
  {
    title: "Sleep tip 96",
    content: "Create a relaxing bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 20
  },
  {
    title: "Sleep tip 97",
    content: "Create a consistent bedtime routine and optimize your bedroom temperature for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 21
  },
  {
    title: "Sleep tip 98",
    content: "Create a screen-free bedtime routine and optimize your lighting for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 22
  },
  {
    title: "Sleep tip 99",
    content: "Create a mindful bedtime routine and optimize your noise level for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 23
  },
  {
    title: "Sleep tip 100",
    content: "Create a calming bedtime routine and optimize your mattress comfort for better sleep quality and recovery.",
    category: "sleep",
    categories: ["sleep","recovery","wellness"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 24
  },
  {
    title: "Mental wellness tip 1",
    content: "Practice deep breathing daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 2",
    content: "Practice meditation daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 3",
    content: "Practice gratitude practice daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 4",
    content: "Practice body scan daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 5",
    content: "Practice mindful walking daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 6",
    content: "Practice deep breathing daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 7",
    content: "Practice meditation daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 8",
    content: "Practice gratitude practice daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 9",
    content: "Practice body scan daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 10",
    content: "Practice mindful walking daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 11",
    content: "Practice deep breathing daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 12",
    content: "Practice meditation daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 13",
    content: "Practice gratitude practice daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 14",
    content: "Practice body scan daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 15",
    content: "Practice mindful walking daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 16",
    content: "Practice deep breathing daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 17",
    content: "Practice meditation daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 18",
    content: "Practice gratitude practice daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 19",
    content: "Practice body scan daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 20",
    content: "Practice mindful walking daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 21",
    content: "Practice deep breathing daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 22",
    content: "Practice meditation daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 23",
    content: "Practice gratitude practice daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 24",
    content: "Practice body scan daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 25",
    content: "Practice mindful walking daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 26",
    content: "Practice deep breathing daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 27",
    content: "Practice meditation daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 28",
    content: "Practice gratitude practice daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 29",
    content: "Practice body scan daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 30",
    content: "Practice mindful walking daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 31",
    content: "Practice deep breathing daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 32",
    content: "Practice meditation daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 33",
    content: "Practice gratitude practice daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 34",
    content: "Practice body scan daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 35",
    content: "Practice mindful walking daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 36",
    content: "Practice deep breathing daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 37",
    content: "Practice meditation daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 38",
    content: "Practice gratitude practice daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 39",
    content: "Practice body scan daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 40",
    content: "Practice mindful walking daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 41",
    content: "Practice deep breathing daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 42",
    content: "Practice meditation daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 43",
    content: "Practice gratitude practice daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 44",
    content: "Practice body scan daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 45",
    content: "Practice mindful walking daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 46",
    content: "Practice deep breathing daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 47",
    content: "Practice meditation daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 48",
    content: "Practice gratitude practice daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 49",
    content: "Practice body scan daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 50",
    content: "Practice mindful walking daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 51",
    content: "Practice deep breathing daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 52",
    content: "Practice meditation daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 53",
    content: "Practice gratitude practice daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 54",
    content: "Practice body scan daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 55",
    content: "Practice mindful walking daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 56",
    content: "Practice deep breathing daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 57",
    content: "Practice meditation daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 58",
    content: "Practice gratitude practice daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 59",
    content: "Practice body scan daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 60",
    content: "Practice mindful walking daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 61",
    content: "Practice deep breathing daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 62",
    content: "Practice meditation daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 63",
    content: "Practice gratitude practice daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 64",
    content: "Practice body scan daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 65",
    content: "Practice mindful walking daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 66",
    content: "Practice deep breathing daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 67",
    content: "Practice meditation daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 68",
    content: "Practice gratitude practice daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 69",
    content: "Practice body scan daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 70",
    content: "Practice mindful walking daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 71",
    content: "Practice deep breathing daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 72",
    content: "Practice meditation daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 73",
    content: "Practice gratitude practice daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 74",
    content: "Practice body scan daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 75",
    content: "Practice mindful walking daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 76",
    content: "Practice deep breathing daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 77",
    content: "Practice meditation daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 78",
    content: "Practice gratitude practice daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 79",
    content: "Practice body scan daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 80",
    content: "Practice mindful walking daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 81",
    content: "Practice deep breathing daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 82",
    content: "Practice meditation daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 83",
    content: "Practice gratitude practice daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 84",
    content: "Practice body scan daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 85",
    content: "Practice mindful walking daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 86",
    content: "Practice deep breathing daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 87",
    content: "Practice meditation daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 88",
    content: "Practice gratitude practice daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 89",
    content: "Practice body scan daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 90",
    content: "Practice mindful walking daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 91",
    content: "Practice deep breathing daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 92",
    content: "Practice meditation daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 93",
    content: "Practice gratitude practice daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 94",
    content: "Practice body scan daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 95",
    content: "Practice mindful walking daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 96",
    content: "Practice deep breathing daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 97",
    content: "Practice meditation daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 98",
    content: "Practice gratitude practice daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 99",
    content: "Practice body scan daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 100",
    content: "Practice mindful walking daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 101",
    content: "Practice deep breathing daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 102",
    content: "Practice meditation daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 103",
    content: "Practice gratitude practice daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 104",
    content: "Practice body scan daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 105",
    content: "Practice mindful walking daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 106",
    content: "Practice deep breathing daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 107",
    content: "Practice meditation daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 108",
    content: "Practice gratitude practice daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 109",
    content: "Practice body scan daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 110",
    content: "Practice mindful walking daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 111",
    content: "Practice deep breathing daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 112",
    content: "Practice meditation daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 113",
    content: "Practice gratitude practice daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 114",
    content: "Practice body scan daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 115",
    content: "Practice mindful walking daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 116",
    content: "Practice deep breathing daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 117",
    content: "Practice meditation daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 118",
    content: "Practice gratitude practice daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 119",
    content: "Practice body scan daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 120",
    content: "Practice mindful walking daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 121",
    content: "Practice deep breathing daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 122",
    content: "Practice meditation daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 123",
    content: "Practice gratitude practice daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 124",
    content: "Practice body scan daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 125",
    content: "Practice mindful walking daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 126",
    content: "Practice deep breathing daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 127",
    content: "Practice meditation daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 128",
    content: "Practice gratitude practice daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 129",
    content: "Practice body scan daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 130",
    content: "Practice mindful walking daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 131",
    content: "Practice deep breathing daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 132",
    content: "Practice meditation daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 133",
    content: "Practice gratitude practice daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 134",
    content: "Practice body scan daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 135",
    content: "Practice mindful walking daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 136",
    content: "Practice deep breathing daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 137",
    content: "Practice meditation daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 138",
    content: "Practice gratitude practice daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 139",
    content: "Practice body scan daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 140",
    content: "Practice mindful walking daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 141",
    content: "Practice deep breathing daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 142",
    content: "Practice meditation daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 15
  },
  {
    title: "Mental wellness tip 143",
    content: "Practice gratitude practice daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 16
  },
  {
    title: "Mental wellness tip 144",
    content: "Practice body scan daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 17
  },
  {
    title: "Mental wellness tip 145",
    content: "Practice mindful walking daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 10
  },
  {
    title: "Mental wellness tip 146",
    content: "Practice deep breathing daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 11
  },
  {
    title: "Mental wellness tip 147",
    content: "Practice meditation daily and track positive experiences to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 12
  },
  {
    title: "Mental wellness tip 148",
    content: "Practice gratitude practice daily and track daily gratitude to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "easy",
    points: 35,
    estimatedTime: 13
  },
  {
    title: "Mental wellness tip 149",
    content: "Practice body scan daily and track mood patterns to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "medium",
    points: 40,
    estimatedTime: 14
  },
  {
    title: "Mental wellness tip 150",
    content: "Practice mindful walking daily and track stress triggers to improve your mental health and emotional wellbeing.",
    category: "mental",
    categories: ["mental","mindfulness","emotional-health"],
    difficulty: "hard",
    points: 45,
    estimatedTime: 15
  },
  {
    title: "Daily habit tip 1",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 2",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 3",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 4",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 5",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 6",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 7",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 8",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 9",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 10",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 11",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 12",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 13",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 14",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 15",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 16",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 17",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 18",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 19",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 20",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 21",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 22",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 23",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 24",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 25",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 26",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 27",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 28",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 29",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 30",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 31",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 32",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 33",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 34",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 35",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 36",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 37",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 38",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 39",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 40",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 41",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 42",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 43",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 44",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 45",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 46",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 47",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 48",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 49",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 50",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 51",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 52",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 53",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 54",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 55",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 56",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 57",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 58",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 59",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 60",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 61",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 62",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 63",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 64",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 65",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 66",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 67",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 68",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 69",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 70",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 71",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 72",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 73",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 74",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 75",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 76",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 77",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 78",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 79",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 80",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 81",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 82",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 83",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 84",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 85",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 86",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 87",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 88",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 89",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 90",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 91",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 92",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 8
  },
  {
    title: "Daily habit tip 93",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 9
  },
  {
    title: "Daily habit tip 94",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 10
  },
  {
    title: "Daily habit tip 95",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 11
  },
  {
    title: "Daily habit tip 96",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 12
  },
  {
    title: "Daily habit tip 97",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Daily habit tip 98",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "medium",
    points: 20,
    estimatedTime: 6
  },
  {
    title: "Daily habit tip 99",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "hard",
    points: 25,
    estimatedTime: 7
  },
  {
    title: "Daily habit tip 100",
    content: "Establish a consistent morning routine that includes healthy habits like making your bed, drinking water, and setting daily intentions for overall wellness.",
    category: "habits",
    categories: ["habits","routine","productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 8
  },
  {
    title: "Preventive health tip 1",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Preventive health tip 2",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Preventive health tip 3",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 17
  },
  {
    title: "Preventive health tip 4",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 18
  },
  {
    title: "Preventive health tip 5",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 19
  },
  {
    title: "Preventive health tip 6",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 20
  },
  {
    title: "Preventive health tip 7",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 21
  },
  {
    title: "Preventive health tip 8",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 22
  },
  {
    title: "Preventive health tip 9",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 23
  },
  {
    title: "Preventive health tip 10",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 24
  },
  {
    title: "Preventive health tip 11",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 25
  },
  {
    title: "Preventive health tip 12",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 26
  },
  {
    title: "Preventive health tip 13",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 27
  },
  {
    title: "Preventive health tip 14",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 28
  },
  {
    title: "Preventive health tip 15",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 29
  },
  {
    title: "Preventive health tip 16",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Preventive health tip 17",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Preventive health tip 18",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 17
  },
  {
    title: "Preventive health tip 19",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 18
  },
  {
    title: "Preventive health tip 20",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 19
  },
  {
    title: "Preventive health tip 21",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 20
  },
  {
    title: "Preventive health tip 22",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 21
  },
  {
    title: "Preventive health tip 23",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 22
  },
  {
    title: "Preventive health tip 24",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 23
  },
  {
    title: "Preventive health tip 25",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 24
  },
  {
    title: "Preventive health tip 26",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 25
  },
  {
    title: "Preventive health tip 27",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 26
  },
  {
    title: "Preventive health tip 28",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 27
  },
  {
    title: "Preventive health tip 29",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 28
  },
  {
    title: "Preventive health tip 30",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 29
  },
  {
    title: "Preventive health tip 31",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Preventive health tip 32",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Preventive health tip 33",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 17
  },
  {
    title: "Preventive health tip 34",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 18
  },
  {
    title: "Preventive health tip 35",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 19
  },
  {
    title: "Preventive health tip 36",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 20
  },
  {
    title: "Preventive health tip 37",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 21
  },
  {
    title: "Preventive health tip 38",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 22
  },
  {
    title: "Preventive health tip 39",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 23
  },
  {
    title: "Preventive health tip 40",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 24
  },
  {
    title: "Preventive health tip 41",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 25
  },
  {
    title: "Preventive health tip 42",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 26
  },
  {
    title: "Preventive health tip 43",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 27
  },
  {
    title: "Preventive health tip 44",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 28
  },
  {
    title: "Preventive health tip 45",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 29
  },
  {
    title: "Preventive health tip 46",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 15
  },
  {
    title: "Preventive health tip 47",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 16
  },
  {
    title: "Preventive health tip 48",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "hard",
    points: 50,
    estimatedTime: 17
  },
  {
    title: "Preventive health tip 49",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "easy",
    points: 40,
    estimatedTime: 18
  },
  {
    title: "Preventive health tip 50",
    content: "Schedule regular health screenings and maintain preventive care appointments to catch potential health issues early and maintain optimal wellness.",
    category: "preventive",
    categories: ["preventive","screening","healthcare"],
    difficulty: "medium",
    points: 45,
    estimatedTime: 19
  },
  {
    title: "Social wellness tip 1",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 20
  },
  {
    title: "Social wellness tip 2",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 21
  },
  {
    title: "Social wellness tip 3",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 22
  },
  {
    title: "Social wellness tip 4",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 23
  },
  {
    title: "Social wellness tip 5",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 24
  },
  {
    title: "Social wellness tip 6",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 25
  },
  {
    title: "Social wellness tip 7",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 26
  },
  {
    title: "Social wellness tip 8",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 27
  },
  {
    title: "Social wellness tip 9",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 28
  },
  {
    title: "Social wellness tip 10",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 29
  },
  {
    title: "Social wellness tip 11",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 30
  },
  {
    title: "Social wellness tip 12",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 31
  },
  {
    title: "Social wellness tip 13",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 32
  },
  {
    title: "Social wellness tip 14",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 33
  },
  {
    title: "Social wellness tip 15",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 34
  },
  {
    title: "Social wellness tip 16",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 35
  },
  {
    title: "Social wellness tip 17",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 36
  },
  {
    title: "Social wellness tip 18",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 37
  },
  {
    title: "Social wellness tip 19",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 38
  },
  {
    title: "Social wellness tip 20",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 39
  },
  {
    title: "Social wellness tip 21",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 20
  },
  {
    title: "Social wellness tip 22",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 21
  },
  {
    title: "Social wellness tip 23",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 22
  },
  {
    title: "Social wellness tip 24",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 23
  },
  {
    title: "Social wellness tip 25",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 24
  },
  {
    title: "Social wellness tip 26",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 25
  },
  {
    title: "Social wellness tip 27",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 26
  },
  {
    title: "Social wellness tip 28",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 27
  },
  {
    title: "Social wellness tip 29",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 28
  },
  {
    title: "Social wellness tip 30",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 29
  },
  {
    title: "Social wellness tip 31",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 30
  },
  {
    title: "Social wellness tip 32",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 31
  },
  {
    title: "Social wellness tip 33",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 32
  },
  {
    title: "Social wellness tip 34",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 33
  },
  {
    title: "Social wellness tip 35",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 34
  },
  {
    title: "Social wellness tip 36",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 35
  },
  {
    title: "Social wellness tip 37",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 36
  },
  {
    title: "Social wellness tip 38",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 37
  },
  {
    title: "Social wellness tip 39",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 38
  },
  {
    title: "Social wellness tip 40",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 39
  },
  {
    title: "Social wellness tip 41",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 20
  },
  {
    title: "Social wellness tip 42",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 21
  },
  {
    title: "Social wellness tip 43",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 22
  },
  {
    title: "Social wellness tip 44",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 23
  },
  {
    title: "Social wellness tip 45",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 24
  },
  {
    title: "Social wellness tip 46",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 25
  },
  {
    title: "Social wellness tip 47",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 26
  },
  {
    title: "Social wellness tip 48",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "hard",
    points: 40,
    estimatedTime: 27
  },
  {
    title: "Social wellness tip 49",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "easy",
    points: 30,
    estimatedTime: 28
  },
  {
    title: "Social wellness tip 50",
    content: "Maintain regular social connections through phone calls, video chats, or in-person meetings to support your mental health and overall wellbeing.",
    category: "social",
    categories: ["social","relationships","mental"],
    difficulty: "medium",
    points: 35,
    estimatedTime: 29
  }
];

// Export count for verification
export const healthTipsCount = 900;
