// Import Python email bridge
import { sendEmail as pythonSendEmail, sendVerificationEmail as pythonSendVerificationEmail, sendPasswordResetEmail as pythonSendPasswordResetEmail } from './email_bridge.js';

export interface EmailParams {
  to: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  try {
    return await pythonSendEmail(params);
  } catch (error) {
    console.error('Email service error:', error);
    return false;
  }
}

export async function sendVerificationEmail(email: string, token: string): Promise<boolean> {
  try {
    return await pythonSendVerificationEmail(email, token);
  } catch (error) {
    console.error('Verification email service error:', error);
    return false;
  }
}

export async function sendPasswordResetEmail(email: string, token: string): Promise<boolean> {
  try {
    return await pythonSendPasswordResetEmail(email, token);
  } catch (error) {
    console.error('Password reset email service error:', error);
    return false;
  }
}