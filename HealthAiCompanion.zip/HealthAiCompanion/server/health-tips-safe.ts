import { InsertHealthTip } from "@shared/schema";

// Ultra-safe health tips data without tags to avoid all JSON parsing issues
export const safeHealthTipsData: InsertHealthTip[] = [
  // Hydration Tips
  {
    title: "Start your day with water",
    content: "Drink a full glass of water immediately upon waking to kickstart your metabolism and rehydrate your body after sleep.",
    category: "hydration",
    categories: ["hydration", "habits", "morning"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 1
  },
  {
    title: "Carry a water bottle",
    content: "Keep a reusable water bottle with you throughout the day as a visual reminder to drink water regularly.",
    category: "hydration",
    categories: ["hydration", "habits", "reminders"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 5
  },
  {
    title: "Drink water before meals",
    content: "Consume a glass of water 30 minutes before each meal to aid digestion and help control portion sizes.",
    category: "hydration",
    categories: ["hydration", "nutrition", "digestion"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 1
  },

  // Nutrition Tips
  {
    title: "Eat colorful foods",
    content: "Include fruits and vegetables of different colors in each meal to ensure diverse nutrient intake.",
    category: "nutrition",
    categories: ["nutrition", "vitamins", "variety"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 15
  },
  {
    title: "Practice portion control",
    content: "Use smaller plates and measure portions with your hands - palm for protein, fist for vegetables.",
    category: "nutrition",
    categories: ["nutrition", "weight", "habits"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Prepare healthy snacks",
    content: "Pre-portion nuts, cut vegetables, or prepare fruit to avoid reaching for processed snacks when hungry.",
    category: "nutrition",
    categories: ["nutrition", "preparation", "habits"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 20
  },

  // Exercise Tips
  {
    title: "Take a 10-minute walk",
    content: "Go for a brisk 10-minute walk to boost circulation, mood, and energy levels.",
    category: "exercise",
    categories: ["exercise", "cardio", "mental"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Do bodyweight exercises",
    content: "Perform 10 push-ups, 15 squats, and a 30-second plank to strengthen major muscle groups.",
    category: "exercise",
    categories: ["exercise", "strength", "functional"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 15
  },
  {
    title: "Stretch daily",
    content: "Complete a 10-minute stretching routine focusing on major muscle groups to improve flexibility.",
    category: "exercise",
    categories: ["exercise", "flexibility", "recovery"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },

  // Sleep Tips
  {
    title: "Create bedtime routine",
    content: "Create a consistent 30-minute pre-sleep routine including dimming lights and avoiding screens.",
    category: "sleep",
    categories: ["sleep", "habits", "relaxation"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 30
  },
  {
    title: "Optimize sleep environment",
    content: "Keep your bedroom cool (65-68°F), dark, and quiet for optimal sleep quality.",
    category: "sleep",
    categories: ["sleep", "environment", "recovery"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 10
  },
  {
    title: "Limit screen time",
    content: "Avoid phones, tablets, and TV for at least 1 hour before bedtime to improve sleep quality.",
    category: "sleep",
    categories: ["sleep", "technology", "habits"],
    difficulty: "medium",
    points: 25,
    estimatedTime: 60
  },

  // Mental Health Tips
  {
    title: "Practice meditation",
    content: "Spend 10 minutes focusing on your breath and observing thoughts without judgment.",
    category: "mental",
    categories: ["mental", "mindfulness", "stress"],
    difficulty: "medium",
    points: 30,
    estimatedTime: 10
  },
  {
    title: "Write gratitude list",
    content: "List three things you're grateful for today to shift focus toward positive aspects of life.",
    category: "mental",
    categories: ["mental", "gratitude", "positivity"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 5
  },
  {
    title: "Connect with friends",
    content: "Reach out to someone you care about through a call, text, or in-person visit.",
    category: "mental",
    categories: ["mental", "social", "relationships"],
    difficulty: "easy",
    points: 25,
    estimatedTime: 15
  },

  // Daily Habits
  {
    title: "Make your bed",
    content: "Start your day by making your bed to create a sense of accomplishment and order.",
    category: "habits",
    categories: ["habits", "morning", "productivity"],
    difficulty: "easy",
    points: 15,
    estimatedTime: 3
  },
  {
    title: "Take vitamins",
    content: "Take your daily vitamins or spend 15-20 minutes in sunlight to support health.",
    category: "habits",
    categories: ["habits", "nutrition", "preventive"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 1
  },
  {
    title: "Plan your day",
    content: "Spend 10 minutes planning your meals and activities for the day to make healthier choices.",
    category: "habits",
    categories: ["habits", "planning", "productivity"],
    difficulty: "easy",
    points: 20,
    estimatedTime: 10
  }
];