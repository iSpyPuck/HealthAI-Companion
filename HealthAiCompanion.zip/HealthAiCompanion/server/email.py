import os
import json
import sys

# Simplified import to avoid circular import issues
def send_email_simple(to_email, subject, text_content=None, html_content=None):
    """send email easy way"""
    print(f"[EMAIL SIMULATION] Would send email to: {to_email}")
    print(f"[EMAIL SIMULATION] Subject: {subject}")
    print(f"[EMAIL SIMULATION] Content: {text_content or html_content}")
    return True

def send_email(to_email, subject, text_content=None, html_content=None):
    """send email with api"""
    return send_email_simple(to_email, subject, text_content, html_content)

def send_verification_email(email, token):
    """send email to check user"""
    
    app_url = os.environ.get('APP_URL', 'http://localhost:5000')
    verification_url = f"{app_url}/verify-email?token={token}"
    
    html_content = f"""
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #0066CC;">Welcome to HealthAI Companion!</h2>
      <p>Thank you for creating an account. Please verify your email address by clicking the button below:</p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{verification_url}" 
           style="background-color: #0066CC; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
          Verify Email Address
        </a>
      </div>
      <p>Or copy and paste this link into your browser:</p>
      <p style="word-break: break-all; color: #666;">{verification_url}</p>
      <p><strong>This verification link will expire in 24 hours.</strong></p>
      <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
      <p style="color: #666; font-size: 12px;">
        If you didn't create an account with HealthAI Companion, please ignore this email.
      </p>
    </div>
    """
    
    text_content = f"""
    Welcome to HealthAI Companion!
    
    Thank you for creating an account. Please verify your email address by visiting:
    {verification_url}
    
    This verification link will expire in 24 hours.
    
    If you didn't create an account with HealthAI Companion, please ignore this email.
    """
    
    return send_email(
        to_email=email,
        subject='Verify your HealthAI Companion account',
        text_content=text_content,
        html_content=html_content
    )

def send_password_reset_email(email, token):
    """send email to reset password"""
    
    app_url = os.environ.get('APP_URL', 'http://localhost:5000')
    reset_url = f"{app_url}/reset-password?token={token}"
    
    html_content = f"""
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #0066CC;">Reset Your Password</h2>
      <p>You requested a password reset for your HealthAI Companion account. Click the button below to reset your password:</p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{reset_url}" 
           style="background-color: #0066CC; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
          Reset Password
        </a>
      </div>
      <p>Or copy and paste this link into your browser:</p>
      <p style="word-break: break-all; color: #666;">{reset_url}</p>
      <p><strong>This reset link will expire in 1 hour.</strong></p>
      <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
      <p style="color: #666; font-size: 12px;">
        If you didn't request a password reset, please ignore this email. Your password will remain unchanged.
      </p>
    </div>
    """
    
    text_content = f"""
    Reset Your Password
    
    You requested a password reset for your HealthAI Companion account. Visit this link to reset your password:
    {reset_url}
    
    This reset link will expire in 1 hour.
    
    If you didn't request a password reset, please ignore this email.
    """
    
    return send_email(
        to_email=email,
        subject='Reset your HealthAI Companion password',
        text_content=text_content,
        html_content=html_content
    )

if __name__ == "__main__":
    import sys
    
    # Handle bridge communication
    if len(sys.argv) == 1:
        # Read JSON data from stdin
        try:
            input_data = sys.stdin.read()
            if input_data:
                data = json.loads(input_data)
                
                if data.get('action') == 'verify':
                    result = send_verification_email(data['email'], data['token'])
                elif data.get('action') == 'reset':
                    result = send_password_reset_email(data['email'], data['token'])
                else:
                    result = send_email(
                        to_email=data['to_email'],
                        subject=data['subject'],
                        text_content=data.get('text_content'),
                        html_content=data.get('html_content')
                    )
                
                if result:
                    print("SUCCESS")
                    sys.exit(0)
                else:
                    print("FAILED")
                    sys.exit(1)
            else:
                print("No input data provided")
                sys.exit(1)
        except Exception as e:
            print(f"Error processing email request: {e}")
            sys.exit(1)
    
    # Test functionality
    elif len(sys.argv) > 1 and sys.argv[1] == "test":
        result = send_email(
            to_email="test@example.com",
            subject="Test Email",
            text_content="This is a test email from HealthAI Companion",
            html_content="<p>This is a <strong>test email</strong> from HealthAI Companion</p>"
        )
        print(f"Email test result: {result}")