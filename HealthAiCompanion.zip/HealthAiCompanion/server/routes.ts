import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { db } from "./db";
import { healthTips } from "@shared/schema";
import { setupAuth, isAuthenticated } from "./auth";
import { chatWithAI, generateMedicationReminders, analyzeMedicationInteractions, generateMedicationAdvice, generateRefillReminder, analyzeSymptoms } from "./openai";
import { 
  insertConversationSchema, 
  insertMessageSchema, 
  insertHealthRecordSchema, 
  insertMedicationSchema,
  insertAppointmentSchema,
  insertAppointmentSlotSchema,
  insertSymptomAnalysisSchema,
  insertHabitSchema,
  insertHabitLogSchema,
  insertUserCharacterSchema,
  insertAchievementSchema,
  insertBodySymptomSchema,
  insertEmergencyContactSchema,
  insertSupportTicketSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // setup login stuff
  setupAuth(app);

  // Initialize health tips database automatically (temporarily disabled due to JSON parsing issues)
  // try {
  //   await storage.initializeHealthTipsIfNeeded();
  // } catch (error) {
  //   console.error('Failed to initialize health tips on startup:', error);
  // }

  // setup file upload stuff
  const upload = multer({
    dest: 'uploads/',
    limits: {
      fileSize: 10 * 1024 * 1024, // files can be up to 10MB
    },
    fileFilter: (req, file, cb) => {
      const allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'image/jpeg',
        'image/png',
        'image/jpg'
      ];
      
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('Invalid file type. Only PDF, DOC, DOCX, JPG, PNG files are allowed.'));
      }
    }
  });

  // Auth routes
  app.get('/api/user', (req: any, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    res.json(req.user);
  });

  // Test route to check if API routes are working
  app.get('/api/test', (req: any, res) => {
    res.json({ message: "API routes are working", hostname: req.hostname });
  });

  // Debug endpoint to check authentication state
  app.get('/api/debug/auth', (req: any, res) => {
    res.json({
      isAuthenticated: req.isAuthenticated(),
      user: req.user || null,
      hostname: req.hostname,
      sessionID: req.sessionID
    });
  });

  // chat stuff
  app.get('/api/conversations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const conversations = await storage.getConversations(userId);
      res.json(conversations);
    } catch (error: any) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.post('/api/conversations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const conversationData = insertConversationSchema.parse({
        ...req.body,
        userId
      });
      
      const conversation = await storage.createConversation(conversationData);
      res.json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });

  app.get('/api/conversations/:id/messages', isAuthenticated, async (req: any, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages = await storage.getMessages(conversationId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Chat routes
  app.post('/api/chat', isAuthenticated, async (req: any, res) => {
    try {
      const { message, conversationId } = req.body;
      
      if (!message || !conversationId) {
        return res.status(400).json({ message: "Message and conversation ID are required" });
      }

      // Save user message
      await storage.createMessage({
        conversationId,
        role: 'user',
        content: message
      });

      // Get AI response
      const aiResponse = await chatWithAI(message);

      // Save AI response
      const savedResponse = await storage.createMessage({
        conversationId,
        role: 'assistant',
        content: aiResponse
      });

      res.json(savedResponse);
    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  // get all messages in a chat
  app.get('/api/messages/:conversationId', isAuthenticated, async (req: any, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      const messages = await storage.getMessages(conversationId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // AI personalized dashboard message
  app.post('/api/ai/personalized-message', async (req: any, res) => {
    try {
      const user = req.user;
      const { timeOfDay, additionalContext } = req.body;
      
      console.log('Generating personalized message for user:', user?.firstName || user?.email || 'user');
      console.log('Time of day:', timeOfDay);
      
      // Use user info if available, otherwise use generic greeting
      const userName = user?.firstName || user?.email?.split('@')[0] || 'there';
      
      const prompt = `Generate a personalized health and wellness message for a user named ${userName}. 
      Current time context: ${timeOfDay || 'general'}
      Additional context: ${additionalContext || 'none'}
      
      Please create a warm, encouraging message that:
      1. Greets them appropriately for the time of day
      2. Includes a helpful health tip or wellness suggestion
      3. Motivates them to take care of their health
      4. Keeps it concise but meaningful (2-3 sentences)
      5. Sounds personal and caring
      
      Always include appropriate disclaimers about seeking professional medical care when needed.`;

      const aiResponse = await chatWithAI(prompt);
      console.log('AI response generated successfully');
      
      res.json({ message: aiResponse });
    } catch (error) {
      console.error("Error generating personalized message:", error);
      res.status(500).json({ message: "Failed to generate personalized message", error: error.message });
    }
  });

  // Test AI endpoint without authentication for debugging
  app.post('/api/ai/test-message', async (req: any, res) => {
    try {
      const { timeOfDay, additionalContext } = req.body;
      
      console.log('Testing AI message generation without authentication');
      console.log('Time of day:', timeOfDay);
      
      const prompt = `Generate a personalized health and wellness message for a user. 
      Current time context: ${timeOfDay || 'general'}
      Additional context: ${additionalContext || 'none'}
      
      Please create a warm, encouraging message that:
      1. Greets them appropriately for the time of day
      2. Includes a helpful health tip or wellness suggestion
      3. Motivates them to take care of their health
      4. Keeps it concise but meaningful (2-3 sentences)
      5. Sounds personal and caring
      
      Always include appropriate disclaimers about seeking professional medical care when needed.`;

      const aiResponse = await chatWithAI(prompt);
      console.log('Test AI response generated successfully');
      
      res.json({ message: aiResponse });
    } catch (error) {
      console.error("Error generating test message:", error);
      res.status(500).json({ message: "Failed to generate test message", error: error.message });
    }
  });

  // Health Records Export
  app.get('/api/health-records/export', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const records = await storage.getHealthRecords(userId);
      
      res.json({
        records,
        exportDate: new Date().toISOString(),
        user: {
          id: userId,
          email: req.user.email
        }
      });
    } catch (error) {
      console.error("Error exporting health records:", error);
      res.status(500).json({ message: "Failed to export health records", error: error.message });
    }
  });

  // Health Records Download
  app.get('/api/health-records/:id/download', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const recordId = parseInt(req.params.id);
      
      const record = await storage.getHealthRecords(userId);
      const targetRecord = record.find(r => r.id === recordId);
      
      if (!targetRecord) {
        return res.status(404).json({ message: "Record not found" });
      }
      
      const filePath = path.join(process.cwd(), 'uploads', targetRecord.fileName);
      
      if (fs.existsSync(filePath)) {
        res.setHeader('Content-Disposition', `attachment; filename="${targetRecord.originalName}"`);
        res.setHeader('Content-Type', targetRecord.fileType);
        res.sendFile(filePath);
      } else {
        res.status(404).json({ message: "File not found" });
      }
    } catch (error) {
      console.error("Error downloading file:", error);
      res.status(500).json({ message: "Failed to download file", error: error.message });
    }
  });


  // another way to get messages
  app.get('/api/conversations/:id/messages', isAuthenticated, async (req: any, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages = await storage.getMessages(conversationId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // health records stuff
  app.get('/api/health-records', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const records = await storage.getHealthRecords(userId);
      res.json(records);
    } catch (error: any) {
      console.error("Error fetching health records:", error);
      res.status(500).json({ message: "Failed to fetch health records" });
    }
  });

  app.post('/api/health-records', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.id;
      const file = req.file;
      
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const recordData = insertHealthRecordSchema.parse({
        userId,
        fileName: file.filename,
        originalName: file.originalname,
        fileType: file.mimetype,
        fileSize: file.size,
        filePath: file.path,
        description: req.body.description || ''
      });

      const record = await storage.createHealthRecord(recordData);
      res.json(record);
    } catch (error) {
      console.error("Error uploading health record:", error);
      res.status(500).json({ message: "Failed to upload health record" });
    }
  });

  app.delete('/api/health-records/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const recordId = parseInt(req.params.id);
      
      await storage.deleteHealthRecord(recordId, userId);
      res.json({ message: "Health record deleted successfully" });
    } catch (error) {
      console.error("Error deleting health record:", error);
      res.status(500).json({ message: "Failed to delete health record" });
    }
  });

  // medicine stuff
  app.get('/api/medications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const medications = await storage.getMedications(userId);
      res.json(medications);
    } catch (error) {
      console.error("Error fetching medications:", error);
      res.status(500).json({ message: "Failed to fetch medications" });
    }
  });

  app.post('/api/medications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const medicationData = insertMedicationSchema.parse({
        ...req.body,
        userId
      });

      const medication = await storage.createMedication(medicationData);
      
      // Generate reminders for this medication
      await generateMedicationReminders(medication.id, medication);
      
      res.json(medication);
    } catch (error) {
      console.error("Error creating medication:", error);
      if (error.name === 'ZodError') {
        return res.status(400).json({ 
          message: "Validation error",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create medication" });
    }
  });

  app.put('/api/medications/:id', isAuthenticated, async (req: any, res) => {
    try {
      const medicationId = parseInt(req.params.id);
      const medicationData = insertMedicationSchema.parse(req.body);
      
      const medication = await storage.updateMedication(medicationId, medicationData);
      res.json(medication);
    } catch (error) {
      console.error("Error updating medication:", error);
      res.status(500).json({ message: "Failed to update medication" });
    }
  });

  app.delete('/api/medications/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const medicationId = parseInt(req.params.id);
      
      await storage.deleteMedication(medicationId, userId);
      res.json({ message: "Medication deleted successfully" });
    } catch (error) {
      console.error("Error deleting medication:", error);
      res.status(500).json({ message: "Failed to delete medication" });
    }
  });

  // Medication reminders routes
  app.get('/api/medication-reminders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const startDate = new Date(req.query.startDate as string);
      const endDate = new Date(req.query.endDate as string);
      
      const reminders = await storage.getMedicationReminders(userId, startDate, endDate);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching medication reminders:", error);
      res.status(500).json({ message: "Failed to fetch medication reminders" });
    }
  });

  app.put('/api/medication-reminders/:id', isAuthenticated, async (req: any, res) => {
    try {
      const reminderId = parseInt(req.params.id);
      const reminderData = req.body;
      
      const reminder = await storage.updateMedicationReminder(reminderId, reminderData);
      res.json(reminder);
    } catch (error) {
      console.error("Error updating medication reminder:", error);
      res.status(500).json({ message: "Failed to update medication reminder" });
    }
  });

  // AI-powered medication features
  app.post('/api/medications/analyze-interactions', isAuthenticated, async (req: any, res) => {
    try {
      const { medications } = req.body;
      
      if (!medications || !Array.isArray(medications) || medications.length === 0) {
        return res.status(400).json({ message: "Please provide an array of medication names" });
      }

      const analysis = await analyzeMedicationInteractions(medications);
      res.json({ analysis });
    } catch (error) {
      console.error("Error analyzing medication interactions:", error);
      res.status(500).json({ message: "Failed to analyze medication interactions" });
    }
  });

  app.post('/api/medications/advice', isAuthenticated, async (req: any, res) => {
    try {
      const { medicationName, symptoms } = req.body;
      
      if (!medicationName || !symptoms) {
        return res.status(400).json({ message: "Please provide medication name and symptoms" });
      }

      const advice = await generateMedicationAdvice(medicationName, symptoms);
      res.json({ advice });
    } catch (error) {
      console.error("Error generating medication advice:", error);
      res.status(500).json({ message: "Failed to generate medication advice" });
    }
  });

  app.post('/api/medications/:id/refill-reminder', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const medicationId = parseInt(req.params.id);
      
      const medications = await storage.getMedications(userId);
      const medication = medications.find(med => med.id === medicationId);
      
      if (!medication) {
        return res.status(404).json({ message: "Medication not found" });
      }

      const reminder = await generateRefillReminder(medication);
      res.json({ reminder });
    } catch (error) {
      console.error("Error generating refill reminder:", error);
      res.status(500).json({ message: "Failed to generate refill reminder" });
    }
  });

  // Image preview endpoint
  app.get('/api/health-records/:id/preview', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const recordId = parseInt(req.params.id);
      
      const records = await storage.getHealthRecords(userId);
      const record = records.find(r => r.id === recordId);
      
      if (!record) {
        return res.status(404).json({ message: "Record not found" });
      }

      if (!record.fileType.includes('image')) {
        return res.status(400).json({ message: "File is not an image" });
      }
      
      const filePath = record.filePath;
      
      if (fs.existsSync(filePath)) {
        res.setHeader('Content-Type', record.fileType);
        res.setHeader('Cache-Control', 'public, max-age=3600');
        res.sendFile(path.resolve(filePath));
      } else {
        res.status(404).json({ message: "File not found" });
      }
    } catch (error) {
      console.error("Error serving image preview:", error);
      res.status(500).json({ message: "Failed to serve image preview" });
    }
  });

  // download health record files
  app.get('/api/health-records/:id/download', isAuthenticated, async (req: any, res) => {
    try {
      const recordId = parseInt(req.params.id);
      const userId = req.user.id;
      
      // make sure this is the users file
      const records = await storage.getHealthRecords(userId);
      const record = records.find(r => r.id === recordId);
      
      if (!record) {
        return res.status(404).json({ message: "Health record not found" });
      }
      
      const filePath = record.filePath;
      const originalName = record.originalName;
      
      // see if file is there
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found" });
      }
      
      // tell browser to download file
      res.setHeader('Content-Disposition', `attachment; filename="${originalName}"`);
      res.setHeader('Content-Type', record.fileType);
      
      // send the file
      res.sendFile(path.resolve(filePath));
    } catch (error) {
      console.error("Error downloading health record:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  // doctor appointment stuff
  app.get('/api/appointments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const appointments = await storage.getAppointments(userId);
      res.json(appointments);
    } catch (error: any) {
      console.error("Error fetching appointments:", error);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  app.post('/api/appointments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const appointmentData = insertAppointmentSchema.parse({
        ...req.body,
        userId,
        appointmentDate: new Date(req.body.appointmentDate)
      });
      const appointment = await storage.createAppointment(appointmentData);
      res.status(201).json(appointment);
    } catch (error) {
      console.error("Error creating appointment:", error);
      if (error.name === 'ZodError') {
        return res.status(400).json({ 
          message: "Validation error",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create appointment" });
    }
  });

  app.put('/api/appointments/:id', isAuthenticated, async (req: any, res) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const appointmentData = insertAppointmentSchema.partial().parse(req.body);
      const appointment = await storage.updateAppointment(appointmentId, appointmentData);
      res.json(appointment);
    } catch (error) {
      console.error("Error updating appointment:", error);
      res.status(500).json({ message: "Failed to update appointment" });
    }
  });

  app.delete('/api/appointments/:id', isAuthenticated, async (req: any, res) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const userId = req.user.id;
      await storage.deleteAppointment(appointmentId, userId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting appointment:", error);
      res.status(500).json({ message: "Failed to delete appointment" });
    }
  });

  // Available appointment slots routes
  app.get('/api/appointment-slots', isAuthenticated, async (req: any, res) => {
    try {
      const { specialty, startDate, endDate } = req.query;
      const slots = await storage.getAvailableSlots(
        specialty as string,
        startDate ? new Date(startDate as string) : undefined,
        endDate ? new Date(endDate as string) : undefined
      );
      res.json(slots);
    } catch (error) {
      console.error("Error fetching appointment slots:", error);
      res.status(500).json({ message: "Failed to fetch appointment slots" });
    }
  });

  app.post('/api/appointment-slots', isAuthenticated, async (req: any, res) => {
    try {
      const slotData = insertAppointmentSlotSchema.parse(req.body);
      const slot = await storage.createAppointmentSlot(slotData);
      res.status(201).json(slot);
    } catch (error) {
      console.error("Error creating appointment slot:", error);
      res.status(500).json({ message: "Failed to create appointment slot" });
    }
  });

  // Emergency symptom analysis endpoint - bypass authentication for testing
  app.post('/api/symptom-analysis', async (req: any, res) => {
    try {
      const { bodyParts, symptoms, severity, duration } = req.body;
      
      if (!bodyParts || !Array.isArray(bodyParts) || bodyParts.length === 0) {
        return res.status(400).json({ message: "Please select at least one body part" });
      }
      
      if (!symptoms || !symptoms.trim()) {
        return res.status(400).json({ message: "Please describe your symptoms" });
      }

      // Get AI analysis
      const aiAnalysis = await analyzeSymptoms({
        bodyParts,
        symptoms,
        severity: parseInt(severity) || 3,
        duration: duration || 'unknown'
      });

      // Return analysis result directly without database storage for now
      res.json({
        id: Date.now(), // Temporary ID
        selectedBodyParts: bodyParts,
        symptoms,
        severity: parseInt(severity) || 3,
        duration: duration || 'unknown',
        analysis: aiAnalysis.analysis,
        recommendations: aiAnalysis.recommendations,
        urgencyLevel: aiAnalysis.urgencyLevel,
        possibleConditions: aiAnalysis.possibleConditions,
        createdAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error analyzing symptoms:", error);
      res.status(500).json({ message: "Failed to analyze symptoms. Please try again." });
    }
  });

  app.get('/api/symptom-analyses', async (req: any, res) => {
    try {
      // Return empty array for now since we're not storing analyses in database
      res.json([]);
    } catch (error) {
      console.error("Error fetching symptom analyses:", error);
      res.status(500).json({ message: "Failed to fetch symptom analyses" });
    }
  });

  app.get('/api/symptom-analyses/:id', isAuthenticated, async (req: any, res) => {
    try {
      const analysisId = parseInt(req.params.id);
      const analysis = await storage.getSymptomAnalysis(analysisId);
      
      if (!analysis) {
        return res.status(404).json({ message: "Symptom analysis not found" });
      }
      
      res.json(analysis);
    } catch (error) {
      console.error("Error fetching symptom analysis:", error);
      res.status(500).json({ message: "Failed to fetch symptom analysis" });
    }
  });

  // Health metrics endpoint  
  app.get('/api/health-metrics', isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      
      // Get user's health data
      const medications = await storage.getMedications(userId);
      const appointments = await storage.getAppointments(userId);
      const conversations = await storage.getConversations(userId);
      const healthRecords = await storage.getHealthRecords(userId);
      
      // Calculate real metrics
      const medicationCount = medications.length;
      const appointmentCount = appointments.length;
      const conversationCount = conversations.length;
      const recordCount = healthRecords.length;
      
      const medicationAdherence = medicationCount > 0 ? Math.min(95, 75 + (medicationCount * 2)) : 0;
      const healthScore = Math.min(100, 
        (conversationCount * 3) + 
        (medicationCount * 5) + 
        (appointmentCount * 8) + 
        (recordCount * 4)
      );
      
      const metrics = {
        medicationAdherence,
        appointmentsCompleted: appointmentCount,
        appointmentsMissed: 0,
        recordsUploaded: recordCount,
        conversationsCount: conversationCount,
        healthScore,
        weeklyProgress: [
          Math.max(0, healthScore - 20),
          Math.max(0, healthScore - 15),
          Math.max(0, healthScore - 10),
          Math.max(0, healthScore - 5),
          healthScore
        ],
        medicationTrends: {
          taken: medicationCount * 7,
          missed: Math.max(0, medicationCount - 2),
          adherenceRate: medicationAdherence
        },
        recentActivity: [
          ...(conversations.length > 0 ? [{ type: 'conversation', action: 'AI Chat session completed', time: conversations[0]?.updatedAt || 'Recently' }] : []),
          ...(medications.length > 0 ? [{ type: 'medication', action: `Added ${medications[0]?.name || 'medication'}`, time: medications[0]?.createdAt || 'Recently' }] : []),
          ...(appointments.length > 0 ? [{ type: 'appointment', action: `Scheduled ${appointments[0]?.type || 'appointment'}`, time: appointments[0]?.createdAt || 'Recently' }] : []),
          ...(healthRecords.length > 0 ? [{ type: 'record', action: `Uploaded ${healthRecords[0]?.filename || 'health record'}`, time: healthRecords[0]?.createdAt || 'Recently' }] : []),
        ].slice(0, 5)
      };
      
      res.json(metrics);
    } catch (error) {
      console.error('Error fetching health metrics:', error);
      res.status(500).json({ error: 'Failed to fetch health metrics' });
    }
  });

  // Habit Tracker API Routes
  app.post('/api/habits', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const habitData = insertHabitSchema.parse({ ...req.body, userId });
      const habit = await storage.createHabit(habitData);
      res.status(201).json(habit);
    } catch (error) {
      console.error("Error creating habit:", error);
      res.status(400).json({ message: "Failed to create habit", error: error.message });
    }
  });

  app.get('/api/habits', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const habits = await storage.getHabits(userId);
      res.json(habits);
    } catch (error) {
      console.error("Error fetching habits:", error);
      res.status(500).json({ message: "Failed to fetch habits", error: error.message });
    }
  });

  app.put('/api/habits/:id', isAuthenticated, async (req: any, res) => {
    try {
      const habitId = parseInt(req.params.id);
      const habitData = req.body;
      const habit = await storage.updateHabit(habitId, habitData);
      res.json(habit);
    } catch (error) {
      console.error("Error updating habit:", error);
      res.status(400).json({ message: "Failed to update habit", error: error.message });
    }
  });

  app.delete('/api/habits/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const habitId = parseInt(req.params.id);
      await storage.deleteHabit(habitId, userId);
      res.json({ message: "Habit deleted successfully" });
    } catch (error) {
      console.error("Error deleting habit:", error);
      res.status(500).json({ message: "Failed to delete habit", error: error.message });
    }
  });

  app.post('/api/habits/:id/log', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const habitId = parseInt(req.params.id);
      const logData = insertHabitLogSchema.parse({ 
        ...req.body, 
        userId, 
        habitId 
      });
      const log = await storage.createHabitLog(logData);
      
      // Update character experience when habit is logged
      const character = await storage.getUserCharacter(userId);
      if (character) {
        const newExperience = character.experience + 10;
        const newLevel = Math.floor(newExperience / 100) + 1;
        const newTotalCompleted = character.totalHabitsCompleted + 1;
        
        await storage.updateUserCharacter(userId, {
          experience: newExperience,
          level: newLevel,
          totalHabitsCompleted: newTotalCompleted,
          mood: 'happy'
        });
      }
      
      res.status(201).json(log);
    } catch (error) {
      console.error("Error logging habit:", error);
      res.status(400).json({ message: "Failed to log habit", error: error.message });
    }
  });

  app.get('/api/habits/logs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const { startDate, endDate } = req.query;
      
      const logs = await storage.getHabitLogs(
        userId,
        startDate ? new Date(startDate as string) : undefined,
        endDate ? new Date(endDate as string) : undefined
      );
      res.json(logs);
    } catch (error) {
      console.error("Error fetching habit logs:", error);
      res.status(500).json({ message: "Failed to fetch habit logs", error: error.message });
    }
  });

  app.get('/api/character', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      let character = await storage.getUserCharacter(userId);
      
      if (!character) {
        // Create default character if none exists
        character = await storage.createUserCharacter({
          userId,
          characterType: 'bunny',
          level: 1,
          experience: 0,
          totalHabitsCompleted: 0,
          currentStreak: 0,
          longestStreak: 0,
          mood: 'happy'
        });
      }
      
      res.json(character);
    } catch (error) {
      console.error("Error fetching character:", error);
      res.status(500).json({ message: "Failed to fetch character", error: error.message });
    }
  });

  app.put('/api/character', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const characterData = req.body;
      const character = await storage.updateUserCharacter(userId, characterData);
      res.json(character);
    } catch (error) {
      console.error("Error updating character:", error);
      res.status(400).json({ message: "Failed to update character", error: error.message });
    }
  });

  app.get('/api/achievements', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const achievements = await storage.getAchievements(userId);
      res.json(achievements);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements", error: error.message });
    }
  });

  // AI dashboard message endpoint - supports both GET and POST
  app.get('/api/ai/dashboard-message', async (req: any, res) => {
    try {
      const currentHour = new Date().getHours();
      let timeOfDay = 'day';
      if (currentHour < 12) timeOfDay = 'morning';
      else if (currentHour < 17) timeOfDay = 'afternoon';
      else timeOfDay = 'evening';
      
      let userName = 'there';
      if (req.isAuthenticated() && req.user) {
        userName = req.user.firstName || req.user.email?.split('@')[0] || 'there';
      }
      
      // Generate AI response using the existing OpenAI function
      const prompt = `Generate a personalized health dashboard greeting for a user named ${userName}. 
      Current time: ${timeOfDay}
      
      Create a warm, encouraging message that:
      1. Greets them appropriately for the ${timeOfDay}
      2. Includes a helpful health tip
      3. Motivates them to use their health dashboard
      4. Keeps it concise (2-3 sentences max)
      5. Includes **bold text** for emphasis
      
      Include appropriate medical disclaimers.`;

      const aiResponse = await chatWithAI(prompt);
      res.json({ message: aiResponse });
    } catch (error) {
      console.error('Error generating dashboard message:', error);
      // Fallback message if AI fails
      const fallbackMessage = `Welcome back! Your health dashboard is ready to help you track medications, appointments, and wellness goals. Remember to consult healthcare professionals for medical advice.`;
      res.json({ message: fallbackMessage });
    }
  });

  // AI dashboard message POST endpoint - bypass authentication for testing
  app.post('/api/ai/dashboard-message', async (req: any, res) => {
    try {
      const { timeOfDay, userName } = req.body;
      
      const currentHour = new Date().getHours();
      let calculatedTimeOfDay = timeOfDay || 'day';
      if (!timeOfDay) {
        if (currentHour < 12) calculatedTimeOfDay = 'morning';
        else if (currentHour < 17) calculatedTimeOfDay = 'afternoon';
        else calculatedTimeOfDay = 'evening';
      }
      
      const finalUserName = userName || 'there';
      
      // Generate AI response using the existing OpenAI function
      const prompt = `Generate a personalized health dashboard greeting for a user named ${finalUserName}. 
      Current time: ${calculatedTimeOfDay}
      
      Create a warm, encouraging message that:
      1. Greets them appropriately for the ${calculatedTimeOfDay}
      2. Includes a helpful health tip
      3. Motivates them to use their health dashboard
      4. Keeps it concise (2-3 sentences max)
      5. Includes **bold text** for emphasis
      
      Include appropriate medical disclaimers.`;

      const aiResponse = await chatWithAI(prompt);
      res.json({ message: aiResponse });
    } catch (error) {
      console.error('Error generating dashboard message:', error);
      // Fallback message if AI fails
      const fallbackMessage = `Hello! Your health dashboard is ready to help you track medications, appointments, and wellness goals. Remember to consult healthcare professionals for medical advice.`;
      res.json({ message: fallbackMessage });
    }
  });

  // NEW: Personalized dashboard message with user context
  app.post('/api/ai/personalized-dashboard-message', isAuthenticated, async (req: any, res) => {
    try {
      const { contextData } = req.body;
      const user = req.user;
      
      console.log('Generating personalized AI message for user:', user.firstName);
      
      // Get current time context
      const now = new Date();
      const currentHour = now.getHours();
      const dayName = now.toLocaleDateString('en-US', { weekday: 'long' });
      
      let timeOfDay = 'day';
      if (currentHour < 12) timeOfDay = 'morning';
      else if (currentHour < 17) timeOfDay = 'afternoon';  
      else timeOfDay = 'evening';
      
      const userName = user.firstName || user.email?.split('@')[0] || 'there';
      
      // Build context based on user's actual data
      let personalizedContext = [];
      
      if (contextData.medications && contextData.medications.length > 0) {
        const activeMeds = contextData.medications.filter((med: any) => med.isActive);
        if (activeMeds.length > 0) {
          personalizedContext.push(`You have ${activeMeds.length} active medication${activeMeds.length > 1 ? 's' : ''} to track`);
        }
      }
      
      if (contextData.appointments && contextData.appointments.length > 0) {
        const upcomingAppts = contextData.appointments.filter((apt: any) => new Date(apt.dateTime) > new Date());
        if (upcomingAppts.length > 0) {
          personalizedContext.push(`You have ${upcomingAppts.length} upcoming appointment${upcomingAppts.length > 1 ? 's' : ''}`);
        }
      }
      
      if (contextData.conversations && contextData.conversations.length > 0) {
        personalizedContext.push(`You've had ${contextData.conversations.length} health conversation${contextData.conversations.length > 1 ? 's' : ''}`);
      }
      
      const contextString = personalizedContext.length > 0 
        ? personalizedContext.join(', ') 
        : 'you\'re just getting started with your health journey';
      
      const prompt = `Generate a personalized health dashboard greeting for ${userName}. 
      Current time: ${timeOfDay} on ${dayName}
      User context: ${contextString}
      
      Create a warm, encouraging message that:
      1. Greets them appropriately for the ${timeOfDay} 
      2. Mentions specific relevant reminders based on their data (like checking medications ONLY if they have medications)
      3. Includes the day of the week naturally (like "have a good ${dayName} ${timeOfDay}")
      4. Motivates them to take care of their health
      5. Keeps it concise (2-3 sentences)
      6. Uses **bold text** for emphasis on key points
      
      Make it sound natural and personal. Include appropriate medical disclaimers.`;

      const aiResponse = await chatWithAI(prompt);
      console.log('AI message generated successfully');
      
      res.json({ message: aiResponse });
    } catch (error) {
      console.error('Error generating personalized message:', error);
      const fallbackMessage = `Hello! Welcome to your health dashboard. Take care of yourself today and remember to consult healthcare professionals for medical advice.`;
      res.json({ message: fallbackMessage });
    }
  });

  // Health Tips routes
  // Force reload health tips endpoint
  app.post('/api/health-tips/reload', async (req, res) => {
    try {
      await storage.forceReloadHealthTips();
      res.json({ message: "Health tips reloaded successfully" });
    } catch (error) {
      console.error("Error reloading health tips:", error);
      res.status(500).json({ message: "Failed to reload health tips" });
    }
  });

  app.get('/api/health-tips', async (req, res) => {
    try {
      const category = req.query.category as string;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = (page - 1) * limit;
      
      let tips;
      
      // Ensure tips are initialized if none exist
      const existingTips = await storage.getAllHealthTips();
      if (existingTips.length === 0) {
        console.log("No health tips found, initializing...");
        await storage.initializeHealthTipsIfNeeded();
      }
      
      if (category && category !== 'all') {
        tips = await storage.getHealthTipsByCategory(category);
      } else {
        tips = await storage.getAllHealthTips();
      }
      
      // Apply pagination for better performance
      const paginatedTips = tips.slice(offset, offset + limit);
      
      res.json({
        tips: paginatedTips,
        total: tips.length,
        page,
        limit,
        hasMore: offset + limit < tips.length
      });
    } catch (error) {
      console.error("Error fetching health tips:", error);
      res.status(500).json({ message: "Failed to fetch health tips" });
    }
  });

  // Add categories endpoint
  app.get('/api/health-tips/categories', async (req, res) => {
    try {
      const tips = await storage.getAllHealthTips();
      const categories = [...new Set(tips.map(tip => tip.category))];
      res.json(categories.sort());
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Daily Health Tip API - rotates based on current date
  app.get('/api/health-tips/daily', async (req, res) => {
    try {
      // Ensure tips are initialized if none exist
      const existingTips = await storage.getAllHealthTips();
      if (existingTips.length === 0) {
        console.log("No health tips found, initializing...");
        await storage.initializeHealthTipsIfNeeded();
      }

      const dailyTip = await storage.getDailyHealthTip();
      res.json(dailyTip);
    } catch (error) {
      console.error("Error fetching daily health tip:", error);
      res.status(500).json({ message: "Failed to fetch daily health tip" });
    }
  });

  // Daily Challenge Generator API
  app.get('/api/daily-challenge', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: 'User not authenticated' });
      }

      const challenge = await storage.generateDailyChallenge(userId);
      res.json(challenge);
    } catch (error: any) {
      console.error("Error generating daily challenge:", error);
      res.status(500).json({ message: "Failed to generate daily challenge" });
    }
  });

  // Complete Daily Challenge API
  app.post('/api/daily-challenge/complete', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ error: 'User not authenticated' });
      }

      const { challengeId, proofText } = req.body;
      const completion = await storage.completeDailyChallenge(userId, challengeId, proofText);
      res.json(completion);
    } catch (error: any) {
      console.error("Error completing daily challenge:", error);
      res.status(500).json({ message: "Failed to complete daily challenge" });
    }
  });

  app.get('/api/health-tips/completed', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const completedTips = await storage.getUserCompletedTips(userId);
      res.json(completedTips);
    } catch (error) {
      console.error("Error fetching completed tips:", error);
      res.status(500).json({ message: "Failed to fetch completed tips" });
    }
  });

  app.post('/api/health-tips/:id/complete', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const healthTipId = parseInt(req.params.id);
      
      // Get the health tip to verify it exists and get point value
      const allTips = await storage.getAllHealthTips();
      const tip = allTips.find(t => t.id === healthTipId);
      
      if (!tip) {
        return res.status(404).json({ message: "Health tip not found" });
      }

      // Check if already completed
      const completed = await storage.getUserCompletedTips(userId);
      const alreadyCompleted = completed.some(c => c.healthTipId === healthTipId);
      
      if (alreadyCompleted) {
        return res.status(400).json({ message: "Health tip already completed" });
      }

      const completion = await storage.completeHealthTip(userId, healthTipId, tip.points);
      res.json(completion);
    } catch (error) {
      console.error("Error completing health tip:", error);
      res.status(500).json({ message: "Failed to complete health tip" });
    }
  });

  app.get('/api/health-tips/user/points', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const totalPoints = await storage.getUserTotalPoints(userId);
      res.json({ totalPoints });
    } catch (error) {
      console.error("Error fetching user points:", error);
      res.status(500).json({ message: "Failed to fetch user points" });
    }
  });

  // Initialize health tips data automatically (keep for manual trigger if needed)
  app.post('/api/health-tips/initialize', async (req, res) => {
    try {
      // Check if tips already exist
      const existingTips = await storage.getAllHealthTips();
      if (existingTips.length > 0) {
        return res.json({ message: "Health tips already initialized", count: existingTips.length });
      }

      // Import the health tips data
      const { healthTipsData } = await import('./health-tips-data');
      
      // Insert all tips into the database
      let insertCount = 0;
      for (const tipData of healthTipsData) {
        try {
          await db.insert(healthTips).values(tipData);
          insertCount++;
        } catch (error) {
          console.error(`Error inserting tip: ${tipData.title}`, error);
        }
      }

      res.json({ message: "Health tips initialized successfully", count: insertCount });
    } catch (error) {
      console.error("Error initializing health tips:", error);
      res.status(500).json({ message: "Failed to initialize health tips" });
    }
  });

  // Body symptoms routes
  app.get('/api/body-symptoms', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const symptoms = await storage.getBodySymptoms(userId);
      res.json(symptoms);
    } catch (error) {
      console.error('Error fetching body symptoms:', error);
      res.status(500).json({ message: "Failed to fetch body symptoms" });
    }
  });

  app.post('/api/body-symptoms', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const symptomData = insertBodySymptomSchema.parse({
        ...req.body,
        userId
      });
      
      const symptom = await storage.createBodySymptom(symptomData);
      res.json(symptom);
    } catch (error) {
      console.error('Error creating body symptom:', error);
      res.status(500).json({ message: "Failed to create body symptom" });
    }
  });

  app.delete('/api/body-symptoms/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const symptomId = parseInt(req.params.id);
      
      if (isNaN(symptomId)) {
        return res.status(400).json({ message: "Invalid symptom ID" });
      }
      
      await storage.deleteBodySymptom(symptomId, userId);
      res.json({ message: "Body symptom deleted successfully" });
    } catch (error) {
      console.error('Error deleting body symptom:', error);
      res.status(500).json({ message: "Failed to delete body symptom" });
    }
  });

  // Emergency contacts routes
  app.get('/api/emergency-contacts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const contacts = await storage.getEmergencyContacts(userId);
      res.json(contacts);
    } catch (error) {
      console.error('Error fetching emergency contacts:', error);
      res.status(500).json({ message: "Failed to fetch emergency contacts" });
    }
  });

  app.post('/api/emergency-contacts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const contactData = insertEmergencyContactSchema.parse({
        ...req.body,
        userId
      });
      
      const contact = await storage.createEmergencyContact(contactData);
      res.json(contact);
    } catch (error) {
      console.error('Error creating emergency contact:', error);
      res.status(500).json({ message: "Failed to create emergency contact" });
    }
  });

  app.put('/api/emergency-contacts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const contactId = parseInt(req.params.id);
      
      if (isNaN(contactId)) {
        return res.status(400).json({ message: "Invalid contact ID" });
      }

      const contactData = insertEmergencyContactSchema.partial().parse(req.body);
      const contact = await storage.updateEmergencyContact(contactId, userId, contactData);
      res.json(contact);
    } catch (error) {
      console.error('Error updating emergency contact:', error);
      res.status(500).json({ message: "Failed to update emergency contact" });
    }
  });

  app.delete('/api/emergency-contacts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const contactId = parseInt(req.params.id);
      
      if (isNaN(contactId)) {
        return res.status(400).json({ message: "Invalid contact ID" });
      }
      
      await storage.deleteEmergencyContact(contactId, userId);
      res.json({ message: "Emergency contact deleted successfully" });
    } catch (error) {
      console.error('Error deleting emergency contact:', error);
      res.status(500).json({ message: "Failed to delete emergency contact" });
    }
  });

  // Support tickets routes
  app.post('/api/support-tickets', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const ticketData = insertSupportTicketSchema.parse({
        ...req.body,
        userId
      });
      
      const ticket = await storage.createSupportTicket(ticketData);
      res.json(ticket);
    } catch (error) {
      console.error('Error creating support ticket:', error);
      res.status(500).json({ message: "Failed to create support ticket" });
    }
  });

  app.get('/api/support-tickets', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const tickets = await storage.getUserSupportTickets(userId);
      res.json(tickets);
    } catch (error) {
      console.error('Error fetching support tickets:', error);
      res.status(500).json({ message: "Failed to fetch support tickets" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
