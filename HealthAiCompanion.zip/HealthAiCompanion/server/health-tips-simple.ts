import { InsertHealthTip } from "@shared/schema";

export const simpleHealthTipsData: InsertHealthTip[] = [
  // Hydration Tips (15 points each)
  { title: "Start your day with water", content: "Drink a full glass of water immediately upon waking to kickstart your metabolism and rehydrate your body after sleep.", category: "hydration", difficulty: "easy", points: 15, tags: ["morning", "water", "metabolism"], estimatedTime: 1 },
  { title: "Carry a water bottle", content: "Keep a reusable water bottle with you throughout the day as a visual reminder to drink water regularly.", category: "hydration", difficulty: "easy", points: 15, tags: ["habit", "reminder", "hydration"], estimatedTime: 5 },
  { title: "Set hydration reminders", content: "Use your phone or smartwatch to set hourly reminders to drink water throughout the day.", category: "hydration", difficulty: "easy", points: 15, tags: ["technology", "reminder", "routine"], estimatedTime: 2 },
  { title: "Drink water before meals", content: "Consume a glass of water 30 minutes before each meal to aid digestion and help control portion sizes.", category: "hydration", difficulty: "easy", points: 15, tags: ["digestion", "portions"], estimatedTime: 1 },
  { title: "Add natural flavor to water", content: "Enhance plain water with cucumber, lemon, mint, or berries for taste variety without added sugars.", category: "hydration", difficulty: "easy", points: 15, tags: ["flavor", "natural", "variety"], estimatedTime: 3 },

  // Nutrition Tips (20-30 points each)
  { title: "Eat the rainbow daily", content: "Include fruits and vegetables of different colors in each meal to ensure diverse nutrient intake.", category: "nutrition", difficulty: "medium", points: 25, tags: ["vitamins", "variety", "colorful"], estimatedTime: 15 },
  { title: "Practice portion control", content: "Use smaller plates and measure portions with your hands - palm for protein, fist for vegetables, cupped hand for carbs.", category: "nutrition", difficulty: "medium", points: 25, tags: ["portions", "weight"], estimatedTime: 10 },
  { title: "Add fiber to every meal", content: "Include beans, whole grains, or vegetables with each meal to reach 25-35g of fiber daily for digestive health.", category: "nutrition", difficulty: "medium", points: 25, tags: ["fiber", "digestion", "gut"], estimatedTime: 15 },
  { title: "Prepare healthy snacks", content: "Pre-portion nuts, cut vegetables, or prepare fruit to avoid reaching for processed snacks when hungry.", category: "nutrition", difficulty: "easy", points: 20, tags: ["meal_prep", "snacks", "planning"], estimatedTime: 20 },
  { title: "Read nutrition labels", content: "Check ingredients and nutrition facts before purchasing packaged foods - avoid items with excessive sodium or added sugars.", category: "nutrition", difficulty: "medium", points: 25, tags: ["labels", "awareness", "shopping"], estimatedTime: 5 },

  // Exercise & Movement (25-40 points each)
  { title: "Take a 10-minute walk", content: "Go for a brisk 10-minute walk to boost circulation, mood, and energy levels.", category: "exercise", difficulty: "easy", points: 25, tags: ["walking", "cardio", "mood"], estimatedTime: 10 },
  { title: "Do bodyweight exercises", content: "Perform 10 push-ups, 15 squats, and a 30-second plank to strengthen major muscle groups.", category: "exercise", difficulty: "medium", points: 30, tags: ["strength", "bodyweight", "equipment"], estimatedTime: 15 },
  { title: "Stretch for flexibility", content: "Complete a 10-minute stretching routine focusing on major muscle groups to improve flexibility and reduce tension.", category: "exercise", difficulty: "easy", points: 25, tags: ["flexibility", "stretching", "tension"], estimatedTime: 10 },
  { title: "Take stairs instead of elevator", content: "Choose stairs over elevators or escalators throughout the day to add extra physical activity.", category: "exercise", difficulty: "easy", points: 20, tags: ["stairs", "activity"], estimatedTime: 5 },
  { title: "Try a new physical activity", content: "Experiment with yoga, dancing, swimming, or cycling to find enjoyable ways to stay active.", category: "exercise", difficulty: "medium", points: 35, tags: ["variety", "exploration", "fun"], estimatedTime: 30 },

  // Sleep & Rest (20-30 points each)
  { title: "Establish a bedtime routine", content: "Create a consistent 30-minute pre-sleep routine including dimming lights and avoiding screens.", category: "sleep", difficulty: "medium", points: 30, tags: ["routine", "hygiene"], estimatedTime: 30 },
  { title: "Optimize your sleep environment", content: "Keep your bedroom cool (65-68°F), dark, and quiet for optimal sleep quality.", category: "sleep", difficulty: "easy", points: 25, tags: ["environment", "temperature", "darkness"], estimatedTime: 10 },
  { title: "Limit screen time before bed", content: "Avoid phones, tablets, and TV for at least 1 hour before bedtime to improve sleep quality.", category: "sleep", difficulty: "medium", points: 25, tags: ["screens", "light", "wind_down"], estimatedTime: 60 },
  { title: "Try progressive muscle relaxation", content: "Practice tensing and releasing muscle groups from toes to head to reduce physical tension before sleep.", category: "sleep", difficulty: "medium", points: 25, tags: ["relaxation", "tension", "technique"], estimatedTime: 15 },
  { title: "Set a consistent sleep schedule", content: "Go to bed and wake up at the same time every day, even on weekends, to regulate your circadian rhythm.", category: "sleep", difficulty: "hard", points: 30, tags: ["schedule", "circadian", "consistency"], estimatedTime: 1 },

  // Mental Health & Stress (25-35 points each)
  { title: "Practice mindful meditation", content: "Spend 10 minutes focusing on your breath and observing thoughts without judgment.", category: "mental", difficulty: "medium", points: 30, tags: ["meditation", "mindfulness", "breath"], estimatedTime: 10 },
  { title: "Write in a gratitude journal", content: "List three things you're grateful for today to shift focus toward positive aspects of life.", category: "mental", difficulty: "easy", points: 25, tags: ["gratitude", "journaling", "positivity"], estimatedTime: 5 },
  { title: "Connect with a friend", content: "Reach out to someone you care about through a call, text, or in-person visit to strengthen social bonds.", category: "mental", difficulty: "easy", points: 25, tags: ["social", "connection", "friendship"], estimatedTime: 15 },
  { title: "Practice deep breathing", content: "Take 5 deep, slow breaths focusing on expanding your diaphragm to reduce stress and anxiety.", category: "mental", difficulty: "easy", points: 20, tags: ["breathing", "stress", "anxiety"], estimatedTime: 3 },
  { title: "Spend time in nature", content: "Go outside for at least 15 minutes, whether in a park, garden, or simply sitting under a tree.", category: "mental", difficulty: "easy", points: 30, tags: ["nature", "outdoors", "vitamin"], estimatedTime: 15 },

  // Preventive Health (30-45 points each)
  { title: "Schedule annual checkup", content: "Book your annual physical exam with your primary care doctor for preventive health screening.", category: "preventive", difficulty: "medium", points: 40, tags: ["checkup", "prevention", "doctor"], estimatedTime: 15 },
  { title: "Get recommended screenings", content: "Schedule age-appropriate screenings like mammograms, colonoscopies, or skin cancer checks.", category: "preventive", difficulty: "medium", points: 45, tags: ["screening", "cancer", "detection"], estimatedTime: 20 },
  { title: "Update your vaccinations", content: "Check with your healthcare provider about needed vaccinations including flu, COVID-19, or travel vaccines.", category: "preventive", difficulty: "easy", points: 35, tags: ["vaccines", "immunity", "prevention"], estimatedTime: 10 },
  { title: "Practice good dental hygiene", content: "Brush twice daily, floss once, and use mouthwash to prevent dental disease and maintain oral health.", category: "preventive", difficulty: "easy", points: 25, tags: ["dental", "hygiene", "oral"], estimatedTime: 5 },
  { title: "Wash hands frequently", content: "Wash hands with soap for 20 seconds, especially before eating and after using the restroom.", category: "preventive", difficulty: "easy", points: 20, tags: ["hygiene", "infection"], estimatedTime: 1 },

  // Advanced Health Tips (35-50 points each)
  { title: "Try intermittent fasting", content: "Experiment with a 16:8 eating window (fast 16 hours, eat within 8 hours) after consulting healthcare provider.", category: "advanced", difficulty: "hard", points: 45, tags: ["fasting", "eating", "metabolism"], estimatedTime: 60 },
  { title: "Learn stress management techniques", content: "Master at least one stress reduction method like yoga, tai chi, or progressive muscle relaxation.", category: "advanced", difficulty: "hard", points: 40, tags: ["stress", "yoga", "techniques"], estimatedTime: 45 },
  { title: "Optimize your gut health", content: "Include fermented foods, probiotics, and prebiotic-rich foods to support digestive and immune health.", category: "advanced", difficulty: "medium", points: 35, tags: ["gut", "probiotics", "fermented"], estimatedTime: 20 },
  { title: "Track your biomarkers", content: "Get comprehensive blood work done and track key markers like cholesterol, blood sugar, and inflammation.", category: "advanced", difficulty: "hard", points: 50, tags: ["biomarkers", "blood", "tracking"], estimatedTime: 30 },

  // Daily Habits (15-25 points each)
  { title: "Make your bed", content: "Start your day by making your bed to create a sense of accomplishment and order.", category: "habits", difficulty: "easy", points: 15, tags: ["morning", "accomplishment"], estimatedTime: 3 },
  { title: "Take vitamin D", content: "Take a vitamin D supplement or spend 15-20 minutes in sunlight to support bone and immune health.", category: "habits", difficulty: "easy", points: 20, tags: ["vitamin", "supplements", "sunlight"], estimatedTime: 1 },
  { title: "Plan your meals", content: "Spend 10 minutes planning your meals for the day to make healthier choices and reduce decision fatigue.", category: "habits", difficulty: "easy", points: 20, tags: ["planning", "meals", "preparation"], estimatedTime: 10 },
  { title: "Take regular breaks", content: "Set a timer to take a 5-minute break every hour to stretch, breathe, and rest your eyes.", category: "habits", difficulty: "easy", points: 15, tags: ["breaks", "productivity", "rest"], estimatedTime: 5 },
  { title: "Practice gratitude", content: "Before bed, think of three specific things you're grateful for from your day.", category: "habits", difficulty: "easy", points: 20, tags: ["gratitude", "evening", "reflection"], estimatedTime: 5 }
];