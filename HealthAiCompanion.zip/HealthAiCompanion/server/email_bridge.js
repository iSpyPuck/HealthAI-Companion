// Bridge between JavaScript and Python email service
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * send email with python
 * @param {Object} params - Email parameters
 * @param {string} params.to - Recipient email
 * @param {string} params.subject - Email subject
 * @param {string} params.text - Plain text content
 * @param {string} params.html - HTML content
 * @returns {Promise<boolean>} - Success status
 */
export async function sendEmail(params) {
  return new Promise((resolve) => {
    const pythonScript = join(__dirname, 'email.py');
    
    // Create Python process
    const python = spawn('python3', [pythonScript], {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: {
        ...process.env,
        PYTHONPATH: __dirname
      }
    });
    
    // Send email data to Python script
    const emailData = {
      to_email: params.to,
      subject: params.subject,
      text_content: params.text,
      html_content: params.html
    };
    
    python.stdin.write(JSON.stringify(emailData));
    python.stdin.end();
    
    let output = '';
    let error = '';
    
    python.stdout.on('data', (data) => {
      output += data.toString();
    });
    
    python.stderr.on('data', (data) => {
      error += data.toString();
    });
    
    python.on('close', (code) => {
      if (code === 0) {
        console.log('Python email service output:', output);
        resolve(true);
      } else {
        console.error('Python email service error:', error);
        resolve(false);
      }
    });
    
    python.on('error', (err) => {
      console.error('Failed to start Python email service:', err);
      resolve(false);
    });
  });
}

/**
 * send email to check user
 * @param {string} email - Recipient email
 * @param {string} token - Verification token
 * @returns {Promise<boolean>} - Success status
 */
export async function sendVerificationEmail(email, token) {
  return new Promise((resolve) => {
    const pythonScript = join(__dirname, 'email.py');
    
    const python = spawn('python3', [pythonScript], {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: {
        ...process.env,
        PYTHONPATH: __dirname
      }
    });
    
    const emailData = {
      action: 'verify',
      email: email,
      token: token
    };
    
    python.stdin.write(JSON.stringify(emailData));
    python.stdin.end();
    
    let output = '';
    let error = '';
    
    python.stdout.on('data', (data) => {
      output += data.toString();
    });
    
    python.stderr.on('data', (data) => {
      error += data.toString();
    });
    
    python.on('close', (code) => {
      if (code === 0) {
        console.log('Verification email sent successfully');
        resolve(true);
      } else {
        console.error('Failed to send verification email:', error);
        resolve(false);
      }
    });
    
    python.on('error', (err) => {
      console.error('Failed to start Python email service:', err);
      resolve(false);
    });
  });
}

/**
 * Send password reset email
 * @param {string} email - Recipient email
 * @param {string} token - Reset token
 * @returns {Promise<boolean>} - Success status
 */
export async function sendPasswordResetEmail(email, token) {
  return new Promise((resolve) => {
    const pythonScript = join(__dirname, 'email.py');
    
    const python = spawn('python3', [pythonScript], {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: {
        ...process.env,
        PYTHONPATH: __dirname
      }
    });
    
    const emailData = {
      action: 'reset',
      email: email,
      token: token
    };
    
    python.stdin.write(JSON.stringify(emailData));
    python.stdin.end();
    
    let output = '';
    let error = '';
    
    python.stdout.on('data', (data) => {
      output += data.toString();
    });
    
    python.stderr.on('data', (data) => {
      error += data.toString();
    });
    
    python.on('close', (code) => {
      if (code === 0) {
        console.log('Password reset email sent successfully');
        resolve(true);
      } else {
        console.error('Failed to send password reset email:', error);
        resolve(false);
      }
    });
    
    python.on('error', (err) => {
      console.error('Failed to start Python email service:', err);
      resolve(false);
    });
  });
}