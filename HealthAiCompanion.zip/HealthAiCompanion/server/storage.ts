import {
  users,
  conversations,
  messages,
  healthRecords,
  medications,
  medicationReminders,
  appointments,
  appointmentSlots,
  symptomAnalyses,
  habits,
  habitLogs,
  userCharacter,
  achievements,
  type User,
  type UpsertUser,
  type InsertConversation,
  type Conversation,
  type InsertMessage,
  type Message,
  type InsertHealthRecord,
  type HealthRecord,
  type InsertMedication,
  type Medication,
  type InsertMedicationReminder,
  type MedicationReminder,
  type Appointment,
  type InsertAppointment,
  type AppointmentSlot,
  type InsertAppointmentSlot,
  type InsertSymptomAnalysis,
  type SymptomAnalysis,
  type InsertHabit,
  type Habit,
  type InsertHabitLog,
  type HabitLog,
  type InsertUserCharacter,
  type UserCharacter,
  type InsertAchievement,
  type Achievement,
  healthTips,
  userHealthTipCompletions,
  type HealthTip,
  type InsertHealthTip,
  type UserHealthTipCompletion,
  type InsertUserHealthTipCompletion,
  dailyChallenges,
  type DailyChallenge,
  type InsertDailyChallenge,
  bodySymptoms,
  type BodySymptom,
  type InsertBodySymptom,
  emergencyContacts,
  type EmergencyContact,
  type InsertEmergencyContact,
  supportTickets,
  type SupportTicket,
  type InsertSupportTicket,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // user stuff - Email/password auth uses integer IDs
  getUser(id: number): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Legacy methods for backward compatibility - not used with Replit Auth
  getUserByEmail?(email: string): Promise<User | undefined>;
  getUserByVerificationToken?(token: string): Promise<User | undefined>;
  getUserByResetToken?(token: string): Promise<User | undefined>;
  createUser?(user: UpsertUser): Promise<User>;
  verifyUserEmail?(id: string): Promise<void>;
  setPasswordResetToken?(id: string, token: string, expires: Date): Promise<void>;
  resetUserPassword?(id: string, password: string): Promise<void>;
  updateVerificationToken?(id: string, token: string, expires: Date): Promise<void>;
  
  // chat stuff
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  getConversations(userId: number): Promise<Conversation[]>;
  getConversation(id: number): Promise<Conversation | undefined>;
  
  // message stuff
  createMessage(message: InsertMessage): Promise<Message>;
  getMessages(conversationId: number): Promise<Message[]>;
  
  // health record stuff
  createHealthRecord(record: InsertHealthRecord): Promise<HealthRecord>;
  getHealthRecords(userId: number): Promise<HealthRecord[]>;
  deleteHealthRecord(id: number, userId: number): Promise<void>;
  
  // medicine stuff
  createMedication(medication: InsertMedication): Promise<Medication>;
  getMedications(userId: number): Promise<Medication[]>;
  updateMedication(id: number, medication: Partial<InsertMedication>): Promise<Medication>;
  deleteMedication(id: number, userId: number): Promise<void>;
  
  // medicine reminder stuff
  createMedicationReminder(reminder: InsertMedicationReminder): Promise<MedicationReminder>;
  getMedicationReminders(userId: number, startDate: Date, endDate: Date): Promise<MedicationReminder[]>;
  updateMedicationReminder(id: number, reminder: Partial<InsertMedicationReminder>): Promise<MedicationReminder>;
  
  // appointment stuff
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  getAppointments(userId: number): Promise<Appointment[]>;
  getAppointment(id: number): Promise<Appointment | undefined>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment>;
  deleteAppointment(id: number, userId: number): Promise<void>;
  
  // appointment slot stuff
  createAppointmentSlot(slot: InsertAppointmentSlot): Promise<AppointmentSlot>;
  getAvailableSlots(doctorSpecialty?: string, startDate?: Date, endDate?: Date): Promise<AppointmentSlot[]>;
  updateAppointmentSlot(id: number, slot: Partial<InsertAppointmentSlot>): Promise<AppointmentSlot>;
  
  // symptom analysis stuff
  createSymptomAnalysis(analysis: InsertSymptomAnalysis): Promise<SymptomAnalysis>;
  getSymptomAnalyses(userId: number): Promise<SymptomAnalysis[]>;
  getSymptomAnalysis(id: number): Promise<SymptomAnalysis | undefined>;

  // habit tracker stuff
  createHabit(habit: InsertHabit): Promise<Habit>;
  getHabits(userId: number): Promise<Habit[]>;
  updateHabit(id: number, habit: Partial<InsertHabit>): Promise<Habit>;
  deleteHabit(id: number, userId: number): Promise<void>;
  
  // habit log stuff
  createHabitLog(log: InsertHabitLog): Promise<HabitLog>;
  getHabitLogs(userId: number, startDate?: Date, endDate?: Date): Promise<HabitLog[]>;
  getHabitLogsByHabit(habitId: number, startDate?: Date, endDate?: Date): Promise<HabitLog[]>;
  
  // user character stuff
  getUserCharacter(userId: number): Promise<UserCharacter | undefined>;
  createUserCharacter(character: InsertUserCharacter): Promise<UserCharacter>;
  updateUserCharacter(userId: number, character: Partial<InsertUserCharacter>): Promise<UserCharacter>;
  
  // achievement stuff
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  getAchievements(userId: number): Promise<Achievement[]>;
  
  // health tips stuff
  getAllHealthTips(): Promise<HealthTip[]>;
  getHealthTipsByCategory(category: string): Promise<HealthTip[]>;
  getUserCompletedTips(userId: number): Promise<UserHealthTipCompletion[]>;
  completeHealthTip(userId: number, healthTipId: number, pointsEarned: number): Promise<UserHealthTipCompletion>;
  getUserTotalPoints(userId: number): Promise<number>;
  initializeHealthTipsIfNeeded(): Promise<void>;
  forceReloadHealthTips(): Promise<void>;
  getDailyHealthTip(): Promise<HealthTip>;

  // daily challenges stuff
  generateDailyChallenge(userId: number): Promise<DailyChallenge>;
  completeDailyChallenge(userId: number, challengeId: number, proofText?: string): Promise<DailyChallenge>;
  getUserDailyChallenges(userId: number): Promise<DailyChallenge[]>;
  
  // body symptoms stuff
  createBodySymptom(symptom: InsertBodySymptom): Promise<BodySymptom>;
  getBodySymptoms(userId: number): Promise<BodySymptom[]>;
  deleteBodySymptom(id: number, userId: number): Promise<void>;
  
  // emergency contacts stuff
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  getEmergencyContacts(userId: number): Promise<EmergencyContact[]>;
  updateEmergencyContact(id: number, userId: number, contact: Partial<InsertEmergencyContact>): Promise<EmergencyContact>;
  deleteEmergencyContact(id: number, userId: number): Promise<void>;
  
  // support tickets stuff
  createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket>;
  getUserSupportTickets(userId: number): Promise<SupportTicket[]>;
  updateSupportTicket(id: number, userId: number, ticket: Partial<InsertSupportTicket>): Promise<SupportTicket>;
}

export class DatabaseStorage implements IStorage {
  // User operations for email/password auth

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByVerificationToken(token: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.emailVerificationToken, token));
    return user;
  }

  async getUserByResetToken(token: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.passwordResetToken, token));
    return user;
  }

  async createUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();
    return user;
  }

  async verifyUserEmail(id: string): Promise<void> {
    await db.update(users).set({ 
      isEmailVerified: true, 
      emailVerificationToken: null,
      emailVerificationExpires: null 
    }).where(eq(users.id, parseInt(id)));
  }

  async setPasswordResetToken(id: string, token: string, expires: Date): Promise<void> {
    await db.update(users).set({ 
      passwordResetToken: token,
      passwordResetExpires: expires 
    }).where(eq(users.id, parseInt(id)));
  }

  async resetUserPassword(id: string, password: string): Promise<void> {
    await db.update(users).set({ 
      password: password,
      passwordResetToken: null,
      passwordResetExpires: null 
    }).where(eq(users.id, parseInt(id)));
  }

  async updateVerificationToken(id: string, token: string, expires: Date): Promise<void> {
    await db.update(users).set({ 
      emailVerificationToken: token,
      emailVerificationExpires: expires 
    }).where(eq(users.id, parseInt(id)));
  }

  // Conversation operations
  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const [result] = await db
      .insert(conversations)
      .values(conversation)
      .returning();
    return result;
  }

  async getConversations(userId: number): Promise<Conversation[]> {
    return await db
      .select()
      .from(conversations)
      .where(eq(conversations.userId, userId))
      .orderBy(desc(conversations.updatedAt));
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    const [conversation] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, id));
    return conversation;
  }

  // Message operations
  async createMessage(message: InsertMessage): Promise<Message> {
    const [result] = await db
      .insert(messages)
      .values(message)
      .returning();
    return result;
  }

  async getMessages(conversationId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.timestamp);
  }

  // Health record operations
  async createHealthRecord(record: InsertHealthRecord): Promise<HealthRecord> {
    const [result] = await db
      .insert(healthRecords)
      .values(record)
      .returning();
    return result;
  }

  async getHealthRecords(userId: number): Promise<HealthRecord[]> {
    return await db
      .select()
      .from(healthRecords)
      .where(eq(healthRecords.userId, userId))
      .orderBy(desc(healthRecords.uploadedAt));
  }

  async deleteHealthRecord(id: number, userId: number): Promise<void> {
    await db
      .delete(healthRecords)
      .where(and(eq(healthRecords.id, id), eq(healthRecords.userId, userId)));
  }

  // Medication operations
  async createMedication(medication: InsertMedication): Promise<Medication> {
    const [result] = await db
      .insert(medications)
      .values(medication)
      .returning();
    return result;
  }

  async getMedications(userId: number): Promise<Medication[]> {
    return await db
      .select()
      .from(medications)
      .where(and(eq(medications.userId, userId), eq(medications.isActive, true)))
      .orderBy(medications.name);
  }

  async updateMedication(id: number, medication: Partial<InsertMedication>): Promise<Medication> {
    const [result] = await db
      .update(medications)
      .set(medication)
      .where(eq(medications.id, id))
      .returning();
    return result;
  }

  async deleteMedication(id: number, userId: number): Promise<void> {
    await db
      .update(medications)
      .set({ isActive: false })
      .where(and(eq(medications.id, id), eq(medications.userId, userId)));
  }

  // Medication reminder operations
  async createMedicationReminder(reminder: InsertMedicationReminder): Promise<MedicationReminder> {
    const [result] = await db
      .insert(medicationReminders)
      .values(reminder)
      .returning();
    return result;
  }

  async getMedicationReminders(userId: number, startDate: Date, endDate: Date): Promise<MedicationReminder[]> {
    return await db
      .select({
        id: medicationReminders.id,
        medicationId: medicationReminders.medicationId,
        scheduledTime: medicationReminders.scheduledTime,
        takenAt: medicationReminders.takenAt,
        isTaken: medicationReminders.isTaken,
        isMissed: medicationReminders.isMissed,
        createdAt: medicationReminders.createdAt,
        medication: medications,
      })
      .from(medicationReminders)
      .innerJoin(medications, eq(medicationReminders.medicationId, medications.id))
      .where(
        and(
          eq(medications.userId, userId),
          gte(medicationReminders.scheduledTime, startDate),
          lte(medicationReminders.scheduledTime, endDate)
        )
      )
      .orderBy(medicationReminders.scheduledTime);
  }

  async updateMedicationReminder(id: number, reminder: Partial<InsertMedicationReminder>): Promise<MedicationReminder> {
    const [result] = await db
      .update(medicationReminders)
      .set(reminder)
      .where(eq(medicationReminders.id, id))
      .returning();
    return result;
  }

  // Appointment operations
  async createAppointment(appointmentData: InsertAppointment): Promise<Appointment> {
    const [appointment] = await db
      .insert(appointments)
      .values({
        ...appointmentData,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();
    return appointment;
  }

  async getAppointments(userId: number): Promise<Appointment[]> {
    return await db
      .select()
      .from(appointments)
      .where(eq(appointments.userId, userId))
      .orderBy(desc(appointments.appointmentDate));
  }

  async getAppointment(id: number): Promise<Appointment | undefined> {
    const [appointment] = await db
      .select()
      .from(appointments)
      .where(eq(appointments.id, id));
    return appointment;
  }

  async updateAppointment(id: number, appointmentData: Partial<InsertAppointment>): Promise<Appointment> {
    const [updated] = await db
      .update(appointments)
      .set({ ...appointmentData, updatedAt: new Date() })
      .where(eq(appointments.id, id))
      .returning();
    return updated;
  }

  async deleteAppointment(id: number, userId: number): Promise<void> {
    await db
      .delete(appointments)
      .where(and(eq(appointments.id, id), eq(appointments.userId, userId)));
  }

  // Appointment slot operations
  async createAppointmentSlot(slotData: InsertAppointmentSlot): Promise<AppointmentSlot> {
    const [slot] = await db
      .insert(appointmentSlots)
      .values({
        ...slotData,
        createdAt: new Date(),
      })
      .returning();
    return slot;
  }

  async getAvailableSlots(doctorSpecialty?: string, startDate?: Date, endDate?: Date): Promise<AppointmentSlot[]> {
    let whereConditions = [eq(appointmentSlots.isAvailable, true)];

    if (doctorSpecialty) {
      whereConditions.push(eq(appointmentSlots.doctorSpecialty, doctorSpecialty));
    }

    if (startDate && endDate) {
      whereConditions.push(
        gte(appointmentSlots.slotDate, startDate),
        lte(appointmentSlots.slotDate, endDate)
      );
    }

    return await db
      .select()
      .from(appointmentSlots)
      .where(and(...whereConditions))
      .orderBy(appointmentSlots.slotDate);
  }

  async updateAppointmentSlot(id: number, slotData: Partial<InsertAppointmentSlot>): Promise<AppointmentSlot> {
    const [updated] = await db
      .update(appointmentSlots)
      .set(slotData)
      .where(eq(appointmentSlots.id, id))
      .returning();
    return updated;
  }

  // Symptom analysis operations
  async createSymptomAnalysis(analysis: InsertSymptomAnalysis): Promise<SymptomAnalysis> {
    const [result] = await db
      .insert(symptomAnalyses)
      .values({
        ...analysis,
        createdAt: new Date(),
      })
      .returning();
    return result;
  }

  async getSymptomAnalyses(userId: number): Promise<SymptomAnalysis[]> {
    return await db
      .select()
      .from(symptomAnalyses)
      .where(eq(symptomAnalyses.userId, userId))
      .orderBy(desc(symptomAnalyses.createdAt));
  }

  async getSymptomAnalysis(id: number): Promise<SymptomAnalysis | undefined> {
    const [analysis] = await db
      .select()
      .from(symptomAnalyses)
      .where(eq(symptomAnalyses.id, id));
    return analysis;
  }

  // Habit tracker methods
  async createHabit(habitData: InsertHabit): Promise<Habit> {
    const [habit] = await db
      .insert(habits)
      .values(habitData)
      .returning();
    return habit;
  }

  async getHabits(userId: number): Promise<Habit[]> {
    return await db
      .select()
      .from(habits)
      .where(and(eq(habits.userId, userId), eq(habits.isActive, true)))
      .orderBy(desc(habits.createdAt));
  }

  async updateHabit(id: number, habitData: Partial<InsertHabit>): Promise<Habit> {
    const [habit] = await db
      .update(habits)
      .set({ ...habitData, updatedAt: new Date() })
      .where(eq(habits.id, id))
      .returning();
    return habit;
  }

  async deleteHabit(id: number, userId: number): Promise<void> {
    await db
      .update(habits)
      .set({ isActive: false, updatedAt: new Date() })
      .where(and(eq(habits.id, id), eq(habits.userId, userId)));
  }

  async createHabitLog(logData: InsertHabitLog): Promise<HabitLog> {
    const [log] = await db
      .insert(habitLogs)
      .values(logData)
      .returning();
    return log;
  }

  async getHabitLogs(userId: number, startDate?: Date, endDate?: Date): Promise<HabitLog[]> {
    const conditions = [eq(habitLogs.userId, userId)];
    
    if (startDate) {
      conditions.push(gte(habitLogs.completedAt, startDate));
    }
    if (endDate) {
      conditions.push(lte(habitLogs.completedAt, endDate));
    }

    return await db
      .select()
      .from(habitLogs)
      .where(and(...conditions))
      .orderBy(desc(habitLogs.completedAt));
  }

  async getHabitLogsByHabit(habitId: number, startDate?: Date, endDate?: Date): Promise<HabitLog[]> {
    const conditions = [eq(habitLogs.habitId, habitId)];
    
    if (startDate) {
      conditions.push(gte(habitLogs.completedAt, startDate));
    }
    if (endDate) {
      conditions.push(lte(habitLogs.completedAt, endDate));
    }

    return await db
      .select()
      .from(habitLogs)
      .where(and(...conditions))
      .orderBy(desc(habitLogs.completedAt));
  }

  async getUserCharacter(userId: number): Promise<UserCharacter | undefined> {
    const [character] = await db
      .select()
      .from(userCharacter)
      .where(eq(userCharacter.userId, userId));
    return character;
  }

  async createUserCharacter(characterData: InsertUserCharacter): Promise<UserCharacter> {
    const [character] = await db
      .insert(userCharacter)
      .values(characterData)
      .returning();
    return character;
  }

  async updateUserCharacter(userId: number, characterData: Partial<InsertUserCharacter>): Promise<UserCharacter> {
    const [character] = await db
      .update(userCharacter)
      .set({ ...characterData, updatedAt: new Date(), lastActivity: new Date() })
      .where(eq(userCharacter.userId, userId))
      .returning();
    return character;
  }

  async createAchievement(achievementData: InsertAchievement): Promise<Achievement> {
    const [achievement] = await db
      .insert(achievements)
      .values(achievementData)
      .returning();
    return achievement;
  }

  async getAchievements(userId: number): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements)
      .where(eq(achievements.userId, userId))
      .orderBy(desc(achievements.unlockedAt));
  }

  // Health Tips methods
  async getAllHealthTips(): Promise<HealthTip[]> {
    return await db
      .select()
      .from(healthTips)
      .where(eq(healthTips.isActive, true))
      .orderBy(healthTips.category, healthTips.difficulty, healthTips.points);
  }

  async getHealthTipsByCategory(category: string): Promise<HealthTip[]> {
    return await db
      .select()
      .from(healthTips)
      .where(and(eq(healthTips.category, category), eq(healthTips.isActive, true)))
      .orderBy(healthTips.difficulty, healthTips.points);
  }

  async getUserCompletedTips(userId: number): Promise<UserHealthTipCompletion[]> {
    return await db
      .select()
      .from(userHealthTipCompletions)
      .where(eq(userHealthTipCompletions.userId, userId))
      .orderBy(desc(userHealthTipCompletions.completedAt));
  }

  async completeHealthTip(userId: number, healthTipId: number, pointsEarned: number): Promise<UserHealthTipCompletion> {
    const [completion] = await db
      .insert(userHealthTipCompletions)
      .values({
        userId,
        healthTipId,
        pointsEarned,
        completedAt: new Date(),
      })
      .returning();

    // Update user character XP
    const userCharacter = await this.getUserCharacter(userId);
    if (userCharacter) {
      await this.updateUserCharacter(userId, {
        experience: (userCharacter.experience || 0) + pointsEarned,
      });
    }

    return completion;
  }

  async getUserTotalPoints(userId: number): Promise<number> {
    const result = await db
      .select()
      .from(userHealthTipCompletions)
      .where(eq(userHealthTipCompletions.userId, userId));
    
    return result.reduce((total, completion) => total + completion.pointsEarned, 0);
  }

  async initializeHealthTipsIfNeeded(): Promise<void> {
    try {
      const existingTips = await this.getAllHealthTips();
      if (existingTips.length > 0) {
        console.log(`Health tips already initialized: ${existingTips.length} tips found`);
        return;
      }

      console.log('Initializing health tips database with massive dataset...');
      const { massiveHealthTipsData } = await import('./massive-health-tips');
      
      // Insert the massive dataset in batches for better performance
      const batchSize = 100;
      let insertCount = 0;
      
      for (let i = 0; i < massiveHealthTipsData.length; i += batchSize) {
        const batch = massiveHealthTipsData.slice(i, i + batchSize);
        try {
          await db.insert(healthTips).values(batch);
          insertCount += batch.length;
        } catch (error) {
          console.error(`Error inserting batch ${Math.floor(i/batchSize) + 1}:`, error);
          // If batch fails, try individually
          for (const tipData of batch) {
            try {
              await db.insert(healthTips).values(tipData);
              insertCount++;
            } catch (tipError) {
              console.error(`Error inserting tip: ${tipData.title}`, tipError);
            }
          }
        }
      }

      console.log(`Successfully initialized ${insertCount} health tips`);
    } catch (error) {
      console.error('Error initializing health tips:', error);
    }
  }

  async getDailyHealthTip(): Promise<HealthTip> {
    try {
      // Get all active health tips
      const allTips = await db
        .select()
        .from(healthTips)
        .where(eq(healthTips.isActive, true));

      if (allTips.length === 0) {
        throw new Error('No health tips available');
      }

      // Use current date to select a consistent daily tip
      const today = new Date();
      const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
      
      // Select tip based on day of year for consistency
      const tipIndex = dayOfYear % allTips.length;
      return allTips[tipIndex];
    } catch (error) {
      console.error('Error fetching daily health tip:', error);
      throw error;
    }
  }

  // Daily Challenges Implementation
  async generateDailyChallenge(userId: number): Promise<DailyChallenge> {
    try {
      // Check if user already has a challenge for today
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const [existingChallenge] = await db
        .select()
        .from(dailyChallenges)
        .where(
          and(
            eq(dailyChallenges.userId, userId),
            gte(dailyChallenges.dateGenerated, today),
            lte(dailyChallenges.dateGenerated, tomorrow)
          )
        );

      if (existingChallenge) {
        return existingChallenge;
      }

      // Generate AI-powered personalized challenge
      const challengeData = await this.generatePersonalizedChallenge(userId);
      
      const expiresAt = new Date();
      expiresAt.setHours(23, 59, 59, 999); // End of today

      const [newChallenge] = await db
        .insert(dailyChallenges)
        .values({
          userId,
          title: challengeData.title,
          description: challengeData.description,
          category: challengeData.category,
          difficulty: challengeData.difficulty,
          points: challengeData.points,
          expiresAt,
          tags: challengeData.tags || [],
          aiGenerated: true,
        })
        .returning();

      return newChallenge;
    } catch (error) {
      console.error('Error generating daily challenge:', error);
      throw error;
    }
  }

  async completeDailyChallenge(userId: number, challengeId: number, proofText?: string): Promise<DailyChallenge> {
    try {
      const [updatedChallenge] = await db
        .update(dailyChallenges)
        .set({
          isCompleted: true,
          completedAt: new Date(),
          proofText: proofText || null,
        })
        .where(
          and(
            eq(dailyChallenges.id, challengeId),
            eq(dailyChallenges.userId, userId)
          )
        )
        .returning();

      // Award points to user character
      if (updatedChallenge) {
        const userCharacter = await this.getUserCharacter(userId);
        if (userCharacter) {
          await this.updateUserCharacter(userId, {
            experience: (userCharacter.experience || 0) + updatedChallenge.points,
          });
        }
      }

      return updatedChallenge;
    } catch (error) {
      console.error('Error completing daily challenge:', error);
      throw error;
    }
  }

  async getUserDailyChallenges(userId: number): Promise<DailyChallenge[]> {
    try {
      return await db
        .select()
        .from(dailyChallenges)
        .where(eq(dailyChallenges.userId, userId))
        .orderBy(desc(dailyChallenges.dateGenerated))
        .limit(30); // Last 30 challenges
    } catch (error) {
      console.error('Error fetching user daily challenges:', error);
      throw error;
    }
  }

  private async generatePersonalizedChallenge(userId: number): Promise<{
    title: string;
    description: string;
    category: string;
    difficulty: string;
    points: number;
    tags?: string[];
  }> {
    // Get user data for personalization
    const user = await this.getUser(userId);
    const userHabits = await this.getHabits(userId);
    const recentCompletions = await this.getUserCompletedTips(userId);

    const challengeCategories = [
      'hydration', 'exercise', 'nutrition', 'sleep', 'mental', 'habits', 'social', 'preventive'
    ];

    // Simple deterministic selection based on user ID and date for consistency
    const today = new Date();
    const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
    const categoryIndex = (userId + dayOfYear) % challengeCategories.length;
    const selectedCategory = challengeCategories[categoryIndex];

    const challenges = {
      hydration: [
        {
          title: "Hydration Hero Challenge",
          description: "Drink 8 glasses of water throughout the day and track your intake. Notice how proper hydration affects your energy levels.",
          difficulty: "easy",
          points: 30,
          tags: ["water", "tracking", "health"]
        },
        {
          title: "Infused Water Explorer",
          description: "Create a delicious infused water combination using fruits, herbs, or vegetables. Try cucumber-mint or lemon-ginger!",
          difficulty: "medium",
          points: 40,
          tags: ["creativity", "flavor", "hydration"]
        }
      ],
      exercise: [
        {
          title: "10-Minute Movement Boost",
          description: "Take three 10-minute movement breaks today. This could be walking, stretching, dancing, or any activity that gets you moving.",
          difficulty: "easy",
          points: 35,
          tags: ["movement", "breaks", "energy"]
        },
        {
          title: "Stairs Champion",
          description: "Take the stairs instead of elevators today. If you work from home, do 5 sets of stair climbing or step-ups.",
          difficulty: "medium",
          points: 45,
          tags: ["cardio", "strength", "daily habits"]
        }
      ],
      nutrition: [
        {
          title: "Rainbow Plate Challenge",
          description: "Include at least 5 different colored fruits or vegetables in your meals today. Each color provides unique nutrients!",
          difficulty: "medium",
          points: 40,
          tags: ["variety", "colors", "nutrients"]
        },
        {
          title: "Mindful Eating Moment",
          description: "Eat one meal today without any distractions - no phone, TV, or computer. Focus on the flavors, textures, and experience.",
          difficulty: "easy",
          points: 30,
          tags: ["mindfulness", "focus", "awareness"]
        }
      ],
      sleep: [
        {
          title: "Digital Sunset Challenge",
          description: "Put away all screens 1 hour before your planned bedtime. Use this time for reading, relaxation, or gentle stretching.",
          difficulty: "medium",
          points: 45,
          tags: ["screen-time", "routine", "relaxation"]
        },
        {
          title: "Perfect Sleep Environment",
          description: "Optimize your bedroom for sleep: cool temperature, dark room, comfortable bedding. Notice the difference in sleep quality.",
          difficulty: "easy",
          points: 35,
          tags: ["environment", "comfort", "quality"]
        }
      ],
      mental: [
        {
          title: "Gratitude Power-Up",
          description: "Write down 5 specific things you're grateful for today. Be detailed about why each one matters to you.",
          difficulty: "easy",
          points: 30,
          tags: ["gratitude", "positivity", "reflection"]
        },
        {
          title: "Mindful Moments Challenge",
          description: "Practice 3 one-minute mindfulness sessions throughout your day. Focus on your breath and present moment awareness.",
          difficulty: "medium",
          points: 40,
          tags: ["mindfulness", "stress-relief", "presence"]
        }
      ],
      habits: [
        {
          title: "Habit Stack Master",
          description: "Choose an existing habit and stack a new healthy behavior right after it. Practice this combination 3 times today.",
          difficulty: "medium",
          points: 50,
          tags: ["habit-stacking", "routine", "consistency"]
        },
        {
          title: "Environment Design Challenge",
          description: "Make one small change to your environment that will make a healthy choice easier. Move healthy snacks to eye level, lay out workout clothes, etc.",
          difficulty: "easy",
          points: 35,
          tags: ["environment", "design", "automation"]
        }
      ],
      social: [
        {
          title: "Connection Catalyst",
          description: "Reach out to someone you care about with a meaningful message or call. Focus on how they're doing and share genuine interest.",
          difficulty: "easy",
          points: 40,
          tags: ["relationships", "connection", "communication"]
        },
        {
          title: "Acts of Kindness",
          description: "Perform 3 small acts of kindness today. These can be for strangers, friends, family, or even yourself.",
          difficulty: "medium",
          points: 45,
          tags: ["kindness", "compassion", "community"]
        }
      ],
      preventive: [
        {
          title: "Health Check Champion",
          description: "Schedule or complete one preventive health task: book a checkup, take vitamins, do a self-exam, or update your health records.",
          difficulty: "medium",
          points: 50,
          tags: ["prevention", "planning", "proactive"]
        },
        {
          title: "Posture Reset Challenge",
          description: "Set 5 reminders throughout your day to check and correct your posture. Notice how proper alignment affects your energy and mood.",
          difficulty: "easy",
          points: 30,
          tags: ["posture", "awareness", "ergonomics"]
        }
      ]
    };

    const categoryChallenge = challenges[selectedCategory as keyof typeof challenges] || challenges.hydration;
    const challengeIndex = (userId + dayOfYear + 1) % categoryChallenge.length;
    const selectedChallenge = categoryChallenge[challengeIndex];

    return {
      ...selectedChallenge,
      category: selectedCategory,
    };
  }

  async forceReloadHealthTips(): Promise<void> {
    try {
      console.log('Force reloading health tips database with massive dataset...');
      
      // Clear user completions first due to foreign key constraint
      await db.delete(userHealthTipCompletions);
      console.log('Cleared user health tip completions');
      
      // Then clear existing health tips
      await db.delete(healthTips);
      console.log('Cleared existing health tips');
      
      // Load the comprehensive 900+ tips data
      const { massiveHealthTipsData } = await import('./massive-health-tips');
      
      // Insert in batches for better performance
      const batchSize = 50;
      let insertCount = 0;
      
      for (let i = 0; i < massiveHealthTipsData.length; i += batchSize) {
        const batch = massiveHealthTipsData.slice(i, i + batchSize);
        try {
          await db.insert(healthTips).values(batch);
          insertCount += batch.length;
          console.log(`Inserted batch ${Math.floor(i/batchSize) + 1}: ${batch.length} tips`);
        } catch (error) {
          console.error(`Error inserting batch ${Math.floor(i/batchSize) + 1}:`, error);
          
          // If batch fails, try inserting individually
          for (const tipData of batch) {
            try {
              await db.insert(healthTips).values(tipData);
              insertCount++;
            } catch (tipError) {
              console.error(`Error inserting tip: ${tipData.title}`, tipError);
            }
          }
        }
      }

      console.log(`Successfully force reloaded ${insertCount} health tips with multiple categories support`);
    } catch (error) {
      console.error('Error force reloading health tips:', error);
      throw error;
    }
  }

  // Body symptoms implementation
  async createBodySymptom(symptomData: InsertBodySymptom): Promise<BodySymptom> {
    try {
      const [symptom] = await db
        .insert(bodySymptoms)
        .values({
          ...symptomData,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();
      return symptom;
    } catch (error) {
      console.error('Error creating body symptom:', error);
      throw error;
    }
  }

  async getBodySymptoms(userId: number): Promise<BodySymptom[]> {
    try {
      const symptoms = await db
        .select()
        .from(bodySymptoms)
        .where(eq(bodySymptoms.userId, userId))
        .orderBy(desc(bodySymptoms.createdAt));
      return symptoms;
    } catch (error) {
      console.error('Error fetching body symptoms:', error);
      throw error;
    }
  }

  async deleteBodySymptom(id: number, userId: number): Promise<void> {
    try {
      await db
        .delete(bodySymptoms)
        .where(and(eq(bodySymptoms.id, id), eq(bodySymptoms.userId, userId)));
    } catch (error) {
      console.error('Error deleting body symptom:', error);
      throw error;
    }
  }

  // Emergency contacts implementation
  async createEmergencyContact(contactData: InsertEmergencyContact): Promise<EmergencyContact> {
    try {
      const [contact] = await db
        .insert(emergencyContacts)
        .values({
          ...contactData,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();
      return contact;
    } catch (error) {
      console.error('Error creating emergency contact:', error);
      throw error;
    }
  }

  async getEmergencyContacts(userId: number): Promise<EmergencyContact[]> {
    try {
      const contacts = await db
        .select()
        .from(emergencyContacts)
        .where(eq(emergencyContacts.userId, userId))
        .orderBy(desc(emergencyContacts.isPrimary), desc(emergencyContacts.medicalContact));
      return contacts;
    } catch (error) {
      console.error('Error fetching emergency contacts:', error);
      throw error;
    }
  }

  async updateEmergencyContact(id: number, userId: number, contactData: Partial<InsertEmergencyContact>): Promise<EmergencyContact> {
    try {
      const [contact] = await db
        .update(emergencyContacts)
        .set({
          ...contactData,
          updatedAt: new Date(),
        })
        .where(and(eq(emergencyContacts.id, id), eq(emergencyContacts.userId, userId)))
        .returning();
      return contact;
    } catch (error) {
      console.error('Error updating emergency contact:', error);
      throw error;
    }
  }

  async deleteEmergencyContact(id: number, userId: number): Promise<void> {
    try {
      await db
        .delete(emergencyContacts)
        .where(and(eq(emergencyContacts.id, id), eq(emergencyContacts.userId, userId)));
    } catch (error) {
      console.error('Error deleting emergency contact:', error);
      throw error;
    }
  }

  // Support tickets implementation
  async createSupportTicket(ticketData: InsertSupportTicket): Promise<SupportTicket> {
    try {
      const [ticket] = await db
        .insert(supportTickets)
        .values({
          ...ticketData,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();
      return ticket;
    } catch (error) {
      console.error('Error creating support ticket:', error);
      throw error;
    }
  }

  async getUserSupportTickets(userId: number): Promise<SupportTicket[]> {
    try {
      const tickets = await db
        .select()
        .from(supportTickets)
        .where(eq(supportTickets.userId, userId))
        .orderBy(desc(supportTickets.createdAt));
      return tickets;
    } catch (error) {
      console.error('Error fetching support tickets:', error);
      throw error;
    }
  }

  async updateSupportTicket(id: number, userId: number, ticketData: Partial<InsertSupportTicket>): Promise<SupportTicket> {
    try {
      const [ticket] = await db
        .update(supportTickets)
        .set({
          ...ticketData,
          updatedAt: new Date(),
        })
        .where(and(eq(supportTickets.id, id), eq(supportTickets.userId, userId)))
        .returning();
      return ticket;
    } catch (error) {
      console.error('Error updating support ticket:', error);
      throw error;
    }
  }
}

export const storage = new DatabaseStorage();
