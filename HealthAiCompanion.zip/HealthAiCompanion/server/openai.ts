import OpenAI from "openai";
import { storage } from "./storage";
import type { Medication } from "@shared/schema";

// using newest ai model from may 2024
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export async function chatWithAI(message: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a helpful health assistant AI. Provide informative, accurate health information while always emphasizing that you are not a substitute for professional medical advice. Always recommend consulting with healthcare providers for medical concerns. Keep responses concise but helpful. Focus on general health education and wellness guidance.

IMPORTANT DISCLAIMERS TO INCLUDE:
- Always include appropriate disclaimers about seeking professional medical care when discussing symptoms or health conditions
- Remind users that AI analysis might not always be accurate
- Emphasize that this is general information only, not personalized medical advice
- For medication questions, always recommend consulting pharmacists or doctors

MEDICATION-SPECIFIC GUIDANCE:
- When discussing medications, remind users to check with their pharmacist about interactions
- Suggest setting up pill reminders and tracking systems
- Mention the importance of taking medications as prescribed
- Remind about refill schedules and running out of medications

Keep responses helpful but always prioritize safety and professional medical guidance.`
        },
        {
          role: "user",
          content: message
        }
      ],
      max_tokens: 500,
      temperature: 0.7
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't process your request. Please try again.";
  } catch (error) {
    console.error("Error with OpenAI API:", error);
    throw new Error("Failed to get AI response");
  }
}

export async function generateMedicationReminders(medicationId: number, medication: Medication): Promise<void> {
  try {
    if (!medication.timeOfDay || medication.timeOfDay.length === 0) {
      return;
    }

    const startDate = new Date(medication.startDate);
    const endDate = medication.endDate ? new Date(medication.endDate) : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days from now

    const reminders = [];
    const currentDate = new Date(startDate);

    while (currentDate <= endDate) {
      for (const timeStr of medication.timeOfDay) {
        const [hours, minutes] = timeStr.split(':').map(Number);
        const reminderTime = new Date(currentDate);
        reminderTime.setHours(hours, minutes, 0, 0);

        if (reminderTime >= new Date()) { // Only create future reminders
          reminders.push({
            medicationId,
            scheduledTime: reminderTime
          });
        }
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Save reminders to database
    for (const reminder of reminders) {
      await storage.createMedicationReminder(reminder);
    }
  } catch (error) {
    console.error("Error generating medication reminders:", error);
    throw new Error("Failed to generate medication reminders");
  }
}

export async function analyzeMedicationInteractions(medications: string[]): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a pharmaceutical information assistant. Analyze potential drug interactions for the given medications. Provide general information about common interactions, but always emphasize the importance of consulting with pharmacists or healthcare providers for personalized advice. Always include disclaimers that AI analysis might not be accurate and that professional consultation is essential."
        },
        {
          role: "user",
          content: `Please analyze potential interactions between these medications: ${medications.join(", ")}. Provide general information about any known interactions, timing considerations, and suggestions for pharmacy consultation.`
        }
      ],
      max_tokens: 400,
      temperature: 0.3
    });

    return response.choices[0].message.content || "Unable to analyze interactions. Please consult with your pharmacist or healthcare provider.";
  } catch (error) {
    console.error("Error analyzing medication interactions:", error);
    throw new Error("Failed to analyze medication interactions");
  }
}

export async function generateMedicationAdvice(medicationName: string, symptoms: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a helpful health assistant specializing in medication guidance. Provide general educational information about medications and their effects. Always emphasize that:
          - This is general information only, not personalized medical advice
          - Users should consult their pharmacist or doctor for specific medication questions
          - AI analysis might not always be accurate
          - Never stop or change medications without professional guidance
          - Side effects should be reported to healthcare providers immediately`
        },
        {
          role: "user",
          content: `I'm taking ${medicationName} and experiencing ${symptoms}. Can you provide general information about this medication and suggest when I should contact my healthcare provider?`
        }
      ],
      max_tokens: 400,
      temperature: 0.3
    });

    return response.choices[0].message.content || "Please consult with your pharmacist or healthcare provider for medication-related concerns.";
  } catch (error) {
    console.error("Error generating medication advice:", error);
    throw new Error("Failed to generate medication advice");
  }
}

export async function generateRefillReminder(medication: Medication): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a helpful medication reminder assistant. Generate friendly, clear reminders about medication refills and pharmacy visits. Always include practical tips and emphasize the importance of not running out of medications."
        },
        {
          role: "user",
          content: `Generate a helpful reminder message for refilling ${medication.name} (${medication.dosage}, taken ${medication.frequency}). Include tips about timing and pharmacy considerations.`
        }
      ],
      max_tokens: 200,
      temperature: 0.7
    });

    return response.choices[0].message.content || `Time to refill your ${medication.name}! Contact your pharmacy or doctor to avoid running out.`;
  } catch (error) {
    console.error("Error generating refill reminder:", error);
    return `Time to refill your ${medication.name}! Contact your pharmacy or doctor to avoid running out.`;
  }
}

export async function analyzeSymptoms(data: {
  bodyParts: string[];
  symptoms: string;
  severity: number;
  duration: string;
}): Promise<{
  analysis: string;
  recommendations: string[];
  urgencyLevel: 'low' | 'medium' | 'high' | 'urgent';
  possibleConditions: string[];
}> {
  try {
    const bodyPartsText = data.bodyParts.join(', ');
    
    const prompt = `Analyze the following symptoms and provide a comprehensive health assessment. Please respond with a JSON object containing the analysis.

**Affected Body Parts:** ${bodyPartsText}
**Symptoms:** ${data.symptoms}
**Severity:** ${data.severity}/10
**Duration:** ${data.duration}

Please provide:
1. A detailed analysis of the symptoms
2. Practical recommendations for the patient
3. An urgency level (low, medium, high, or urgent)
4. Possible conditions that might explain these symptoms

**Important Medical Disclaimer:** This analysis is for informational purposes only and should not replace professional medical advice. Always consult with qualified healthcare professionals for proper diagnosis and treatment.

Please respond with a JSON object in this exact format:
{
  "analysis": "detailed analysis text here",
  "recommendations": ["recommendation 1", "recommendation 2", "recommendation 3"],
  "urgencyLevel": "low|medium|high|urgent",
  "possibleConditions": ["condition 1", "condition 2", "condition 3"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are a medical AI assistant helping with symptom analysis. You provide helpful, accurate information while emphasizing the importance of professional medical consultation. Always include appropriate medical disclaimers and safety warnings.

Key guidelines:
- Be thorough but avoid overly alarming language
- Focus on common, evidence-based conditions
- Always recommend consulting healthcare professionals
- Provide practical, actionable recommendations
- Consider the severity and duration when determining urgency
- Respond only with valid JSON format`
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 1000,
      temperature: 0.3,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    // Validate and provide defaults
    return {
      analysis: result.analysis || "Unable to analyze symptoms. Please consult a healthcare professional.",
      recommendations: Array.isArray(result.recommendations) ? result.recommendations : [
        "Consult with a healthcare professional for proper evaluation",
        "Monitor symptoms and seek immediate care if they worsen",
        "Keep a symptom diary to track changes"
      ],
      urgencyLevel: ['low', 'medium', 'high', 'urgent'].includes(result.urgencyLevel) 
        ? result.urgencyLevel 
        : 'medium',
      possibleConditions: Array.isArray(result.possibleConditions) ? result.possibleConditions : [
        "Requires professional medical evaluation"
      ]
    };
  } catch (error) {
    console.error("Error analyzing symptoms:", error);
    
    // Fallback if OpenAI fails
    return {
      analysis: "Unable to process symptom analysis. Please consult a healthcare professional for proper evaluation of your symptoms.",
      recommendations: [
        "Consult with a healthcare professional for proper evaluation",
        "Monitor symptoms and seek immediate care if they worsen",
        "Keep a symptom diary to track changes"
      ],
      urgencyLevel: data.severity >= 7 ? 'high' : data.severity >= 4 ? 'medium' : 'low',
      possibleConditions: ["Requires professional medical evaluation"]
    };
  }
}
