#!/usr/bin/env node

import { execSync } from 'child_process';
import { existsSync, readFileSync, writeFileSync } from 'fs';

console.log('🚀 Preparing for deployment...');

try {
  // Run the build process
  console.log('📦 Running build process...');
  execSync('node build.js', { stdio: 'inherit' });
  
  // Verify standalone.mjs was created
  if (!existsSync('standalone.mjs')) {
    throw new Error('standalone.mjs was not created during build');
  }
  
  // Verify frontend build exists
  if (!existsSync('dist/public')) {
    throw new Error('Frontend build (dist/public) was not created');
  }
  
  console.log('✅ Deployment preparation completed successfully!');
  console.log('   - Backend: standalone.mjs ✓');
  console.log('   - Frontend: dist/public/ ✓');
  console.log('   - Ready for deployment!');
  
} catch (error) {
  console.error('❌ Deployment preparation failed:', error.message);
  process.exit(1);
}