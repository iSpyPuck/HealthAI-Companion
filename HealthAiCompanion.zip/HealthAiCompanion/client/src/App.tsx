import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme-provider";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { useAuth, AuthProvider } from "@/hooks/use-auth";
import { FadeIn } from "@/components/animations/fade-in";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import HomePage from "@/pages/home-page";
import Dashboard from "@/pages/dashboard";
import Chat from "@/pages/chat";
import Records from "@/pages/records";
import Medications from "@/pages/medications";
import Appointments from "@/pages/appointments";
import Profile from "@/pages/profile";
import Reports from "@/pages/reports";
import Help from "@/pages/help";
import Emergency from "@/pages/emergency";
import SymptomAnalysis from "@/pages/symptom-analysis";
import SymptomMapping from "@/pages/symptom-mapping";
import AuthPage from "@/pages/auth-page";
import HabitTracker from "@/pages/habit-tracker";
import HealthTips from "@/pages/health-tips";
import TypingTest from "@/pages/typing-test";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import PageTransition from "@/components/ui/page-transition";

function Router() {
  const { user, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading ? (
        <Route path="*" component={() => <div className="min-h-screen flex items-center justify-center">Loading...</div>} />
      ) : !user ? (
        <>
          <Route path="/" component={Landing} />
          <Route path="/auth" component={AuthPage} />
        </>
      ) : (
        <>
          <Route path="/" component={Dashboard} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/chat" component={Chat} />
          <Route path="/records" component={Records} />
          <Route path="/medications" component={Medications} />
          <Route path="/appointments" component={Appointments} />
          <Route path="/profile" component={Profile} />
          <Route path="/reports" component={Reports} />
          <Route path="/help" component={Help} />
          <Route path="/emergency" component={Emergency} />
          <Route path="/symptom-analysis" component={SymptomAnalysis} />
          <Route path="/symptom-mapping" component={SymptomMapping} />
          <Route path="/habit-tracker" component={HabitTracker} />
          <Route path="/health-tips" component={HealthTips} />
          <Route path="/typing-test" component={TypingTest} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="system" storageKey="health-chat-theme">
      <TooltipProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </TooltipProvider>
    </ThemeProvider>
  );
}

function AppContent() {
  const { user, isLoading } = useAuth();

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      {/* Theme Toggle - Top Right */}
      <div className="fixed top-4 right-4 z-50">
        <FadeIn delay={1000}>
          <ThemeToggle />
        </FadeIn>
      </div>
      
      {!isLoading && user && <Header />}
      <PageTransition>
        <Router />
      </PageTransition>
      {!isLoading && user && <MobileNav />}
      <Toaster />
    </div>
  );
}

export default App;
