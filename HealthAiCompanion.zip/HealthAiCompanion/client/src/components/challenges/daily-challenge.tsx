import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Target, 
  Trophy, 
  Clock, 
  Sparkles, 
  CheckCircle, 
  RefreshCw, 
  Calendar,
  Zap,
  Star,
  Gift,
  ArrowRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DailyChallenge } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Floating challenge icons animation
const FloatingIcon = ({ icon: Icon, delay = 0 }: { icon: React.ElementType; delay?: number }) => (
  <motion.div
    className="absolute opacity-30"
    initial={{ 
      x: Math.random() * 200,
      y: Math.random() * 150,
      scale: 0.5,
      opacity: 0.3
    }}
    animate={{
      x: Math.random() * 200,
      y: Math.random() * 150,
      scale: [0.5, 0.8, 0.5],
      opacity: [0.3, 0.6, 0.3]
    }}
    transition={{
      duration: 4 + delay,
      repeat: Infinity,
      ease: "easeInOut"
    }}
  >
    <Icon className="h-6 w-6 text-purple-400" />
  </motion.div>
);

// Pulsing success overlay
const SuccessOverlay = ({ show, points }: { show: boolean; points: number }) => (
  <AnimatePresence>
    {show && (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-blue-500/20 backdrop-blur-sm flex items-center justify-center z-20 rounded-lg"
      >
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          exit={{ scale: 0, rotate: 180 }}
          className="text-center"
        >
          <motion.div
            animate={{ 
              scale: [1, 1.2, 1],
              rotate: [0, 10, -10, 0]
            }}
            transition={{ duration: 0.8, repeat: 3 }}
          >
            <Trophy className="h-16 w-16 text-yellow-400 mx-auto mb-2" />
          </motion.div>
          <h3 className="text-white font-bold text-xl mb-1">Challenge Completed!</h3>
          <p className="text-green-300 font-semibold">+{points} points earned!</p>
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

export default function DailyChallengeWidget() {
  const [showCompletionDialog, setShowCompletionDialog] = useState(false);
  const [proofText, setProofText] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: challenge, isLoading, error, refetch } = useQuery<DailyChallenge>({
    queryKey: ['/api/daily-challenge'],
    refetchOnWindowFocus: false,
    staleTime: 60 * 60 * 1000, // Cache for 1 hour
  });

  const completeMutation = useMutation({
    mutationFn: async (data: { challengeId: number; proofText: string }) => {
      return await apiRequest('POST', '/api/daily-challenge/complete', data);
    },
    onSuccess: () => {
      setShowSuccess(true);
      setShowCompletionDialog(false);
      setProofText("");
      queryClient.invalidateQueries({ queryKey: ['/api/daily-challenge'] });
      queryClient.invalidateQueries({ queryKey: ['/api/character'] });
      
      setTimeout(() => setShowSuccess(false), 4000);
      
      toast({
        title: "Challenge Completed! 🎉",
        description: `You earned ${challenge?.points || 0} points! Your character gained XP too!`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Challenge completion failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      hydration: "from-blue-500 to-cyan-400",
      exercise: "from-green-500 to-emerald-400", 
      nutrition: "from-orange-500 to-yellow-400",
      sleep: "from-purple-500 to-indigo-400",
      mental: "from-pink-500 to-rose-400",
      habits: "from-teal-500 to-blue-400",
      social: "from-indigo-500 to-purple-400",
      preventive: "from-red-500 to-pink-400"
    };
    return colors[category] || "from-purple-500 to-indigo-400";
  };

  const getCategoryIcon = (category: string) => {
    const icons: Record<string, React.ElementType> = {
      hydration: Sparkles,
      exercise: Zap,
      nutrition: Star,
      sleep: Calendar,
      mental: Gift,
      habits: Target,
      social: Trophy,
      preventive: RefreshCw
    };
    return icons[category] || Target;
  };

  const handleComplete = () => {
    if (!challenge || challenge.isCompleted) return;
    setShowCompletionDialog(true);
  };

  const submitCompletion = () => {
    if (!challenge) return;
    completeMutation.mutate({
      challengeId: challenge.id,
      proofText: proofText.trim()
    });
  };

  if (isLoading) {
    return (
      <Card className="relative overflow-hidden bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950/20 dark:to-blue-950/20">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-4">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            >
              <Target className="h-6 w-6 text-purple-500" />
            </motion.div>
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">
              Daily Challenge
            </h3>
          </div>
          <div className="animate-pulse">
            <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-full mb-1"></div>
            <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error || !challenge) {
    return (
      <Card className="relative overflow-hidden bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950/20 dark:to-orange-950/20">
        <CardContent className="p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">
            Daily Challenge
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Unable to load today's challenge
          </p>
          <Button 
            onClick={() => refetch()}
            variant="outline"
            className="hover:scale-105 transition-transform duration-200"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  const CategoryIcon = getCategoryIcon(challenge.category);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      >
        <Card className={`relative overflow-hidden bg-gradient-to-br ${getCategoryColor(challenge.category)} shadow-2xl`}>
          {/* Animated background elements */}
          <div className="absolute inset-0 pointer-events-none">
            <FloatingIcon icon={Target} delay={0} />
            <FloatingIcon icon={Sparkles} delay={0.5} />
            <FloatingIcon icon={Star} delay={1} />
            <FloatingIcon icon={Trophy} delay={1.5} />
          </div>

          {/* Success overlay */}
          <SuccessOverlay show={showSuccess} points={challenge.points} />

          <CardContent className="p-6 relative z-10">
            <div className="flex items-start justify-between mb-4">
              <motion.div 
                className="flex items-center space-x-3"
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <motion.div
                  animate={{ 
                    scale: [1, 1.1, 1],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{ 
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <CategoryIcon className="h-7 w-7 text-white drop-shadow-lg" />
                </motion.div>
                <div>
                  <h3 className="text-lg font-bold text-white drop-shadow-lg">
                    Daily Challenge
                  </h3>
                  <p className="text-white/90 text-sm drop-shadow-sm">
                    {challenge.category.charAt(0).toUpperCase() + challenge.category.slice(1)}
                  </p>
                </div>
              </motion.div>
              
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.4, type: "spring", stiffness: 200 }}
                className="text-right"
              >
                <div className="flex items-center text-white/90 text-sm mb-1">
                  <Trophy className="h-4 w-4 mr-1" />
                  {challenge.points} points
                </div>
                <div className="text-xs text-white/80 bg-white/20 px-2 py-1 rounded">
                  {challenge.difficulty}
                </div>
              </motion.div>
            </div>

            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="mb-6"
            >
              <h4 className="text-xl font-bold text-white mb-3 drop-shadow-lg">
                {challenge.title}
              </h4>
              <p className="text-white/95 leading-relaxed drop-shadow-sm text-sm">
                {challenge.description}
              </p>
            </motion.div>

            <motion.div 
              className="flex items-center justify-between"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              <div className="flex items-center space-x-2 text-white/90 text-sm">
                <Clock className="h-4 w-4" />
                <span>Expires at midnight</span>
              </div>

              {!challenge.isCompleted ? (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.7, type: "spring", stiffness: 200 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    onClick={handleComplete}
                    className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/30 text-white font-medium px-6 py-2 rounded-full transition-all duration-300 hover:shadow-lg"
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Complete Challenge
                  </Button>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="flex items-center text-white font-medium bg-green-500/30 px-4 py-2 rounded-full backdrop-blur-sm"
                >
                  <CheckCircle className="h-5 w-5 mr-2 text-green-300" />
                  Completed!
                </motion.div>
              )}
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Completion Dialog */}
      <Dialog open={showCompletionDialog} onOpenChange={setShowCompletionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Trophy className="h-5 w-5 mr-2 text-yellow-500" />
              Complete Your Challenge
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">{challenge?.title}</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                {challenge?.description}
              </p>
            </div>
            
            <div>
              <Label htmlFor="proof">How did you complete this challenge?</Label>
              <Textarea
                id="proof"
                placeholder="Share your experience, what you learned, or any notes about completing this challenge..."
                value={proofText}
                onChange={(e) => setProofText(e.target.value)}
                className="mt-2"
                rows={3}
              />
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setShowCompletionDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                onClick={submitCompletion}
                disabled={completeMutation.isPending}
                className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
              >
                {completeMutation.isPending ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Completing...
                  </>
                ) : (
                  <>
                    <Trophy className="h-4 w-4 mr-2" />
                    Complete Challenge
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}