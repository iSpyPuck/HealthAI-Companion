import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, MapPin, User, CheckCircle } from "lucide-react";
import { format, addDays, startOfWeek } from "date-fns";
import AppointmentForm from "./appointment-form";
import type { AppointmentSlot } from "@shared/schema";

const specialties = [
  "General Practice",
  "Cardiology",
  "Dermatology", 
  "Endocrinology",
  "Gastroenterology",
  "Neurology",
  "Oncology",
  "Orthopedics",
  "Pediatrics",
  "Psychiatry",
  "Pulmonology",
  "Urology",
];

export default function AppointmentScheduler() {
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>("");
  const [selectedSlot, setSelectedSlot] = useState<AppointmentSlot | null>(null);
  const [showForm, setShowForm] = useState(false);

  // Generate date range for the next 14 days
  const startDate = new Date();
  const endDate = addDays(startDate, 14);

  const { data: availableSlots = [], isLoading } = useQuery({
    queryKey: ["/api/appointment-slots", selectedSpecialty, startDate.toISOString(), endDate.toISOString()],
    enabled: !!selectedSpecialty,
  });

  // Group slots by date
  const slotsByDate = availableSlots.reduce((acc: Record<string, AppointmentSlot[]>, slot: AppointmentSlot) => {
    const date = format(new Date(slot.slotDate), "yyyy-MM-dd");
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(slot);
    return acc;
  }, {});

  const handleSlotSelect = (slot: AppointmentSlot) => {
    setSelectedSlot(slot);
    setShowForm(true);
  };

  // Create some sample slots if none exist
  const sampleSlots = [
    {
      id: 1,
      doctorName: "Dr. Sarah Johnson",
      doctorSpecialty: "General Practice",
      location: "HealthCare Center Downtown",
      slotDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Tomorrow 9 AM
      duration: 30,
      isAvailable: true,
    },
    {
      id: 2,
      doctorName: "Dr. Michael Chen",
      doctorSpecialty: "Cardiology",
      location: "Heart Specialists Clinic",
      slotDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), // Day after tomorrow 2 PM
      duration: 45,
      isAvailable: true,
    },
    {
      id: 3,
      doctorName: "Dr. Emily Rodriguez",
      doctorSpecialty: "Dermatology",
      location: "Skin Health Institute",
      slotDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days from now 10 AM
      duration: 30,
      isAvailable: true,
    },
  ];

  const displaySlots = availableSlots.length > 0 ? availableSlots : 
    (selectedSpecialty ? sampleSlots.filter(slot => slot.doctorSpecialty === selectedSpecialty) : sampleSlots);

  return (
    <div className="space-y-6">
      {/* Specialty Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <User className="w-5 h-5 mr-2 text-medical-blue" />
            Find Available Appointments
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Select Medical Specialty
              </label>
              <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Choose a medical specialty" />
                </SelectTrigger>
                <SelectContent>
                  {specialties.map((specialty) => (
                    <SelectItem key={specialty} value={specialty}>
                      {specialty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedSpecialty && (
              <div className="p-4 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">
                  Showing available appointments for <strong>{selectedSpecialty}</strong> in the next 14 days.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Available Slots */}
      {selectedSpecialty && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-medical-blue" />
              Available Time Slots
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-20 bg-muted rounded-lg"></div>
                  </div>
                ))}
              </div>
            ) : displaySlots.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No available slots</h3>
                <p className="text-muted-foreground">
                  No appointments are currently available for {selectedSpecialty}.
                  Please try a different specialty or check back later.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {Object.entries(slotsByDate).map(([date, slots]) => (
                  <div key={date} className="space-y-2">
                    <h4 className="font-semibold text-foreground">
                      {format(new Date(date), "EEEE, MMMM dd, yyyy")}
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {slots.map((slot: AppointmentSlot) => {
                        const slotTime = new Date(slot.slotDate);
                        return (
                          <Card 
                            key={slot.id} 
                            className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-medical-blue"
                            onClick={() => handleSlotSelect(slot)}
                          >
                            <CardContent className="p-4">
                              <div className="space-y-2">
                                <div className="flex justify-between items-start">
                                  <div>
                                    <p className="font-semibold text-foreground">
                                      Dr. {slot.doctorName}
                                    </p>
                                    <p className="text-sm text-muted-foreground">
                                      {slot.doctorSpecialty}
                                    </p>
                                  </div>
                                  <CheckCircle className="w-5 h-5 text-green-600" />
                                </div>
                                
                                <div className="flex items-center text-sm text-muted-foreground">
                                  <Clock className="w-4 h-4 mr-2" />
                                  {format(slotTime, "h:mm a")} ({slot.duration} min)
                                </div>
                                
                                <div className="flex items-center text-sm text-muted-foreground">
                                  <MapPin className="w-4 h-4 mr-2" />
                                  {slot.location}
                                </div>
                              </div>
                              
                              <Button 
                                className="w-full mt-3 bg-medical-blue hover:bg-blue-700"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleSlotSelect(slot);
                                }}
                              >
                                Book Appointment
                              </Button>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                ))}
                
                {displaySlots === sampleSlots && (
                  <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                    <p className="text-sm text-blue-800 dark:text-blue-200">
                      <strong>Demo Mode:</strong> These are sample appointment slots for demonstration. 
                      In a real application, these would be populated from your healthcare provider's scheduling system.
                    </p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Quick Schedule Option */}
      {!selectedSpecialty && (
        <Card>
          <CardContent className="p-8 text-center">
            <Calendar className="w-12 h-12 text-medical-blue mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Manual Scheduling</h3>
            <p className="text-muted-foreground mb-4">
              Can't find what you're looking for? Schedule an appointment manually.
            </p>
            <Button
              onClick={() => setShowForm(true)}
              className="bg-medical-blue hover:bg-blue-700"
            >
              Schedule Custom Appointment
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Appointment Form Modal */}
      {showForm && (
        <AppointmentForm
          appointment={selectedSlot ? {
            id: 0,
            userId: 0,
            title: `${selectedSlot.doctorSpecialty} Appointment`,
            description: `Appointment with Dr. ${selectedSlot.doctorName}`,
            appointmentDate: selectedSlot.slotDate,
            duration: selectedSlot.duration,
            location: selectedSlot.location,
            doctorName: selectedSlot.doctorName,
            doctorSpecialty: selectedSlot.doctorSpecialty,
            status: "scheduled",
            reminderSent: false,
            notes: "",
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          } : null}
          onClose={() => {
            setShowForm(false);
            setSelectedSlot(null);
          }}
          onSuccess={() => {
            setShowForm(false);
            setSelectedSlot(null);
          }}
        />
      )}
    </div>
  );
}