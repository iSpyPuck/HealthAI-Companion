import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertAppointmentSchema } from "@shared/schema";
import type { Appointment } from "@shared/schema";
import { z } from "zod";

const appointmentFormSchema = insertAppointmentSchema.extend({
  appointmentDate: z.string().min(1, "Appointment date is required"),
  appointmentTime: z.string().min(1, "Appointment time is required"),
});

type AppointmentFormData = z.infer<typeof appointmentFormSchema>;

interface AppointmentFormProps {
  appointment?: Appointment | null;
  onClose: () => void;
  onSuccess: () => void;
}

const specialties = [
  "General Practice",
  "Cardiology",
  "Dermatology",
  "Endocrinology",
  "Gastroenterology",
  "Neurology",
  "Oncology",
  "Orthopedics",
  "Pediatrics",
  "Psychiatry",
  "Pulmonology",
  "Urology",
];

export default function AppointmentForm({ appointment, onClose, onSuccess }: AppointmentFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!appointment;

  const form = useForm<AppointmentFormData>({
    resolver: zodResolver(appointmentFormSchema),
    defaultValues: {
      title: "",
      description: "",
      appointmentDate: "",
      appointmentTime: "",
      duration: 30,
      location: "",
      doctorName: "",
      doctorSpecialty: "",
      notes: "",
    },
  });

  useEffect(() => {
    if (appointment) {
      const appointmentDate = new Date(appointment.appointmentDate);
      const dateStr = appointmentDate.toISOString().split('T')[0];
      const timeStr = appointmentDate.toTimeString().slice(0, 5);

      form.reset({
        title: appointment.title,
        description: appointment.description || "",
        appointmentDate: dateStr,
        appointmentTime: timeStr,
        duration: appointment.duration || 30,
        location: appointment.location || "",
        doctorName: appointment.doctorName || "",
        doctorSpecialty: appointment.doctorSpecialty || "",
        notes: appointment.notes || "",
      });
    }
  }, [appointment, form]);

  const createAppointmentMutation = useMutation({
    mutationFn: async (data: Omit<AppointmentFormData, "appointmentTime" | "appointmentDate"> & { appointmentDate: string }) => {
      const response = await apiRequest("POST", "/api/appointments", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Appointment scheduled",
        description: "Your appointment has been successfully scheduled.",
      });
      onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to schedule appointment",
        variant: "destructive",
      });
    },
  });

  const updateAppointmentMutation = useMutation({
    mutationFn: async (data: Omit<AppointmentFormData, "appointmentTime" | "appointmentDate"> & { appointmentDate: string }) => {
      const response = await apiRequest("PUT", `/api/appointments/${appointment!.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Appointment updated",
        description: "Your appointment has been successfully updated.",
      });
      onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update appointment",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: AppointmentFormData) => {
    // Combine date and time into a single DateTime string
    const appointmentDateTime = new Date(`${data.appointmentDate}T${data.appointmentTime}`);
    
    const appointmentData = {
      title: data.title,
      description: data.description,
      appointmentDate: appointmentDateTime.toISOString(),
      duration: data.duration,
      location: data.location,
      doctorName: data.doctorName,
      doctorSpecialty: data.doctorSpecialty,
      notes: data.notes,
    };

    if (isEditing) {
      updateAppointmentMutation.mutate(appointmentData);
    } else {
      createAppointmentMutation.mutate(appointmentData);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Appointment" : "Schedule New Appointment"}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Appointment Title *</Label>
            <Input
              id="title"
              placeholder="e.g., Annual Check-up, Cardiology Consultation"
              {...form.register("title")}
            />
            {form.formState.errors.title && (
              <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Brief description of the appointment"
              {...form.register("description")}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="appointmentDate">Date *</Label>
              <Input
                id="appointmentDate"
                type="date"
                min={new Date().toISOString().split('T')[0]}
                {...form.register("appointmentDate")}
              />
              {form.formState.errors.appointmentDate && (
                <p className="text-sm text-destructive">{form.formState.errors.appointmentDate.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="appointmentTime">Time *</Label>
              <Input
                id="appointmentTime"
                type="time"
                {...form.register("appointmentTime")}
              />
              {form.formState.errors.appointmentTime && (
                <p className="text-sm text-destructive">{form.formState.errors.appointmentTime.message}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="duration">Duration (minutes)</Label>
            <Select
              value={form.watch("duration")?.toString()}
              onValueChange={(value) => form.setValue("duration", parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select duration" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">15 minutes</SelectItem>
                <SelectItem value="30">30 minutes</SelectItem>
                <SelectItem value="45">45 minutes</SelectItem>
                <SelectItem value="60">1 hour</SelectItem>
                <SelectItem value="90">1.5 hours</SelectItem>
                <SelectItem value="120">2 hours</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="doctorName">Doctor Name</Label>
            <Input
              id="doctorName"
              placeholder="Dr. Smith"
              {...form.register("doctorName")}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="doctorSpecialty">Specialty</Label>
            <Select
              value={form.watch("doctorSpecialty") || ""}
              onValueChange={(value) => form.setValue("doctorSpecialty", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select specialty" />
              </SelectTrigger>
              <SelectContent>
                {specialties.map((specialty) => (
                  <SelectItem key={specialty} value={specialty}>
                    {specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              placeholder="Hospital/Clinic name or address"
              {...form.register("location")}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Any additional notes or preparation instructions"
              {...form.register("notes")}
            />
          </div>

          <div className="flex space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-medical-blue hover:bg-blue-700"
              disabled={createAppointmentMutation.isPending || updateAppointmentMutation.isPending}
            >
              {createAppointmentMutation.isPending || updateAppointmentMutation.isPending
                ? "Saving..."
                : isEditing
                ? "Update Appointment"
                : "Schedule Appointment"
              }
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}