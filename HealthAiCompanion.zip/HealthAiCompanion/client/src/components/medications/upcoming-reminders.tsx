import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Pill, Bell } from "lucide-react";

interface UpcomingRemindersProps {
  medications: any[];
}

interface UpcomingReminder {
  medicationName: string;
  time: string;
  timeUntil: string;
  isToday: boolean;
}

export default function UpcomingReminders({ medications }: UpcomingRemindersProps) {
  const [upcomingReminders, setUpcomingReminders] = useState<UpcomingReminder[]>([]);

  useEffect(() => {
    const calculateUpcomingReminders = () => {
      const now = new Date();
      const reminders: UpcomingReminder[] = [];

      medications.forEach((medication) => {
        if (medication.timeOfDay && medication.timeOfDay.length > 0) {
          medication.timeOfDay.forEach((time: string) => {
            const [hours, minutes] = time.split(':').map(Number);
            
            // Today's reminder
            const todayReminder = new Date(now);
            todayReminder.setHours(hours, minutes, 0, 0);
            
            // Tomorrow's reminder
            const tomorrowReminder = new Date(now);
            tomorrowReminder.setDate(tomorrowReminder.getDate() + 1);
            tomorrowReminder.setHours(hours, minutes, 0, 0);
            
            // Use today's time if it's in the future, otherwise tomorrow's
            const reminderTime = todayReminder > now ? todayReminder : tomorrowReminder;
            const isToday = todayReminder > now;
            
            const timeUntil = formatTimeUntil(reminderTime, now);
            
            reminders.push({
              medicationName: medication.name,
              time: time,
              timeUntil,
              isToday
            });
          });
        }
      });

      // Sort by time
      reminders.sort((a, b) => {
        const timeA = new Date();
        const [hoursA, minutesA] = a.time.split(':').map(Number);
        timeA.setHours(hoursA, minutesA, 0, 0);
        if (!a.isToday) timeA.setDate(timeA.getDate() + 1);
        
        const timeB = new Date();
        const [hoursB, minutesB] = b.time.split(':').map(Number);
        timeB.setHours(hoursB, minutesB, 0, 0);
        if (!b.isToday) timeB.setDate(timeB.getDate() + 1);
        
        return timeA.getTime() - timeB.getTime();
      });

      setUpcomingReminders(reminders.slice(0, 5)); // Show next 5 reminders
    };

    const formatTimeUntil = (futureTime: Date, currentTime: Date): string => {
      const diffMs = futureTime.getTime() - currentTime.getTime();
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      
      if (diffHours > 0) {
        return `${diffHours}h ${diffMinutes}m`;
      } else {
        return `${diffMinutes}m`;
      }
    };

    calculateUpcomingReminders();
    
    // Update every minute
    const interval = setInterval(calculateUpcomingReminders, 60000);
    
    return () => clearInterval(interval);
  }, [medications]);

  if (upcomingReminders.length === 0) {
    return null;
  }

  return (
    <Card className="bg-light-blue">
      <CardContent className="p-4">
        <div className="flex items-center space-x-2 mb-3">
          <Bell className="w-5 h-5 text-medical-blue" />
          <h4 className="font-medium text-charcoal">Upcoming Reminders</h4>
        </div>
        
        <div className="space-y-2">
          {upcomingReminders.map((reminder, index) => (
            <div key={index} className="flex items-center justify-between p-2 bg-white rounded-lg">
              <div className="flex items-center space-x-2">
                <Pill className="w-4 h-4 text-medical-blue" />
                <span className="text-sm font-medium text-charcoal">
                  {reminder.medicationName}
                </span>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <div className="text-sm font-medium text-charcoal">
                    {reminder.time}
                  </div>
                  <div className="text-xs text-gray-500">
                    in {reminder.timeUntil}
                  </div>
                </div>
                <Badge 
                  variant={reminder.isToday ? "default" : "secondary"}
                  className={reminder.isToday ? "bg-medical-blue" : ""}
                >
                  {reminder.isToday ? "Today" : "Tomorrow"}
                </Badge>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-3 text-xs text-gray-600">
          Enable notifications above to receive push reminders
        </div>
      </CardContent>
    </Card>
  );
}