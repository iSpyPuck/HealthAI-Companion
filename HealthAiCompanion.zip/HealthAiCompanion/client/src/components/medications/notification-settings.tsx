import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Bell, BellOff, CheckCircle, AlertCircle } from "lucide-react";
import { notificationService } from "@/lib/notifications";
import { useToast } from "@/hooks/use-toast";

export default function NotificationSettings() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [hasPermission, setHasPermission] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setIsSupported(notificationService.isSupported());
    setHasPermission(notificationService.hasPermission());
    
    // Load saved preference
    const savedPreference = localStorage.getItem('medication-notifications-enabled');
    if (savedPreference === 'true' && notificationService.hasPermission()) {
      setNotificationsEnabled(true);
    }
  }, []);

  const handleToggleNotifications = async () => {
    if (!notificationsEnabled) {
      // Requesting to enable notifications
      const hasPermission = await notificationService.requestPermission();
      
      if (hasPermission) {
        setNotificationsEnabled(true);
        setHasPermission(true);
        localStorage.setItem('medication-notifications-enabled', 'true');
        
        toast({
          title: "Notifications enabled",
          description: "You'll now receive medication reminders",
        });

        // Show a test notification
        await notificationService.showNotification(
          "🎉 Notifications are working!",
          {
            body: "You'll receive medication reminders like this one",
            requireInteraction: false
          }
        );
      } else {
        toast({
          title: "Permission denied",
          description: "Please enable notifications in your browser settings to receive reminders",
          variant: "destructive",
        });
      }
    } else {
      // Disabling notifications
      setNotificationsEnabled(false);
      localStorage.setItem('medication-notifications-enabled', 'false');
      
      toast({
        title: "Notifications disabled",
        description: "You won't receive medication reminders",
      });
    }
  };

  const testNotification = async () => {
    if (notificationsEnabled) {
      await notificationService.showNotification(
        "💊 Test Medication Reminder",
        {
          body: "This is how your medication reminders will look",
          requireInteraction: false
        }
      );
    }
  };

  if (!isSupported) {
    return (
      <Card className="bg-gray-50">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <BellOff className="w-5 h-5 text-gray-400" />
            <div>
              <h4 className="font-medium text-gray-600">Notifications Not Supported</h4>
              <p className="text-sm text-gray-500">
                Your browser doesn't support push notifications for reminders
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-light-blue">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3">
            <div className="w-10 h-10 bg-medical-blue rounded-full flex items-center justify-center">
              <Bell className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <h4 className="font-medium text-charcoal">Text Reminders</h4>
                {hasPermission ? (
                  <Badge variant="secondary" className="bg-health-green/20 text-health-green">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Enabled
                  </Badge>
                ) : (
                  <Badge variant="secondary" className="bg-coral/20 text-coral">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    Disabled
                  </Badge>
                )}
              </div>
              <p className="text-sm text-gray-600 mb-3">
                Get push notifications when it's time to take your medications
              </p>
              
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={notificationsEnabled}
                    onCheckedChange={handleToggleNotifications}
                  />
                  <span className="text-sm text-charcoal">
                    {notificationsEnabled ? 'On' : 'Off'}
                  </span>
                </div>
                
                {notificationsEnabled && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={testNotification}
                    className="text-xs"
                  >
                    Test Reminder
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {!hasPermission && (
          <div className="mt-3 p-3 bg-coral/10 rounded-lg">
            <p className="text-xs text-charcoal">
              <strong>Note:</strong> Click the switch to enable notifications. Your browser will ask for permission to send you reminders.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}