import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Calendar, Clock, Pill } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday, addMonths, subMonths } from "date-fns";

interface MedicationReminder {
  id: number;
  medicationId: number;
  medicationName: string;
  dosage: string;
  scheduledTime: Date;
  taken: boolean;
  notes?: string;
}

interface EnhancedCalendarProps {
  reminders: MedicationReminder[];
  onReminderClick: (reminder: MedicationReminder) => void;
  onDateClick: (date: Date) => void;
}

export default function EnhancedCalendar({ reminders, onReminderClick, onDateClick }: EnhancedCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day'>('month');

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // put reminders together by day
  const remindersByDate = useMemo(() => {
    const grouped: { [key: string]: MedicationReminder[] } = {};
    reminders.forEach(reminder => {
      const dateKey = format(reminder.scheduledTime, 'yyyy-MM-dd');
      if (!grouped[dateKey]) {
        grouped[dateKey] = [];
      }
      grouped[dateKey].push(reminder);
    });
    return grouped;
  }, [reminders]);

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => direction === 'prev' ? subMonths(prev, 1) : addMonths(prev, 1));
  };

  const renderCalendarDay = (date: Date) => {
    const dateKey = format(date, 'yyyy-MM-dd');
    const dayReminders = remindersByDate[dateKey] || [];
    const isCurrentMonth = isSameMonth(date, currentDate);
    const isCurrentDay = isToday(date);

    return (
      <div
        key={dateKey}
        className={`
          min-h-[120px] border border-gray-200 dark:border-gray-700 p-2 cursor-pointer
          transition-colors hover:bg-gray-50 dark:hover:bg-gray-800
          ${!isCurrentMonth ? 'bg-gray-50 dark:bg-gray-900 text-gray-400' : ''}
          ${isCurrentDay ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-600' : ''}
        `}
        onClick={() => onDateClick(date)}
      >
        <div className={`text-sm font-medium mb-1 ${isCurrentDay ? 'text-blue-600 dark:text-blue-400' : ''}`}>
          {format(date, 'd')}
        </div>
        
        <div className="space-y-1">
          {dayReminders.slice(0, 3).map((reminder) => (
            <div
              key={reminder.id}
              className={`
                text-xs p-1 rounded cursor-pointer transition-colors
                ${reminder.taken 
                  ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300' 
                  : 'bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-300'
                }
                hover:opacity-80
              `}
              onClick={(e) => {
                e.stopPropagation();
                onReminderClick(reminder);
              }}
            >
              <div className="flex items-center gap-1">
                <Pill className="w-3 h-3" />
                <span className="font-medium">{reminder.medicationName}</span>
              </div>
              <div className="flex items-center gap-1 text-xs opacity-75">
                <Clock className="w-2 h-2" />
                {format(reminder.scheduledTime, 'HH:mm')}
              </div>
            </div>
          ))}
          
          {dayReminders.length > 3 && (
            <div className="text-xs text-gray-500 dark:text-gray-400">
              +{dayReminders.length - 3} more
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderWeekView = () => {
    // week view stuff
    return (
      <div className="text-center py-8 text-gray-500">
        Week view coming soon
      </div>
    );
  };

  const renderDayView = () => {
    // day view stuff
    const dateKey = format(currentDate, 'yyyy-MM-dd');
    const dayReminders = remindersByDate[dateKey] || [];

    return (
      <div className="space-y-4">
        <div className="text-center">
          <h3 className="text-lg font-semibold">{format(currentDate, 'EEEE, MMMM d, yyyy')}</h3>
        </div>
        
        <div className="space-y-2">
          {dayReminders.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No medications scheduled for this day
            </div>
          ) : (
            dayReminders.map((reminder) => (
              <Card key={reminder.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${reminder.taken ? 'bg-green-500' : 'bg-orange-500'}`} />
                      <div>
                        <div className="font-medium">{reminder.medicationName}</div>
                        <div className="text-sm text-gray-500">{reminder.dosage}</div>
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      {format(reminder.scheduledTime, 'HH:mm')}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    );
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Medication Calendar
          </CardTitle>
          
          <div className="flex items-center gap-2">
            {/* View mode toggles */}
            <div className="flex rounded-lg bg-gray-100 dark:bg-gray-800 p-1">
              {(['month', 'week', 'day'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  className={`
                    px-3 py-1 text-sm font-medium rounded-md transition-colors
                    ${viewMode === mode 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'hover:bg-gray-50 dark:hover:bg-gray-700/50'
                    }
                  `}
                >
                  {mode.charAt(0).toUpperCase() + mode.slice(1)}
                </button>
              ))}
            </div>
            
            {/* Navigation */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigateMonth('prev')}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              
              <div className="text-sm font-medium min-w-[120px] text-center">
                {format(currentDate, 'MMMM yyyy')}
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigateMonth('next')}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {viewMode === 'month' && (
          <div>
            {/* Calendar header */}
            <div className="grid grid-cols-7 gap-0 mb-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div key={day} className="p-2 text-center text-sm font-medium text-gray-500 dark:text-gray-400">
                  {day}
                </div>
              ))}
            </div>
            
            {/* Calendar grid */}
            <div className="grid grid-cols-7 gap-0 border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
              {daysInMonth.map(renderCalendarDay)}
            </div>
          </div>
        )}
        
        {viewMode === 'week' && renderWeekView()}
        {viewMode === 'day' && renderDayView()}
      </CardContent>
    </Card>
  );
}