import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, CheckCircle, XCircle } from "lucide-react";

export default function MedicationCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const startOfWeek = new Date(currentDate);
  startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
  
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);

  const { data: reminders = [] } = useQuery({
    queryKey: ['/api/medication-reminders', startOfWeek.toISOString(), endOfWeek.toISOString()],
    queryFn: async () => {
      const response = await fetch(`/api/medication-reminders?startDate=${startOfWeek.toISOString()}&endDate=${endOfWeek.toISOString()}`, {
        credentials: 'include',
      });
      if (!response.ok) return [];
      return response.json();
    },
  });

  const navigateWeek = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() + (direction === 'next' ? 7 : -7));
    setCurrentDate(newDate);
  };

  const getDaysOfWeek = () => {
    const days = [];
    const start = new Date(startOfWeek);
    
    for (let i = 0; i < 7; i++) {
      days.push(new Date(start));
      start.setDate(start.getDate() + 1);
    }
    
    return days;
  };

  const getRemindersForDate = (date: Date) => {
    return reminders.filter((reminder: any) => {
      const reminderDate = new Date(reminder.scheduledTime);
      return reminderDate.toDateString() === date.toDateString();
    });
  };

  const isToday = (date: Date) => {
    return date.toDateString() === new Date().toDateString();
  };

  const days = getDaysOfWeek();
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-charcoal">This Week's Schedule</h3>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" onClick={() => navigateWeek('prev')}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium text-charcoal">
              {startOfWeek.toLocaleDateString()} - {endOfWeek.toLocaleDateString()}
            </span>
            <Button variant="ghost" size="sm" onClick={() => navigateWeek('next')}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2 mb-4">
          {weekDays.map((day) => (
            <div key={day} className="text-center text-sm font-medium text-gray-600 py-2">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-2">
          {days.map((date, index) => {
            const dayReminders = getRemindersForDate(date);
            const completedReminders = dayReminders.filter((r: any) => r.isTaken).length;
            const totalReminders = dayReminders.length;
            
            return (
              <div
                key={index}
                className={`h-20 p-2 rounded-lg border ${
                  isToday(date) 
                    ? 'bg-medical-blue text-white border-medical-blue' 
                    : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <div className="text-center">
                  <div className={`text-sm font-medium ${
                    isToday(date) ? 'text-white' : 'text-charcoal'
                  }`}>
                    {date.getDate()}
                  </div>
                  {totalReminders > 0 && (
                    <div className="flex items-center justify-center space-x-1 mt-1">
                      <div className={`w-2 h-2 rounded-full ${
                        completedReminders === totalReminders 
                          ? 'bg-health-green' 
                          : completedReminders > 0 
                            ? 'bg-yellow-500' 
                            : 'bg-coral'
                      }`}></div>
                      <span className={`text-xs ${
                        isToday(date) ? 'text-white' : 'text-gray-600'
                      }`}>
                        {completedReminders}/{totalReminders}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 space-y-2">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-health-green rounded-full"></div>
            <span className="text-sm text-gray-600">All doses completed</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <span className="text-sm text-gray-600">Partially completed</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-coral rounded-full"></div>
            <span className="text-sm text-gray-600">Missed doses</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
