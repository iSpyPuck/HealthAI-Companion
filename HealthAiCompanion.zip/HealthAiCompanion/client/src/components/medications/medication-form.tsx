import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Plus, X } from "lucide-react";

interface MedicationFormProps {
  onSuccess: () => void;
}

export default function MedicationForm({ onSuccess }: MedicationFormProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    dosage: "",
    frequency: "",
    timeOfDay: [""],
    startDate: new Date().toISOString().split('T')[0],
    endDate: "",
    notes: "",
  });

  const createMedicationMutation = useMutation({
    mutationFn: async (medicationData: any) => {
      const response = await apiRequest('POST', '/api/medications', medicationData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Medication added",
        description: "Your medication has been added successfully with reminders set up.",
      });
      onSuccess();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add medication. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.dosage || !formData.frequency) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const medicationData = {
      ...formData,
      timeOfDay: formData.timeOfDay.filter(time => time !== ""),
      startDate: new Date(formData.startDate),
      endDate: formData.endDate ? new Date(formData.endDate) : null,
    };

    createMedicationMutation.mutate(medicationData);
  };

  const addTimeSlot = () => {
    setFormData(prev => ({
      ...prev,
      timeOfDay: [...prev.timeOfDay, ""]
    }));
  };

  const removeTimeSlot = (index: number) => {
    setFormData(prev => ({
      ...prev,
      timeOfDay: prev.timeOfDay.filter((_, i) => i !== index)
    }));
  };

  const updateTimeSlot = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      timeOfDay: prev.timeOfDay.map((time, i) => i === index ? value : time)
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Medication Name *</Label>
          <Input
            id="name"
            placeholder="e.g., Metformin"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            required
          />
        </div>
        
        <div>
          <Label htmlFor="dosage">Dosage *</Label>
          <Input
            id="dosage"
            placeholder="e.g., 500mg"
            value={formData.dosage}
            onChange={(e) => setFormData(prev => ({ ...prev, dosage: e.target.value }))}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="frequency">Frequency *</Label>
          <Select value={formData.frequency} onValueChange={(value) => setFormData(prev => ({ ...prev, frequency: value }))}>
            <SelectTrigger>
              <SelectValue placeholder="Select frequency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Once daily">Once daily</SelectItem>
              <SelectItem value="Twice daily">Twice daily</SelectItem>
              <SelectItem value="Three times daily">Three times daily</SelectItem>
              <SelectItem value="Four times daily">Four times daily</SelectItem>
              <SelectItem value="As needed">As needed</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="startDate">Start Date *</Label>
          <Input
            id="startDate"
            type="date"
            value={formData.startDate}
            onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
            required
          />
        </div>
      </div>

      <div>
        <Label>Times of Day</Label>
        <div className="space-y-2">
          {formData.timeOfDay.map((time, index) => (
            <div key={index} className="flex items-center space-x-2">
              <Input
                type="time"
                value={time}
                onChange={(e) => updateTimeSlot(index, e.target.value)}
                className="flex-1"
              />
              {formData.timeOfDay.length > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeTimeSlot(index)}
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addTimeSlot}
            className="w-full"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Time
          </Button>
        </div>
      </div>

      <div>
        <Label htmlFor="endDate">End Date (optional)</Label>
        <Input
          id="endDate"
          type="date"
          value={formData.endDate}
          onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
        />
      </div>

      <div>
        <Label htmlFor="notes">Notes (optional)</Label>
        <Textarea
          id="notes"
          placeholder="Any additional notes about this medication..."
          value={formData.notes}
          onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
          rows={3}
        />
      </div>

      <Button
        type="submit"
        className="w-full bg-medical-blue hover:bg-blue-700"
        disabled={createMedicationMutation.isPending}
      >
        {createMedicationMutation.isPending ? "Adding..." : "Add Medication"}
      </Button>
    </form>
  );
}
