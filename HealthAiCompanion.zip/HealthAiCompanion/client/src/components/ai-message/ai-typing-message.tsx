import { useState, useEffect } from "react";
import { motion } from "framer-motion";

interface AITypingMessageProps {
  message: string;
  speed?: number;
  className?: string;
}

// Function to parse bold text (** text **)
const parseAiMessage = (text: string) => {
  const parts = text.split(/(\*\*.*?\*\*)/g);
  
  return parts.map((part, index) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      const boldText = part.slice(2, -2);
      return <strong key={index} className="font-bold text-primary">{boldText}</strong>;
    }
    return part;
  });
};

export default function AITypingMessage({ message, speed = 15, className = "" }: AITypingMessageProps) {
  const [displayedText, setDisplayedText] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    if (currentIndex < message.length) {
      const timeout = setTimeout(() => {
        setDisplayedText(prev => prev + message[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, speed);
      
      return () => clearTimeout(timeout);
    } else if (currentIndex >= message.length && !isComplete) {
      setIsComplete(true);
    }
  }, [currentIndex, message, speed, isComplete]);

  // Reset animation when message changes
  useEffect(() => {
    setDisplayedText("");
    setCurrentIndex(0);
    setIsComplete(false);
  }, [message]);

  return (
    <div className={`ai-message ${className}`}>
      <div className="leading-relaxed">
        {parseAiMessage(displayedText)}
        {!isComplete && (
          <motion.span
            animate={{ opacity: [1, 0, 1] }}
            transition={{ 
              duration: 0.8, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            className="inline-block w-2 h-5 bg-primary ml-1"
          />
        )}
      </div>
    </div>
  );
}