import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { CheckCircle, Circle, Clock, MessageSquare, Target, Flame } from 'lucide-react';
import type { Habit } from '@shared/schema';

interface HabitCardProps {
  habit: Habit;
  onLog: (notes?: string) => void;
  isLogging: boolean;
  isCompleted: boolean;
}

export function HabitCard({ habit, onLog, isLogging, isCompleted }: HabitCardProps) {
  const [showNotes, setShowNotes] = useState(false);
  const [notes, setNotes] = useState('');

  const handleComplete = () => {
    onLog(notes);
    setNotes('');
    setShowNotes(false);
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      fitness: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
      nutrition: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
      sleep: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      mental: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
      medical: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
    };
    return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-700 dark:bg-gray-900 dark:text-gray-300';
  };

  return (
    <Card className={`card-modern transition-all duration-300 hover:shadow-lg ${
      isCompleted ? 'ring-2 ring-green-500/20 bg-green-50/50 dark:bg-green-900/10' : ''
    }`}>
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          {/* Habit Icon */}
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg"
            style={{ backgroundColor: habit.color }}
          >
            {habit.icon}
          </div>

          {/* Habit Details */}
          <div className="flex-1">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-semibold text-lg text-foreground">{habit.name}</h3>
                {habit.description && (
                  <p className="text-sm text-muted-foreground mt-1">{habit.description}</p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className={getCategoryColor(habit.category)}>
                  {habit.category}
                </Badge>
                <Badge variant="outline" className="gap-1">
                  <Target className="w-3 h-3" />
                  {habit.targetCount}x {habit.frequency}
                </Badge>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 mt-4">
              {isCompleted ? (
                <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-medium">Completed today!</span>
                </div>
              ) : (
                <>
                  <Button
                    onClick={() => setShowNotes(!showNotes)}
                    variant="outline"
                    size="sm"
                    className="gap-2"
                  >
                    <MessageSquare className="w-4 h-4" />
                    Add Note
                  </Button>
                  <Button
                    onClick={handleComplete}
                    disabled={isLogging}
                    className="gap-2 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                  >
                    {isLogging ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                        Logging...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        Mark Complete
                      </>
                    )}
                  </Button>
                </>
              )}
            </div>

            {/* Notes Input */}
            {showNotes && !isCompleted && (
              <div className="mt-4 space-y-2">
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add a note about this habit completion..."
                  className="min-h-[80px]"
                />
                <div className="flex gap-2">
                  <Button
                    onClick={handleComplete}
                    disabled={isLogging}
                    size="sm"
                    className="gap-2"
                  >
                    <CheckCircle className="w-4 h-4" />
                    Complete with Note
                  </Button>
                  <Button
                    onClick={() => setShowNotes(false)}
                    variant="outline"
                    size="sm"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}