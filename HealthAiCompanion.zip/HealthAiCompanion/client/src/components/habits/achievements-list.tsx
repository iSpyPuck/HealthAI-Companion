import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Star, Target, Flame, Crown, Zap, Heart, Award } from 'lucide-react';
import { ScaleIn } from '@/components/animations';
import type { Achievement } from '@shared/schema';
import { format } from 'date-fns';

interface AchievementsListProps {
  achievements: Achievement[];
  isLoading: boolean;
}

const ACHIEVEMENT_ICONS = {
  streak: Flame,
  completion: Trophy,
  variety: Star,
  milestone: Crown,
  dedication: Heart,
  consistency: Target,
  progress: Zap,
  excellence: Award
};

const PREDEFINED_ACHIEVEMENTS = [
  {
    id: 'first_habit',
    title: 'First Steps',
    description: 'Complete your first habit',
    icon: 'streak',
    category: 'milestone',
    requirement: 'Complete 1 habit'
  },
  {
    id: 'week_warrior',
    title: 'Week Warrior',
    description: 'Maintain a 7-day streak',
    icon: 'streak',
    category: 'streak',
    requirement: '7-day streak'
  },
  {
    id: 'habit_master',
    title: 'Habit Master',
    description: 'Complete 100 habits',
    icon: 'completion',
    category: 'completion',
    requirement: '100 completed habits'
  },
  {
    id: 'variety_lover',
    title: 'Variety Lover',
    description: 'Create habits in all categories',
    icon: 'variety',
    category: 'variety',
    requirement: 'All 5 categories'
  },
  {
    id: 'monthly_champion',
    title: 'Monthly Champion',
    description: 'Complete habits every day for a month',
    icon: 'consistency',
    category: 'streak',
    requirement: '30-day streak'
  },
  {
    id: 'dedication_hero',
    title: 'Dedication Hero',
    description: 'Use the app for 6 months',
    icon: 'dedication',
    category: 'milestone',
    requirement: '6 months active'
  },
  {
    id: 'level_10',
    title: 'Level 10 Legend',
    description: 'Reach character level 10',
    icon: 'progress',
    category: 'milestone',
    requirement: 'Level 10'
  },
  {
    id: 'perfectionist',
    title: 'Perfectionist',
    description: 'Complete all habits for 14 days straight',
    icon: 'excellence',
    category: 'streak',
    requirement: '14-day perfect streak'
  }
];

export function AchievementsList({ achievements, isLoading }: AchievementsListProps) {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  const unlockedAchievements = achievements.map(a => a.title);
  
  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <ScaleIn>
        <Card className="card-modern">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              Achievement Progress
            </CardTitle>
            <CardDescription>
              Track your health journey milestones
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">
                  {achievements.length}
                </div>
                <div className="text-sm text-muted-foreground">Unlocked</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-500">
                  {PREDEFINED_ACHIEVEMENTS.length}
                </div>
                <div className="text-sm text-muted-foreground">Total</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-500">
                  {Math.round((achievements.length / PREDEFINED_ACHIEVEMENTS.length) * 100)}%
                </div>
                <div className="text-sm text-muted-foreground">Complete</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-500">
                  {achievements.filter(a => a.category === 'milestone').length}
                </div>
                <div className="text-sm text-muted-foreground">Milestones</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </ScaleIn>

      {/* Achievements Grid */}
      <div className="grid md:grid-cols-2 gap-4">
        {PREDEFINED_ACHIEVEMENTS.map((achievement, index) => {
          const isUnlocked = unlockedAchievements.includes(achievement.title);
          const userAchievement = achievements.find(a => a.title === achievement.title);
          const IconComponent = ACHIEVEMENT_ICONS[achievement.icon as keyof typeof ACHIEVEMENT_ICONS] || Trophy;
          
          return (
            <ScaleIn key={achievement.id} delay={index * 100}>
              <Card className={`card-modern transition-all ${
                isUnlocked 
                  ? 'border-yellow-200 bg-yellow-50/50 dark:border-yellow-800 dark:bg-yellow-900/20' 
                  : 'opacity-60'
              }`}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                      isUnlocked 
                        ? 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-400' 
                        : 'bg-gray-100 text-gray-400 dark:bg-gray-800 dark:text-gray-600'
                    }`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-foreground">
                          {achievement.title}
                        </h3>
                        {isUnlocked && (
                          <Badge variant="secondary" className="bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300">
                            Unlocked
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">
                        {achievement.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">
                          {achievement.requirement}
                        </span>
                        {isUnlocked && userAchievement && (
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(userAchievement.unlockedAt), 'MMM d, yyyy')}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </ScaleIn>
          );
        })}
      </div>

      {/* Coming Soon */}
      <ScaleIn delay={800}>
        <Card className="card-modern border-dashed border-2">
          <CardContent className="py-8 text-center">
            <div className="text-4xl mb-4">🚀</div>
            <h3 className="font-semibold mb-2">More Achievements Coming Soon!</h3>
            <p className="text-muted-foreground text-sm">
              We're working on more exciting achievements to celebrate your health journey.
            </p>
          </CardContent>
        </Card>
      </ScaleIn>
    </div>
  );
}