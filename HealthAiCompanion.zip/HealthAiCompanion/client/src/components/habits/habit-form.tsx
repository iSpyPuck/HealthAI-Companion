import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Target, Repeat, Palette } from 'lucide-react';
import { ScaleIn } from '@/components/animations';

interface HabitFormProps {
  onClose: () => void;
  onSubmit: (data: any) => void;
  isLoading: boolean;
}

const HABIT_CATEGORIES = [
  { id: 'fitness', label: 'Fitness', icon: '💪', color: '#ef4444' },
  { id: 'nutrition', label: 'Nutrition', icon: '🥗', color: '#22c55e' },
  { id: 'sleep', label: 'Sleep', icon: '😴', color: '#8b5cf6' },
  { id: 'mental', label: 'Mental Health', icon: '🧠', color: '#06b6d4' },
  { id: 'medical', label: 'Medical', icon: '🏥', color: '#f59e0b' },
];

const HABIT_ICONS = [
  '💪', '🏃', '🥗', '💧', '😴', '📚', '🧠', '🏥', '🎯', '⭐',
  '🌿', '🏋️', '🚴', '🧘', '📖', '💊', '🥤', '🚶', '🌅', '🌙'
];

const HABIT_COLORS = [
  '#ef4444', '#f97316', '#f59e0b', '#eab308', '#22c55e', '#06b6d4',
  '#3b82f6', '#8b5cf6', '#d946ef', '#ec4899', '#f43f5e', '#84cc16'
];

export function HabitForm({ onClose, onSubmit, isLoading }: HabitFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    icon: '🎯',
    color: '#3b82f6',
    frequency: 'daily',
    targetCount: 1,
    category: 'fitness'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <ScaleIn>
        <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Create New Habit
                </CardTitle>
                <CardDescription>
                  Add a new healthy habit to your daily routine
                </CardDescription>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="rounded-full"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Info */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Habit Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Drink 8 glasses of water"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="description">Description (optional)</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Add some details about this habit..."
                    rows={3}
                  />
                </div>
              </div>

              {/* Category */}
              <div>
                <Label>Category</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
                  {HABIT_CATEGORIES.map((category) => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => setFormData(prev => ({ 
                        ...prev, 
                        category: category.id,
                        color: category.color 
                      }))}
                      className={`p-3 rounded-lg border text-left transition-all ${
                        formData.category === category.id
                          ? 'border-primary bg-primary/10 text-primary'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="text-lg mb-1">{category.icon}</div>
                      <div className="font-medium text-sm">{category.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Icon & Color */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Icon</Label>
                  <div className="grid grid-cols-5 gap-2 mt-2">
                    {HABIT_ICONS.map((icon) => (
                      <button
                        key={icon}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, icon }))}
                        className={`p-2 rounded-lg border text-xl transition-all ${
                          formData.icon === icon
                            ? 'border-primary bg-primary/10'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        {icon}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label>Color</Label>
                  <div className="grid grid-cols-6 gap-2 mt-2">
                    {HABIT_COLORS.map((color) => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, color }))}
                        className={`w-8 h-8 rounded-lg border-2 transition-all ${
                          formData.color === color
                            ? 'border-gray-800 dark:border-gray-200 scale-110'
                            : 'border-gray-300 hover:scale-105'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Frequency & Target */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="frequency">Frequency</Label>
                  <Select
                    value={formData.frequency}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, frequency: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="targetCount">Target Count</Label>
                  <Input
                    id="targetCount"
                    type="number"
                    min="1"
                    value={formData.targetCount}
                    onChange={(e) => setFormData(prev => ({ ...prev, targetCount: parseInt(e.target.value) }))}
                  />
                </div>
              </div>

              {/* Preview */}
              <div className="border rounded-lg p-4 bg-gray-50 dark:bg-gray-900">
                <Label className="text-sm font-medium mb-2 block">Preview</Label>
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold"
                    style={{ backgroundColor: formData.color }}
                  >
                    {formData.icon}
                  </div>
                  <div>
                    <div className="font-medium">
                      {formData.name || 'Habit Name'}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {formData.frequency} • {formData.targetCount}x
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit */}
              <div className="flex gap-2 pt-4">
                <Button
                  type="submit"
                  disabled={isLoading || !formData.name}
                  className="flex-1"
                >
                  {isLoading ? 'Creating...' : 'Create Habit'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  disabled={isLoading}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </ScaleIn>
    </div>
  );
}