import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Star, Zap, Trophy, Heart, Smile, Sparkles, Crown, Target } from 'lucide-react';
import { ScaleIn } from '@/components/animations';
import type { UserCharacter } from '@shared/schema';

interface CharacterDisplayProps {
  character: UserCharacter | null;
  isLoading: boolean;
}

const CHARACTER_TYPES = {
  bunny: {
    name: 'Healthy Bunny',
    emoji: '🐰',
    description: 'A cute and energetic bunny companion',
    color: 'from-pink-400 to-pink-600'
  },
  cat: {
    name: 'Wellness Cat',
    emoji: '🐱',
    description: 'A calm and wise feline friend',
    color: 'from-purple-400 to-purple-600'
  },
  dog: {
    name: 'Fitness Dog',
    emoji: '🐶',
    description: 'A loyal and active canine buddy',
    color: 'from-blue-400 to-blue-600'
  },
  dragon: {
    name: 'Health Dragon',
    emoji: '🐉',
    description: 'A powerful and magical dragon ally',
    color: 'from-green-400 to-green-600'
  }
};

const MOOD_EMOJIS = {
  happy: '😊',
  excited: '🤩',
  motivated: '💪',
  sleepy: '😴',
  sad: '😢'
};

export function CharacterDisplay({ character, isLoading }: CharacterDisplayProps) {
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  if (!character) {
    return (
      <Card className="card-modern">
        <CardContent className="py-12 text-center">
          <div className="text-6xl mb-4">🎭</div>
          <h3 className="text-lg font-semibold mb-2">No Character Yet</h3>
          <p className="text-muted-foreground">Complete your first habit to create your character!</p>
        </CardContent>
      </Card>
    );
  }

  const characterInfo = CHARACTER_TYPES[character.characterType as keyof typeof CHARACTER_TYPES] || CHARACTER_TYPES.bunny;
  const experienceToNextLevel = (character.level * 100) - character.experience;
  const progressToNextLevel = ((character.experience % 100) / 100) * 100;

  return (
    <div className="space-y-6">
      {/* Character Overview */}
      <ScaleIn>
        <Card className="card-modern overflow-hidden">
          <div className={`bg-gradient-to-r ${characterInfo.color} p-6 text-white`}>
            <div className="flex items-center gap-6">
              <div className="text-8xl animate-bounce">
                {characterInfo.emoji}
              </div>
              <div className="flex-1">
                <h2 className="text-3xl font-bold mb-2">{characterInfo.name}</h2>
                <p className="text-white/90 mb-4">{characterInfo.description}</p>
                <div className="flex items-center gap-4">
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    Level {character.level}
                  </Badge>
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    {MOOD_EMOJIS[character.mood as keyof typeof MOOD_EMOJIS]} {character.mood}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
          <CardContent className="p-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Experience Progress */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Experience</span>
                  <span className="text-sm text-muted-foreground">
                    {character.experience} XP
                  </span>
                </div>
                <Progress value={progressToNextLevel} className="h-3 mb-2" />
                <p className="text-sm text-muted-foreground">
                  {experienceToNextLevel} XP to level {character.level + 1}
                </p>
              </div>

              {/* Stats */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-yellow-500" />
                    Habits Completed
                  </span>
                  <span className="font-bold">{character.totalHabitsCompleted}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-orange-500" />
                    Current Streak
                  </span>
                  <span className="font-bold">{character.currentStreak} days</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-purple-500" />
                    Longest Streak
                  </span>
                  <span className="font-bold">{character.longestStreak} days</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </ScaleIn>

      {/* Character Selection */}
      <ScaleIn delay={200}>
        <Card className="card-modern">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Crown className="w-5 h-5" />
              Choose Your Character
            </CardTitle>
            <CardDescription>
              Select a different companion to represent your health journey
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(CHARACTER_TYPES).map(([type, info]) => (
                <button
                  key={type}
                  onClick={() => setSelectedCharacter(type)}
                  className={`p-4 rounded-lg border-2 transition-all text-center ${
                    character.characterType === type
                      ? 'border-primary bg-primary/10 text-primary'
                      : 'border-gray-200 hover:border-gray-300 dark:border-gray-700'
                  }`}
                >
                  <div className="text-4xl mb-2">{info.emoji}</div>
                  <div className="font-medium text-sm">{info.name}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {info.description}
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </ScaleIn>

      {/* Level Milestones */}
      <ScaleIn delay={400}>
        <Card className="card-modern">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5" />
              Level Milestones
            </CardTitle>
            <CardDescription>
              Reach these levels to unlock special rewards
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { level: 5, reward: 'New character mood options', icon: '😊' },
                { level: 10, reward: 'Character customization colors', icon: '🎨' },
                { level: 15, reward: 'Special achievement badges', icon: '🏆' },
                { level: 20, reward: 'Legendary character evolution', icon: '⭐' },
                { level: 25, reward: 'Ultimate health master title', icon: '👑' },
              ].map((milestone) => (
                <div
                  key={milestone.level}
                  className={`flex items-center gap-3 p-3 rounded-lg border ${
                    character.level >= milestone.level
                      ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20'
                      : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  <div className="text-2xl">{milestone.icon}</div>
                  <div className="flex-1">
                    <div className="font-medium">Level {milestone.level}</div>
                    <div className="text-sm text-muted-foreground">
                      {milestone.reward}
                    </div>
                  </div>
                  {character.level >= milestone.level && (
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      Unlocked
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </ScaleIn>
    </div>
  );
}