import { Bot, User } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { CSSTypewriter } from "@/components/ui/css-typewriter";

interface MessageProps {
  message: {
    id: number;
    role: string;
    content: string;
    timestamp: string;
  };
  isNewMessage?: boolean;
}

export default function Message({ message, isNewMessage = false }: MessageProps) {
  const { user } = useAuth();
  const isUser = message.role === 'user';
  const timestamp = new Date(message.timestamp).toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  return (
    <div className={`flex items-start space-x-3 ${isUser ? 'justify-end' : ''}`}>
      {!isUser && (
        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
          <Bot className="w-4 h-4 text-primary-foreground" />
        </div>
      )}
      
      <div className={`max-w-md ${isUser ? 'order-first' : ''}`}>
        <div className={`rounded-lg p-4 ${
          isUser 
            ? 'bg-primary text-primary-foreground' 
            : 'bg-muted text-foreground dark:bg-muted dark:text-foreground'
        }`}>
          {!isUser && isNewMessage ? (
            <CSSTypewriter 
              text={message.content} 
              className="text-sm whitespace-pre-wrap"
              speed={80} // Fast chunks like CSS example
              chunkSize={4} // 4 letters per chunk
            />
          ) : (
            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
          )}
          <span className={`text-xs mt-2 block ${
            isUser ? 'text-primary-foreground/70' : 'text-muted-foreground'
          }`}>
            {timestamp}
          </span>
        </div>
      </div>
      
      {isUser && (
        <div className="w-8 h-8 bg-muted dark:bg-muted rounded-full flex items-center justify-center">
          {user?.profileImageUrl ? (
            <img 
              src={user.profileImageUrl} 
              alt="User" 
              className="w-8 h-8 rounded-full object-cover"
            />
          ) : (
            <User className="w-4 h-4 text-muted-foreground" />
          )}
        </div>
      )}
    </div>
  );
}
