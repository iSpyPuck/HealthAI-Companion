import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Send, Bot, User, Shield } from "lucide-react";
import Message from "./message";
import { LoadingDots } from "@/components/ui/loading-dots";

interface ChatInterfaceProps {
  conversationId: number;
}

export default function ChatInterface({ conversationId }: ChatInterfaceProps) {
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const [lastMessageCount, setLastMessageCount] = useState(0);
  const [lastMessageIds, setLastMessageIds] = useState(new Set<string>());
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ['/api/conversations', conversationId, 'messages'],
    queryFn: async () => {
      const response = await fetch(`/api/conversations/${conversationId}/messages`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch messages');
      return response.json();
    },
    refetchInterval: 3000, // Poll every 3 seconds for new messages
    enabled: !!conversationId, // Only fetch when we have a conversation ID
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const response = await apiRequest('POST', '/api/chat', {
        message: messageText,
        conversationId,
      });
      return response.json();
    },
    onMutate: async (messageText: string) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ 
        queryKey: ['/api/conversations', conversationId, 'messages'] 
      });
      
      // Snapshot the previous value
      const previousMessages = queryClient.getQueryData(['/api/conversations', conversationId, 'messages']);
      
      // Add user message to the UI immediately
      const userMessage = {
        id: Date.now(), // temporary ID
        role: 'user',
        content: messageText,
        conversationId,
        createdAt: new Date().toISOString(),
      };
      
      // Optimistically update the cache
      queryClient.setQueryData(['/api/conversations', conversationId, 'messages'], (old: any) => {
        return old ? [...old, userMessage] : [userMessage];
      });
      
      return { previousMessages };
    },
    onSuccess: (data) => {
      // Force immediate refresh of messages to get the AI response
      queryClient.invalidateQueries({ 
        queryKey: ['/api/conversations', conversationId, 'messages'] 
      });
      // Also update conversations list to show latest message
      queryClient.invalidateQueries({ 
        queryKey: ['/api/conversations'] 
      });
    },
    onError: (error, variables, context) => {
      // Roll back on error
      if (context?.previousMessages) {
        queryClient.setQueryData(['/api/conversations', conversationId, 'messages'], context.previousMessages);
      }
      
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/auth";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    // Clear the input immediately to show responsiveness
    const messageText = message;
    setMessage("");
    
    sendMessageMutation.mutate(messageText);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    
    // Update tracking for new messages
    if (messages.length > 0) {
      const newMessageIds = new Set(messages.map((msg: any) => String(msg.id)));
      setLastMessageIds(newMessageIds);
      setLastMessageCount(messages.length);
    }
  }, [messages]);

  if (isLoading) {
    return (
      <Card className="h-full">
        <CardContent className="p-6 flex items-center justify-center h-full">
          <div className="text-center">
            <Bot className="w-12 h-12 mx-auto mb-4 text-primary animate-pulse" />
            <p className="text-muted-foreground">Loading conversation...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full flex flex-col">
      {/* Chat Header */}
      <div className="p-6 border-b border-border flex-shrink-0">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
            <Bot className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">HealthAI Companion</h3>
            <p className="text-sm text-muted-foreground">Online • Responds in seconds</p>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center py-8">
            <Bot className="w-16 h-16 mx-auto mb-4 text-primary" />
            <h3 className="text-lg font-medium text-foreground mb-2">Start the conversation</h3>
            <p className="text-muted-foreground">Ask me anything about your health and I'll do my best to help!</p>
          </div>
        ) : (
          messages.map((msg: any, index: number) => {
            // Mark AI messages as new if they weren't in the previous set of message IDs
            const isNewMessage = msg.role === 'assistant' && 
                                 !lastMessageIds.has(msg.id) && 
                                 index === messages.length - 1; // Only animate the latest message
            return (
              <Message 
                key={msg.id} 
                message={msg} 
                isNewMessage={isNewMessage}
              />
            );
          })
        )}
        
        {sendMessageMutation.isPending && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-primary-foreground" />
            </div>
            <div className="bg-muted dark:bg-muted rounded-lg p-4 max-w-md">
              <LoadingDots text="Writing message" />
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="p-6 border-t border-border flex-shrink-0">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Input
              placeholder="Type your health question..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={sendMessageMutation.isPending}
              className="pr-12"
            />
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={sendMessageMutation.isPending || !message.trim()}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center space-x-2 mt-2 text-xs text-muted-foreground">
          <Shield className="w-3 h-3" />
          <span>
            Your conversations are encrypted and secure. Remember, this is not a substitute for professional medical advice.
          </span>
        </div>
      </div>
    </Card>
  );
}
