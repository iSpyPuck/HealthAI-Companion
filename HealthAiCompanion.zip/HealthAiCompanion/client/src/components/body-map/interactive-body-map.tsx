import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { z } from 'zod';
import { X, MapPin, AlertCircle, Plus } from 'lucide-react';
import { FadeIn } from '@/components/animations/fade-in';
import { ScaleIn } from '@/components/animations/scale-in';
// Use the body diagram image
const bodyDiagramImage = '/body-diagram-full.png';
import { insertBodySymptomSchema, type BodySymptom } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

const bodyPartOptions = [
  'Head', 'Neck', 'Chest', 'Left Arm', 'Right Arm', 'Left Hand', 'Right Hand',
  'Abdomen', 'Back', 'Left Leg', 'Right Leg', 'Left Foot', 'Right Foot'
];

const symptomTypeOptions = [
  'Pain', 'Ache', 'Stiffness', 'Swelling', 'Rash', 'Itching', 'Burning',
  'Numbness', 'Tingling', 'Weakness', 'Cramp', 'Other'
];

const symptomFormSchema = insertBodySymptomSchema.extend({
  severity: z.number().min(1).max(10),
});

type SymptomFormData = z.infer<typeof symptomFormSchema>;

interface InteractiveBodyMapProps {
  className?: string;
}

export function InteractiveBodyMap({ className }: InteractiveBodyMapProps) {
  const [selectedPosition, setSelectedPosition] = useState<{ x: number; y: number } | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const form = useForm<SymptomFormData>({
    resolver: zodResolver(symptomFormSchema),
    defaultValues: {
      bodyPart: '',
      symptomType: '',
      severity: 5,
      description: '',
      xPosition: 0,
      yPosition: 0,
    },
  });

  // Fetch existing symptoms
  const { data: symptoms = [], isLoading } = useQuery<BodySymptom[]>({
    queryKey: ['/api/body-symptoms'],
  });

  // Add new symptom mutation
  const addSymptomMutation = useMutation({
    mutationFn: (data: SymptomFormData) => 
      fetch('/api/body-symptoms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(data),
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/body-symptoms'] });
      setIsDialogOpen(false);
      setSelectedPosition(null);
      form.reset();
    },
  });

  // Delete symptom mutation
  const deleteSymptomMutation = useMutation({
    mutationFn: (id: number) => 
      fetch(`/api/body-symptoms/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/body-symptoms'] });
    },
  });

  const handleBodyClick = useCallback((event: React.MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 100;
    const y = ((event.clientY - rect.top) / rect.height) * 100;
    
    setSelectedPosition({ x, y });
    form.setValue('xPosition', Math.round(x));
    form.setValue('yPosition', Math.round(y));
    setIsDialogOpen(true);
  }, [form]);

  const onSubmit = (data: SymptomFormData) => {
    if (selectedPosition) {
      addSymptomMutation.mutate({
        ...data,
        xPosition: selectedPosition.x,
        yPosition: selectedPosition.y,
      });
    }
  };

  const getSeverityColor = (severity: number) => {
    if (severity <= 3) return 'bg-green-500';
    if (severity <= 6) return 'bg-yellow-500';
    if (severity <= 8) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getSeverityLabel = (severity: number) => {
    if (severity <= 3) return 'Mild';
    if (severity <= 6) return 'Moderate';
    if (severity <= 8) return 'Severe';
    return 'Critical';
  };

  return (
    <div className={className}>
      <FadeIn>
        <Card className="card-modern">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-primary" />
              Interactive Body Symptom Map
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Click on the body diagram to mark areas where you're experiencing symptoms
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Body Diagram */}
              <div className="relative">
                <div
                  className="relative w-full max-w-md mx-auto cursor-crosshair border-2 border-dashed border-muted-foreground/20 rounded-lg overflow-hidden hover:border-primary/50 transition-colors"
                  onClick={handleBodyClick}
                  style={{ aspectRatio: '1/1.5' }}
                >
                  <img
                    src={bodyDiagramImage}
                    alt="Body Diagram"
                    className="w-full h-full object-contain"
                  />
                  
                  {/* Existing symptom markers */}
                  {symptoms.map((symptom) => (
                    <div
                      key={symptom.id}
                      className="absolute w-6 h-6 rounded-full border-2 border-white shadow-lg cursor-pointer transform -translate-x-1/2 -translate-y-1/2 hover:scale-110 transition-transform group"
                      style={{
                        left: `${symptom.xPosition}%`,
                        top: `${symptom.yPosition}%`,
                      }}
                    >
                      <div className={`w-full h-full rounded-full ${getSeverityColor(symptom.severity)}`} />
                      
                      {/* Tooltip */}
                      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-black text-white px-2 py-1 rounded text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity z-10">
                        {symptom.bodyPart}: {symptom.symptomType} ({getSeverityLabel(symptom.severity)})
                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-black" />
                      </div>
                      
                      {/* Delete button */}
                      <Button
                        variant="destructive"
                        size="sm"
                        className="absolute -top-2 -right-2 w-4 h-4 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteSymptomMutation.mutate(symptom.id);
                        }}
                        disabled={deleteSymptomMutation.isPending}
                      >
                        <X className="w-2 h-2" />
                      </Button>
                    </div>
                  ))}
                  
                  {/* Selected position indicator */}
                  {selectedPosition && (
                    <div
                      className="absolute w-8 h-8 border-4 border-primary rounded-full animate-pulse transform -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                      style={{
                        left: `${selectedPosition.x}%`,
                        top: `${selectedPosition.y}%`,
                      }}
                    />
                  )}
                </div>
                
                <div className="mt-4 text-center text-sm text-muted-foreground">
                  <div className="flex items-center justify-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-green-500" />
                      <span>Mild (1-3)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-yellow-500" />
                      <span>Moderate (4-6)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-orange-500" />
                      <span>Severe (7-8)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500" />
                      <span>Critical (9-10)</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Symptom List */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Current Symptoms</h3>
                  <Badge variant="secondary">
                    {symptoms.length} symptoms tracked
                  </Badge>
                </div>
                
                {isLoading ? (
                  <div className="space-y-3">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-16 bg-muted rounded-lg" />
                      </div>
                    ))}
                  </div>
                ) : symptoms.length === 0 ? (
                  <ScaleIn delay={200}>
                    <Card className="border-dashed">
                      <CardContent className="p-6 text-center">
                        <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                        <h4 className="text-lg font-semibold mb-2">No Symptoms Tracked</h4>
                        <p className="text-muted-foreground mb-4">
                          Click on the body diagram to start tracking your symptoms
                        </p>
                      </CardContent>
                    </Card>
                  </ScaleIn>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {symptoms.map((symptom, index) => (
                      <ScaleIn key={symptom.id} delay={index * 100}>
                        <Card className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <Badge variant="outline">{symptom.bodyPart}</Badge>
                                  <Badge variant="secondary">{symptom.symptomType}</Badge>
                                  <div className={`w-3 h-3 rounded-full ${getSeverityColor(symptom.severity)}`} />
                                  <span className="text-sm font-medium">
                                    {getSeverityLabel(symptom.severity)} ({symptom.severity}/10)
                                  </span>
                                </div>
                                {symptom.description && (
                                  <p className="text-sm text-muted-foreground">
                                    {symptom.description}
                                  </p>
                                )}
                                <p className="text-xs text-muted-foreground mt-2">
                                  Added {new Date(symptom.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteSymptomMutation.mutate(symptom.id)}
                                disabled={deleteSymptomMutation.isPending}
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      </ScaleIn>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </FadeIn>

      {/* Add Symptom Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Symptom</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="bodyPart"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Body Part</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select body part" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {bodyPartOptions.map((part) => (
                            <SelectItem key={part} value={part}>
                              {part}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="symptomType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Symptom Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select symptom" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {symptomTypeOptions.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="severity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Severity: {getSeverityLabel(field.value)} ({field.value}/10)
                    </FormLabel>
                    <FormControl>
                      <div className="px-2">
                        <Slider
                          min={1}
                          max={10}
                          step={1}
                          value={[field.value]}
                          onValueChange={(value) => field.onChange(value[0])}
                          className="w-full"
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Describe your symptom in more detail..."
                        className="resize-none"
                        value={field.value || ''}
                        onChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={addSymptomMutation.isPending}
                  className="flex-1"
                >
                  {addSymptomMutation.isPending ? 'Adding...' : 'Add Symptom'}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}