import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Calendar, Star, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { HealthTip } from "@shared/schema";
import { Link } from "wouter";

export default function DailyTipPreview() {
  const { data: dailyTip, isLoading } = useQuery<HealthTip>({
    queryKey: ['/api/health-tips/daily'],
    refetchOnWindowFocus: false,
    staleTime: 24 * 60 * 60 * 1000, // Cache for 24 hours
  });

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      hydration: "from-blue-500 to-cyan-400",
      exercise: "from-green-500 to-emerald-400", 
      nutrition: "from-orange-500 to-yellow-400",
      sleep: "from-purple-500 to-indigo-400",
      mental: "from-pink-500 to-rose-400",
      habits: "from-teal-500 to-blue-400",
      preventive: "from-red-500 to-pink-400",
      social: "from-indigo-500 to-purple-400"
    };
    return colors[category] || "from-gray-500 to-gray-400";
  };

  if (isLoading || !dailyTip) {
    return (
      <Card className="card-modern bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-900">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3 mb-3">
            <Calendar className="h-5 w-5 text-blue-500" />
            <h3 className="font-semibold text-gray-800 dark:text-gray-200">
              Today's Health Tip
            </h3>
          </div>
          <div className="animate-pulse">
            <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-3/4 mb-2"></div>
            <div className="h-2 bg-gray-300 dark:bg-gray-600 rounded w-full mb-1"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <Card className={`card-modern overflow-hidden bg-gradient-to-r ${getCategoryColor(dailyTip.category)} shadow-lg hover:shadow-xl transition-all duration-300`}>
        <CardContent className="p-4 text-white relative">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center space-x-2">
              <motion.div
                animate={{ rotate: [0, 5, -5, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <Calendar className="h-5 w-5 drop-shadow-lg" />
              </motion.div>
              <h3 className="font-bold drop-shadow-lg text-sm">Today's Health Tip</h3>
            </div>
            <div className="flex items-center text-xs">
              <Star className="h-3 w-3 mr-1" />
              {dailyTip.points}
            </div>
          </div>

          <h4 className="font-bold text-sm mb-2 drop-shadow-lg line-clamp-2">
            {dailyTip.title}
          </h4>
          
          <p className="text-white/90 text-xs line-clamp-2 mb-3 drop-shadow-sm">
            {dailyTip.content}
          </p>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {dailyTip.categories && dailyTip.categories.length > 0 ? 
                <span className="px-2 py-1 bg-white/20 backdrop-blur-sm rounded text-xs border border-white/30">
                  {dailyTip.categories[0]}
                </span> : 
                <span className="px-2 py-1 bg-white/20 backdrop-blur-sm rounded text-xs border border-white/30">
                  {dailyTip.category}
                </span>
              }
            </div>
            
            <Link href="/health-tips">
              <Button 
                size="sm" 
                className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/30 text-white text-xs px-3 py-1 h-7"
              >
                View More
                <ArrowRight className="h-3 w-3 ml-1" />
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}