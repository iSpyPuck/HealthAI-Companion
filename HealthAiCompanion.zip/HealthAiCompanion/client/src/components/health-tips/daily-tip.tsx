import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Calendar, Clock, Award, RefreshCw, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { HealthTip } from "@shared/schema";

// Animated sparkle component
const AnimatedSparkle = ({ delay = 0 }: { delay?: number }) => (
  <motion.div
    className="absolute"
    initial={{ scale: 0, rotate: 0 }}
    animate={{ 
      scale: [0, 1, 0], 
      rotate: [0, 180, 360],
      opacity: [0, 1, 0]
    }}
    transition={{
      duration: 2,
      repeat: Infinity,
      delay,
      ease: "easeInOut"
    }}
  >
    <Sparkles className="h-4 w-4 text-yellow-400" />
  </motion.div>
);

// Floating particles animation
const FloatingParticle = ({ index }: { index: number }) => (
  <motion.div
    className="absolute w-1 h-1 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full"
    initial={{ 
      x: Math.random() * 300,
      y: Math.random() * 200,
      opacity: 0.7
    }}
    animate={{
      x: Math.random() * 300,
      y: Math.random() * 200,
      opacity: [0.3, 0.8, 0.3]
    }}
    transition={{
      duration: 4 + index,
      repeat: Infinity,
      ease: "easeInOut"
    }}
  />
);

export default function DailyHealthTip() {
  const [isCompleted, setIsCompleted] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);

  const { data: dailyTip, isLoading, error, refetch } = useQuery<HealthTip>({
    queryKey: ['/api/health-tips/daily'],
    refetchOnWindowFocus: false,
    staleTime: 24 * 60 * 60 * 1000, // Cache for 24 hours
  });

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      hydration: "from-blue-500 to-cyan-400",
      exercise: "from-green-500 to-emerald-400", 
      nutrition: "from-orange-500 to-yellow-400",
      sleep: "from-purple-500 to-indigo-400",
      mental: "from-pink-500 to-rose-400",
      habits: "from-teal-500 to-blue-400",
      preventive: "from-red-500 to-pink-400",
      social: "from-indigo-500 to-purple-400"
    };
    return colors[category] || "from-gray-500 to-gray-400";
  };

  const handleComplete = async () => {
    if (!dailyTip || isCompleted) return;

    try {
      const response = await fetch(`/api/health-tips/${dailyTip.id}/complete`, {
        method: 'POST',
        credentials: 'include'
      });
      
      if (response.ok) {
        setIsCompleted(true);
        setShowCelebration(true);
        
        // Hide celebration after 3 seconds
        setTimeout(() => setShowCelebration(false), 3000);
      }
    } catch (error) {
      console.error('Error completing daily tip:', error);
    }
  };

  if (isLoading) {
    return (
      <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-900">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-4">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            >
              <Calendar className="h-6 w-6 text-blue-500" />
            </motion.div>
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">
              Health Tip of the Day
            </h3>
          </div>
          <div className="animate-pulse">
            <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-full mb-1"></div>
            <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error || !dailyTip) {
    return (
      <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20">
        <CardContent className="p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">
            Health Tip of the Day
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Unable to load today's tip
          </p>
          <Button 
            onClick={() => refetch()}
            variant="outline"
            className="hover:scale-105 transition-transform duration-200"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <Card className={`relative overflow-hidden border-0 bg-gradient-to-br ${getCategoryColor(dailyTip.category)} shadow-2xl`}>
        {/* Animated background particles */}
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 8 }).map((_, i) => (
            <FloatingParticle key={i} index={i} />
          ))}
        </div>

        {/* Animated sparkles */}
        <div className="absolute top-4 right-4">
          <AnimatedSparkle delay={0} />
        </div>
        <div className="absolute top-8 right-8">
          <AnimatedSparkle delay={0.5} />
        </div>
        <div className="absolute top-6 right-12">
          <AnimatedSparkle delay={1} />
        </div>

        {/* Celebration overlay */}
        <AnimatePresence>
          {showCelebration && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-blue-400/20 flex items-center justify-center z-20"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="text-center"
              >
                <motion.div
                  animate={{ 
                    scale: [1, 1.2, 1],
                    rotate: [0, 10, -10, 0]
                  }}
                  transition={{ duration: 0.8, repeat: 2 }}
                >
                  <CheckCircle className="h-16 w-16 text-green-400 mx-auto mb-2" />
                </motion.div>
                <p className="text-white font-bold text-lg">Great job!</p>
                <p className="text-white/90">+{dailyTip.points} points earned</p>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <CardContent className="p-6 relative z-10">
          <div className="flex items-center justify-between mb-4">
            <motion.div 
              className="flex items-center space-x-3"
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <motion.div
                animate={{ 
                  scale: [1, 1.1, 1],
                  rotate: [0, 5, -5, 0]
                }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Calendar className="h-6 w-6 text-white drop-shadow-lg" />
              </motion.div>
              <h3 className="text-lg font-bold text-white drop-shadow-lg">
                Health Tip of the Day
              </h3>
            </motion.div>
            
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.4, type: "spring", stiffness: 200 }}
              className="text-right"
            >
              <div className="flex items-center text-white/90 text-sm mb-1">
                <Award className="h-4 w-4 mr-1" />
                {dailyTip.points} points
              </div>
              <div className="flex items-center text-white/90 text-sm">
                <Clock className="h-4 w-4 mr-1" />
                {dailyTip.estimatedTime} min
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="mb-4"
          >
            <h4 className="text-xl font-bold text-white mb-3 drop-shadow-lg">
              {dailyTip.title}
            </h4>
            <p className="text-white/95 leading-relaxed drop-shadow-sm">
              {dailyTip.content}
            </p>
          </motion.div>

          <motion.div 
            className="flex items-center justify-between"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <div className="flex flex-wrap gap-2">
              {/* Show categories if available */}
              {dailyTip.categories && dailyTip.categories.length > 0 ? 
                dailyTip.categories.slice(0, 3).map((cat, index) => (
                  <motion.span
                    key={index}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-xs font-medium text-white border border-white/30"
                  >
                    {cat}
                  </motion.span>
                )) : (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.6 }}
                    className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-xs font-medium text-white border border-white/30"
                  >
                    {dailyTip.category}
                  </motion.span>
                )}
            </div>

            {!isCompleted && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.7, type: "spring", stiffness: 200 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  onClick={handleComplete}
                  className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/30 text-white font-medium px-6 py-2 rounded-full transition-all duration-300 hover:shadow-lg"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Complete
                </Button>
              </motion.div>
            )}

            {isCompleted && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="flex items-center text-white/90 font-medium"
              >
                <CheckCircle className="h-5 w-5 mr-2 text-green-300" />
                Completed!
              </motion.div>
            )}
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
}