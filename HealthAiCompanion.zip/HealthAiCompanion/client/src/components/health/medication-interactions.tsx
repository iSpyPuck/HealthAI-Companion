import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, AlertTriangle, CheckCircle, Info, RefreshCw, Pill } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import FadeIn from "@/components/ui/fade-in";

interface InteractionResult {
  severity: 'low' | 'moderate' | 'high';
  description: string;
  recommendation: string;
  medications: string[];
}

export default function MedicationInteractions() {
  const [interactionResults, setInteractionResults] = useState<InteractionResult[]>([]);
  const { toast } = useToast();

  const { data: medications = [] } = useQuery({
    queryKey: ['/api/medications'],
  });

  const activeMedications = medications.filter(med => med.isActive);

  const checkInteractionsMutation = useMutation({
    mutationFn: async () => {
      const medicationNames = activeMedications.map(med => med.name).join(', ');
      const response = await apiRequest('POST', '/api/medications/analyze-interactions', {
        medications: medicationNames
      });
      return response.json();
    },
    onSuccess: (data) => {
      // Parse AI response into structured format
      const interactions = parseInteractionResponse(data.analysis);
      setInteractionResults(interactions);
      toast({
        title: "Interaction Analysis Complete",
        description: `Found ${interactions.length} potential interactions to review`,
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: "Unable to analyze medication interactions. Please try again.",
        variant: "destructive",
      });
    },
  });

  const parseInteractionResponse = (analysis: string): InteractionResult[] => {
    // This is a simplified parser - in a real app, you'd have more sophisticated parsing
    const interactions: InteractionResult[] = [];
    
    // Look for common interaction patterns in AI response
    const lines = analysis.split('\n');
    let currentInteraction: Partial<InteractionResult> = {};
    
    for (const line of lines) {
      if (line.includes('HIGH RISK') || line.includes('SEVERE')) {
        currentInteraction.severity = 'high';
      } else if (line.includes('MODERATE') || line.includes('CAUTION')) {
        currentInteraction.severity = 'moderate';
      } else if (line.includes('LOW') || line.includes('MINOR')) {
        currentInteraction.severity = 'low';
      }
      
      if (line.includes('Interaction:') || line.includes('Warning:')) {
        currentInteraction.description = line.replace(/^.*?:|Warning:|Interaction:/, '').trim();
      }
      
      if (line.includes('Recommendation:') || line.includes('Advice:')) {
        currentInteraction.recommendation = line.replace(/^.*?:|Recommendation:|Advice:/, '').trim();
        
        // If we have a complete interaction, add it
        if (currentInteraction.severity && currentInteraction.description) {
          interactions.push({
            severity: currentInteraction.severity,
            description: currentInteraction.description,
            recommendation: currentInteraction.recommendation || 'Consult your healthcare provider',
            medications: activeMedications.map(med => med.name)
          });
          currentInteraction = {};
        }
      }
    }
    
    // If no specific interactions found but we have medications, add a general assessment
    if (interactions.length === 0 && activeMedications.length > 1) {
      interactions.push({
        severity: 'low',
        description: 'No significant interactions detected between your current medications',
        recommendation: 'Continue taking medications as prescribed and consult your doctor for any concerns',
        medications: activeMedications.map(med => med.name)
      });
    }
    
    return interactions;
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'destructive';
      case 'moderate': return 'secondary';
      case 'low': return 'default';
      default: return 'secondary';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case 'moderate': return <Info className="w-4 h-4 text-yellow-600" />;
      case 'low': return <CheckCircle className="w-4 h-4 text-green-600" />;
      default: return <Info className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-6">
      <FadeIn delay={100}>
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <Pill className="w-5 h-5 text-purple-600" />
              </div>
              Medication Interaction Checker
            </CardTitle>
            <p className="text-muted-foreground">
              AI-powered analysis of potential interactions between your medications
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Active Medications: {activeMedications.length}</p>
                <p className="text-xs text-muted-foreground">
                  {activeMedications.map(med => med.name).join(', ') || 'No active medications'}
                </p>
              </div>
              <Button 
                onClick={() => checkInteractionsMutation.mutate()}
                disabled={checkInteractionsMutation.isPending || activeMedications.length < 2}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {checkInteractionsMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Check Interactions
                  </>
                )}
              </Button>
            </div>

            {activeMedications.length < 2 && (
              <Alert>
                <Info className="w-4 h-4" />
                <AlertDescription>
                  Add at least 2 active medications to check for interactions
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </FadeIn>

      {/* Interaction Results */}
      {interactionResults.length > 0 && (
        <FadeIn delay={200}>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Interaction Analysis Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {interactionResults.map((interaction, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    {getSeverityIcon(interaction.severity)}
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant={getSeverityColor(interaction.severity)}>
                          {interaction.severity.toUpperCase()} RISK
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {interaction.medications.join(' + ')}
                        </span>
                      </div>
                      <p className="text-sm font-medium text-foreground mb-2">
                        {interaction.description}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        <strong>Recommendation:</strong> {interaction.recommendation}
                      </p>
                    </div>
                  </div>
                </div>
              ))}

              <Alert>
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription>
                  <strong>Important:</strong> This analysis is for informational purposes only. 
                  Always consult with your healthcare provider before making any changes to your medications.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </FadeIn>
      )}
    </div>
  );
}