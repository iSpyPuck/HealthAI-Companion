import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Heart, 
  Target, 
  Calendar,
  AlertCircle,
  CheckCircle,
  Clock
} from "lucide-react";
import FadeIn from "@/components/ui/fade-in";
import SlideIn from "@/components/ui/slide-in";

export default function HealthInsights() {
  const { data: medications = [] } = useQuery({
    queryKey: ['/api/medications'],
  });

  const { data: healthRecords = [] } = useQuery({
    queryKey: ['/api/health-records'],
  });

  const { data: conversations = [] } = useQuery({
    queryKey: ['/api/conversations'],
  });

  // Calculate health metrics
  const activeMedications = medications.filter(med => med.isActive).length;
  const totalMedications = medications.length;
  const medicationCompliance = activeMedications > 0 ? Math.round((activeMedications / totalMedications) * 100) : 0;
  
  const recentRecords = healthRecords.filter(record => {
    const recordDate = new Date(record.createdAt);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    return recordDate > thirtyDaysAgo;
  }).length;

  const totalConversations = conversations.length;
  const recentConversations = conversations.filter(conv => {
    const convDate = new Date(conv.createdAt);
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    return convDate > sevenDaysAgo;
  }).length;

  const healthScore = Math.round((medicationCompliance * 0.4) + (recentRecords * 10) + (recentConversations * 5));

  return (
    <div className="space-y-6">
      <FadeIn delay={100}>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Health Insights</h2>
            <p className="text-muted-foreground">Your personalized health analytics and trends</p>
          </div>
          <Badge variant="secondary" className="text-sm">
            Last updated: {new Date().toLocaleDateString()}
          </Badge>
        </div>
      </FadeIn>

      {/* Health Score Overview */}
      <SlideIn delay={200} direction="up">
        <Card className="border-0 shadow-lg bg-gradient-to-r from-medical-blue/5 to-health-green/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-10 h-10 bg-medical-blue/20 rounded-full flex items-center justify-center">
                <Activity className="w-5 h-5 text-medical-blue" />
              </div>
              Overall Health Score
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold text-foreground">{healthScore}</span>
                <span className="text-muted-foreground">/100</span>
              </div>
              <Badge variant={healthScore >= 70 ? "default" : healthScore >= 40 ? "secondary" : "destructive"}>
                {healthScore >= 70 ? "Excellent" : healthScore >= 40 ? "Good" : "Needs Attention"}
              </Badge>
            </div>
            <Progress value={healthScore} className="h-2" />
            <p className="text-sm text-muted-foreground mt-2">
              Based on medication compliance, recent health records, and AI consultations
            </p>
          </CardContent>
        </Card>
      </SlideIn>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <SlideIn delay={300} direction="left">
          <Card className="border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Medication Compliance</CardTitle>
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <Target className="w-4 h-4 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{medicationCompliance}%</div>
              <p className="text-xs text-muted-foreground">
                {activeMedications} of {totalMedications} active medications
              </p>
              <div className="flex items-center gap-1 mt-2">
                <TrendingUp className="w-4 h-4 text-health-green" />
                <span className="text-xs text-health-green">+5% from last month</span>
              </div>
            </CardContent>
          </Card>
        </SlideIn>

        <SlideIn delay={400} direction="up">
          <Card className="border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Recent Health Records</CardTitle>
              <div className="w-8 h-8 bg-health-green/20 rounded-full flex items-center justify-center">
                <Heart className="w-4 h-4 text-health-green" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{recentRecords}</div>
              <p className="text-xs text-muted-foreground">
                Documents uploaded in last 30 days
              </p>
              <div className="flex items-center gap-1 mt-2">
                <Calendar className="w-4 h-4 text-medical-blue" />
                <span className="text-xs text-medical-blue">Stay up to date</span>
              </div>
            </CardContent>
          </Card>
        </SlideIn>

        <SlideIn delay={500} direction="right">
          <Card className="border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AI Consultations</CardTitle>
              <div className="w-8 h-8 bg-medical-blue/20 rounded-full flex items-center justify-center">
                <Activity className="w-4 h-4 text-medical-blue" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{recentConversations}</div>
              <p className="text-xs text-muted-foreground">
                Conversations in last 7 days
              </p>
              <div className="flex items-center gap-1 mt-2">
                <CheckCircle className="w-4 h-4 text-health-green" />
                <span className="text-xs text-health-green">Active engagement</span>
              </div>
            </CardContent>
          </Card>
        </SlideIn>
      </div>

      {/* Health Trends */}
      <SlideIn delay={600} direction="up">
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-health-green" />
              Health Trends & Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {medicationCompliance < 80 && (
              <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-lg">
                <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                <div>
                  <p className="font-medium text-orange-800">Medication Compliance</p>
                  <p className="text-sm text-orange-700">
                    Consider setting up medication reminders to improve compliance
                  </p>
                </div>
              </div>
            )}
            
            {recentRecords === 0 && (
              <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                <Clock className="w-5 h-5 text-medical-blue mt-0.5" />
                <div>
                  <p className="font-medium text-blue-800">Health Records</p>
                  <p className="text-sm text-blue-700">
                    Upload recent test results or medical documents for better insights
                  </p>
                </div>
              </div>
            )}

            {recentConversations < 3 && (
              <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                <CheckCircle className="w-5 h-5 text-health-green mt-0.5" />
                <div>
                  <p className="font-medium text-green-800">AI Health Consultations</p>
                  <p className="text-sm text-green-700">
                    Regular check-ins with our AI assistant can help track your health better
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </SlideIn>
    </div>
  );
}