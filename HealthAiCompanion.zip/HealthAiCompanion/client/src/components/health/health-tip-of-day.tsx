import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Lightbulb, 
  Heart, 
  Activity, 
  Apple, 
  Droplets, 
  Sun, 
  Moon, 
  Zap,
  RefreshCw
} from 'lucide-react';
import { FadeIn } from '@/components/animations/fade-in';
import { ScaleIn } from '@/components/animations/scale-in';
import { cn } from '@/lib/utils';

interface HealthTip {
  id: number;
  title: string;
  content: string;
  category: 'nutrition' | 'exercise' | 'sleep' | 'hydration' | 'mental' | 'general';
  icon: any;
  color: string;
  bgColor: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

const healthTips: HealthTip[] = [
  {
    id: 1,
    title: "Stay Hydrated",
    content: "Drink at least 8 glasses of water daily. Start your morning with a glass of water to kickstart your metabolism and keep your body functioning optimally.",
    category: 'hydration',
    icon: Droplets,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    difficulty: 'easy'
  },
  {
    id: 2,
    title: "Take a 10-Minute Walk",
    content: "A short walk after meals can help improve digestion and blood sugar levels. Even light activity makes a significant difference to your health.",
    category: 'exercise',
    icon: Activity,
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    difficulty: 'easy'
  },
  {
    id: 3,
    title: "Eat Colorful Foods",
    content: "Include fruits and vegetables of different colors in your meals. Each color provides unique nutrients and antioxidants your body needs.",
    category: 'nutrition',
    icon: Apple,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    difficulty: 'medium'
  },
  {
    id: 4,
    title: "Practice Deep Breathing",
    content: "Take 5 minutes to practice deep breathing. Inhale for 4 counts, hold for 4, exhale for 6. This reduces stress and improves focus.",
    category: 'mental',
    icon: Heart,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    difficulty: 'easy'
  },
  {
    id: 5,
    title: "Get Morning Sunlight",
    content: "Spend 10-15 minutes in natural sunlight each morning. This helps regulate your circadian rhythm and improves mood and energy.",
    category: 'general',
    icon: Sun,
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-50',
    difficulty: 'easy'
  },
  {
    id: 6,
    title: "Create a Sleep Routine",
    content: "Go to bed at the same time each night. Avoid screens 1 hour before sleep and keep your bedroom cool and dark for better rest.",
    category: 'sleep',
    icon: Moon,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    difficulty: 'medium'
  },
  {
    id: 7,
    title: "Stretch Your Body",
    content: "Do 5 minutes of gentle stretching every few hours, especially if you sit at a desk. Focus on your neck, shoulders, and back.",
    category: 'exercise',
    icon: Zap,
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50',
    difficulty: 'easy'
  }
];

export function HealthTipOfDay() {
  const [currentTip, setCurrentTip] = useState<HealthTip>(healthTips[0]);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showIcon, setShowIcon] = useState(true);

  // Get today's tip based on date
  const getTodaysTip = () => {
    const today = new Date();
    const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
    return healthTips[dayOfYear % healthTips.length];
  };

  // Initialize with today's tip
  useEffect(() => {
    setCurrentTip(getTodaysTip());
  }, []);

  const refreshTip = () => {
    setIsAnimating(true);
    setShowIcon(false);
    
    setTimeout(() => {
      const randomTip = healthTips[Math.floor(Math.random() * healthTips.length)];
      setCurrentTip(randomTip);
      setShowIcon(true);
      setIsAnimating(false);
    }, 300);
  };

  const getDifficultyBadge = (difficulty: string) => {
    const colors = {
      easy: 'bg-green-100 text-green-800',
      medium: 'bg-yellow-100 text-yellow-800', 
      hard: 'bg-red-100 text-red-800'
    };
    return colors[difficulty as keyof typeof colors] || colors.easy;
  };

  const IconComponent = currentTip.icon;

  return (
    <FadeIn delay={200}>
      <Card className="relative overflow-hidden border-0 shadow-lg bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/5"></div>
        
        <CardHeader className="relative pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <ScaleIn delay={400}>
                <div 
                  className={cn(
                    "p-2 rounded-full transition-all duration-500",
                    currentTip.bgColor,
                    "dark:bg-opacity-20",
                    showIcon ? 'scale-100 rotate-0' : 'scale-75 rotate-180',
                    isAnimating && 'animate-pulse'
                  )}
                >
                  {showIcon && (
                    <IconComponent 
                      className={cn(
                        "w-5 h-5 transition-all duration-300",
                        currentTip.color
                      )} 
                    />
                  )}
                </div>
              </ScaleIn>
              
              <div>
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Lightbulb className="w-4 h-4 text-primary animate-pulse" />
                  Health Tip of the Day
                </CardTitle>
                <div className="flex items-center gap-2 mt-1">
                  <Badge 
                    variant="secondary" 
                    className={cn(
                      "text-xs font-medium transition-all duration-300",
                      getDifficultyBadge(currentTip.difficulty)
                    )}
                  >
                    {currentTip.difficulty}
                  </Badge>
                  <Badge variant="outline" className="text-xs capitalize">
                    {currentTip.category}
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-1">
              <Button
                size="sm"
                variant="ghost"
                onClick={refreshTip}
                disabled={isAnimating}
                className="hover:bg-primary/10 transition-all duration-200 hover:scale-105"
              >
                <RefreshCw 
                  className={cn(
                    "w-4 h-4",
                    isAnimating && "animate-spin"
                  )} 
                />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="relative">
          <div className={cn(
            "transition-all duration-500 ease-in-out",
            isAnimating ? 'opacity-0 translate-y-2' : 'opacity-100 translate-y-0'
          )}>
            <h3 className="font-semibold text-foreground mb-2 text-base">
              {currentTip.title}
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed mb-3">
              {currentTip.content}
            </p>
            
            <div className="flex items-center justify-between">
              <a
                href="/health-tips"
                className="text-xs text-primary hover:text-primary/80 transition-colors duration-200 flex items-center gap-1 hover:underline"
              >
                View all tips
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                </svg>
              </a>
            </div>
          </div>

          {/* Decorative micro-animations */}
          <div className="absolute bottom-2 right-2 opacity-10">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent animate-pulse"></div>
          </div>
          
          <div className="absolute top-2 right-4 opacity-5">
            <div className="w-8 h-8 rounded-full bg-primary animate-bounce" style={{animationDelay: '1s', animationDuration: '2s'}}></div>
          </div>

          {/* Floating particles */}
          <div className="absolute top-4 left-4 opacity-10">
            <div className="w-2 h-2 rounded-full bg-accent animate-ping" style={{animationDelay: '0.5s', animationDuration: '3s'}}></div>
          </div>
          
          <div className="absolute bottom-8 left-8 opacity-10">
            <div className="w-1 h-1 rounded-full bg-primary animate-ping" style={{animationDelay: '2s', animationDuration: '4s'}}></div>
          </div>
        </CardContent>

        {/* Progress indicator for tip rotation */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200 dark:bg-gray-700">
          <div 
            className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-1000 ease-in-out"
            style={{width: `${((new Date().getHours() * 60 + new Date().getMinutes()) / 1440) * 100}%`}}
          ></div>
        </div>
      </Card>
    </FadeIn>
  );
}