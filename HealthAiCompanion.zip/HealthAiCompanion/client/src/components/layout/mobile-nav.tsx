import { Link, useLocation } from "wouter";
import { 
  MessageCircle, 
  FileText, 
  Pill, 
  Calendar, 
  Home,
  BarChart3,
  Brain,
  Target,
  Lightbulb,
  Activity
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Chat", href: "/chat", icon: MessageCircle },
  { name: "Tips", href: "/health-tips", icon: Lightbulb },
  { name: "Body", href: "/symptom-mapping", icon: Activity },
  { name: "Reports", href: "/reports", icon: BarChart3 },
];

export default function MobileNav() {
  const [location] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-background border-t md:hidden">
      <nav className="grid grid-cols-5 gap-1 p-2">
        {navigation.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-md text-xs font-medium transition-colors ${
                isActive
                  ? "bg-medical-blue text-white"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-xs">{item.name}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}