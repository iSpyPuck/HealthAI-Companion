import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/lib/theme-provider";
import { 
  MessageCircle, 
  FileText, 
  Pill, 
  Calendar, 
  Home, 
  LogOut, 
  Moon, 
  Sun, 
  User,
  Menu,
  Settings,
  BarChart3,
  HelpCircle,
  Heart,
  Brain,
  Target,
  Lightbulb
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { useState } from "react";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Chat", href: "/chat", icon: MessageCircle },
  { name: "Health Tips", href: "/health-tips", icon: Lightbulb },
  { name: "Symptom Analysis", href: "/symptom-analysis", icon: Brain },
  { name: "Habit Tracker", href: "/habit-tracker", icon: Target },
  { name: "Records", href: "/records", icon: FileText },
  { name: "Medications", href: "/medications", icon: Pill },
  { name: "Appointments", href: "/appointments", icon: Calendar },
];

export default function Header() {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();
  const { user, logoutMutation } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
      <div className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-medical-blue rounded-2xl flex items-center justify-center shadow-lg">
            <span className="text-white font-bold text-lg">H</span>
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-xl text-foreground">HealthAI Companion</span>
            <span className="text-xs text-muted-foreground hidden sm:block">by Quinn Bradley</span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover:scale-105 hover:shadow-md relative ${
                  isActive
                    ? "bg-medical-blue text-white shadow-lg"
                    : "text-foreground hover:text-foreground hover:bg-accent"
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="whitespace-nowrap">{item.name}</span>
              </Link>
            );
          })}
        </nav>

        {/* Right Side Actions */}
        <div className="flex items-center space-x-3">
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            className="rounded-lg hover:scale-110 transition-all duration-200 hover:rotate-180"
          >
            {theme === "light" ? (
              <Moon className="w-4 h-4 text-foreground" />
            ) : (
              <Sun className="w-4 h-4 text-foreground" />
            )}
          </Button>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="flex items-center space-x-2 rounded-lg hover:scale-105 transition-all duration-200">
                <div className="w-8 h-8 bg-health-green rounded-full flex items-center justify-center hover:shadow-lg transition-shadow">
                  <User className="w-4 h-4 text-white" />
                </div>
                <span className="hidden sm:inline font-medium text-foreground">
                  {user?.email?.split('@')[0] || 'User'}
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <Link href="/profile">
                <DropdownMenuItem>
                  <Settings className="w-4 h-4 mr-2" />
                  Profile & Settings
                </DropdownMenuItem>
              </Link>
              <Link href="/reports">
                <DropdownMenuItem>
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Health Reports
                </DropdownMenuItem>
              </Link>
              <Link href="/emergency">
                <DropdownMenuItem>
                  <Heart className="w-4 h-4 mr-2" />
                  Emergency Contacts
                </DropdownMenuItem>
              </Link>
              <Link href="/help">
                <DropdownMenuItem>
                  <HelpCircle className="w-4 h-4 mr-2" />
                  Help & Support
                </DropdownMenuItem>
              </Link>
              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <nav className="container py-4 space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-medical-blue text-white"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      )}
    </header>
  );
}