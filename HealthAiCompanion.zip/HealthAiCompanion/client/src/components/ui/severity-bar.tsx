import { cn } from '@/lib/utils';

interface SeverityBarProps {
  level: number; // 1-10 scale
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  showValue?: boolean;
}

export function SeverityBar({ 
  level, 
  className, 
  size = 'md', 
  showLabel = true, 
  showValue = true 
}: SeverityBarProps) {
  const clampedLevel = Math.max(1, Math.min(10, level));
  const percentage = (clampedLevel / 10) * 100;
  
  const getSeverityColor = (level: number) => {
    if (level <= 3) return 'bg-green-500';
    if (level <= 6) return 'bg-yellow-500';
    if (level <= 8) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getSeverityText = (level: number) => {
    if (level <= 3) return 'Mild';
    if (level <= 6) return 'Moderate';
    if (level <= 8) return 'Severe';
    return 'Critical';
  };

  const sizeClasses = {
    sm: 'h-2',
    md: 'h-3',
    lg: 'h-4'
  };

  return (
    <div className={cn("space-y-2", className)}>
      {showLabel && (
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-foreground">
            Severity Level
          </span>
          {showValue && (
            <span className="text-sm font-medium text-foreground">
              {getSeverityText(clampedLevel)} ({clampedLevel}/10)
            </span>
          )}
        </div>
      )}
      
      <div className="relative">
        {/* Background bar */}
        <div className={cn(
          "w-full rounded-full bg-muted/50 border border-border",
          sizeClasses[size]
        )}>
          {/* Filled portion */}
          <div
            className={cn(
              "h-full rounded-full transition-all duration-500 ease-out",
              getSeverityColor(clampedLevel),
              "shadow-sm"
            )}
            style={{ width: `${percentage}%` }}
          />
        </div>
        
        {/* Scale markers */}
        <div className="absolute top-0 left-0 w-full h-full flex items-center">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((marker) => (
            <div
              key={marker}
              className="flex-1 relative"
              style={{ width: '10%' }}
            >
              {marker % 2 === 0 && (
                <div className="absolute top-0 left-0 w-px h-full bg-border opacity-30" />
              )}
            </div>
          ))}
        </div>
      </div>
      
      {/* Scale labels */}
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>1</span>
        <span>5</span>
        <span>10</span>
      </div>
    </div>
  );
}