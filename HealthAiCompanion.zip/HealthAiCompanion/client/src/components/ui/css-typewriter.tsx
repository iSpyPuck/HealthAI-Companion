import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';

interface CSSTypewriterProps {
  text: string;
  className?: string;
  speed?: number; // milliseconds between chunks (fast like your CSS example)
  chunkSize?: number; // letters per chunk (3-5)
  onComplete?: () => void;
}

export function CSSTypewriter({ 
  text, 
  className, 
  speed = 80, // Faster speed like the CSS example
  chunkSize = 4, // 4 letters per chunk
  onComplete 
}: CSSTypewriterProps) {
  const [displayText, setDisplayText] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const [showCursor, setShowCursor] = useState(true);

  // Function to parse **text** and make it bold
  const parseAiMessage = (text: string) => {
    if (!text) return '';
    return text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  };

  useEffect(() => {
    let currentLength = 0;
    
    const typeInterval = setInterval(() => {
      if (currentLength < text.length) {
        // Add 3-5 characters at a time
        currentLength = Math.min(currentLength + chunkSize, text.length);
        setDisplayText(text.slice(0, currentLength));
      } else {
        setIsComplete(true);
        setShowCursor(false);
        clearInterval(typeInterval);
        onComplete?.();
      }
    }, speed);

    return () => clearInterval(typeInterval);
  }, [text, speed, chunkSize, onComplete]);

  // Reset when text changes
  useEffect(() => {
    setDisplayText('');
    setIsComplete(false);
    setShowCursor(true);
  }, [text]);

  return (
    <div className={cn("typewriter-container", className)}>
      <style dangerouslySetInnerHTML={{
        __html: `
          .typewriter-container .typewriter-text {
            display: inline;
          }
          
          .typewriter-cursor {
            display: inline-block;
            background-color: hsl(var(--primary));
            margin-left: 2px;
            width: 2px;
            height: 1.2em;
            animation: blink 0.75s infinite;
          }
          
          @keyframes blink {
            0%, 50% { opacity: 1; }
            51%, 100% { opacity: 0; }
          }
          
          .typewriter-text strong {
            font-weight: bold;
          }
        `
      }} />
      
      <span 
        className="typewriter-text" 
        dangerouslySetInnerHTML={{ __html: parseAiMessage(displayText) }}
      />
      {showCursor && <span className="typewriter-cursor"></span>}
    </div>
  );
}