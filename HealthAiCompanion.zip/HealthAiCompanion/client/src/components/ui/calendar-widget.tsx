import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Button } from './button';
import { ChevronLeft, ChevronRight, Calendar, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CalendarWidgetProps {
  className?: string;
  onDateClick?: (date: Date) => void;
  onAddEvent?: (date: Date) => void;
  events?: { date: Date; title: string; type: 'medication' | 'appointment' | 'reminder' }[];
}

export function CalendarWidget({ className, onDateClick, onAddEvent, events = [] }: CalendarWidgetProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isExpanded, setIsExpanded] = useState(false);
  const [viewMode, setViewMode] = useState<'month' | 'week'>('month');

  const today = new Date();
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const firstDayOfWeek = firstDayOfMonth.getDay();
  const daysInMonth = lastDayOfMonth.getDate();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const previousMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  const previousWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() - 7);
    setCurrentDate(newDate);
  };

  const nextWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() + 7);
    setCurrentDate(newDate);
  };

  const getWeekDays = () => {
    const start = new Date(currentDate);
    start.setDate(currentDate.getDate() - currentDate.getDay());
    const days = [];
    
    for (let i = 0; i < 7; i++) {
      const day = new Date(start);
      day.setDate(start.getDate() + i);
      days.push(day);
    }
    
    return days;
  };

  const getWeekEvents = (date: Date) => {
    return events.filter(event => 
      event.date.getDate() === date.getDate() &&
      event.date.getMonth() === date.getMonth() &&
      event.date.getFullYear() === date.getFullYear()
    );
  };

  const getDayEvents = (day: number) => {
    const dayDate = new Date(year, month, day);
    return events.filter(event => 
      event.date.getDate() === day &&
      event.date.getMonth() === month &&
      event.date.getFullYear() === year
    );
  };

  const renderCalendarDays = () => {
    const days = [];
    
    // Empty cells for days before the first day of month
    for (let i = 0; i < firstDayOfWeek; i++) {
      days.push(
        <div key={`empty-${i}`} className="aspect-square p-1" />
      );
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dayDate = new Date(year, month, day);
      const isToday = day === today.getDate() && month === today.getMonth() && year === today.getFullYear();
      const dayEvents = getDayEvents(day);

      days.push(
        <div
          key={day}
          className={cn(
            "aspect-square p-1 cursor-pointer relative group transform transition-all duration-200 hover:scale-105",
            isToday && "bg-blue-100 dark:bg-blue-900/30 rounded-lg animate-pulse"
          )}
          onClick={() => onDateClick?.(dayDate)}
        >
          <div className={cn(
            "w-full h-full flex flex-col items-center justify-center rounded-lg transition-all duration-200",
            "hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:shadow-lg",
            isToday && "bg-blue-500 text-white hover:bg-blue-600"
          )}>
            <span className={cn(
              "text-sm font-medium transition-all duration-200",
              isToday ? "text-white" : "text-foreground"
            )}>
              {day}
            </span>
            {dayEvents.length > 0 && (
              <div className="flex gap-1 mt-1">
                {dayEvents.slice(0, 2).map((event, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      "w-1.5 h-1.5 rounded-full animate-bounce",
                      event.type === 'medication' && "bg-green-500",
                      event.type === 'appointment' && "bg-blue-500",
                      event.type === 'reminder' && "bg-yellow-500"
                    )}
                    style={{ animationDelay: `${idx * 0.1}s` }}
                  />
                ))}
                {dayEvents.length > 2 && (
                  <div className="w-1.5 h-1.5 rounded-full bg-gray-400 animate-pulse" />
                )}
              </div>
            )}
          </div>
          
          {/* Add event button on hover */}
          <button
            className="absolute top-1 right-1 w-4 h-4 bg-blue-500 hover:bg-blue-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all duration-200 flex items-center justify-center hover:scale-110 hover:rotate-90"
            onClick={(e) => {
              e.stopPropagation();
              onAddEvent?.(dayDate);
            }}
          >
            <Plus className="w-2 h-2" />
          </button>
        </div>
      );
    }

    return days;
  };

  if (!isExpanded) {
    return (
      <Card className={cn("card-modern", className)}>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Calendar
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(true)}
              className="text-xs hover:scale-110 transition-all duration-200"
            >
              Expand
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-sm">
                {monthNames[today.getMonth()]} {today.getFullYear()}
              </h3>
              <div className="text-xs text-muted-foreground">
                Today: {today.getDate()}
              </div>
            </div>
            
            <div className="space-y-2">
              {events.slice(0, 3).map((event, idx) => (
                <div key={idx} className="flex items-center gap-2 p-2 bg-muted/50 rounded-lg">
                  <div className={cn(
                    "w-2 h-2 rounded-full",
                    event.type === 'medication' && "bg-green-500",
                    event.type === 'appointment' && "bg-blue-500",
                    event.type === 'reminder' && "bg-yellow-500"
                  )} />
                  <span className="text-sm truncate">{event.title}</span>
                </div>
              ))}
              
              {events.length > 3 && (
                <div className="text-xs text-muted-foreground text-center">
                  +{events.length - 3} more events
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("card-modern", className)}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            {monthNames[month]} {year}
          </span>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setViewMode(viewMode === 'month' ? 'week' : 'month')}
              className="text-xs hover:scale-110 transition-all duration-200"
            >
              {viewMode === 'month' ? 'Week' : 'Month'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={goToToday}
              className="text-xs hover:scale-110 transition-all duration-200"
            >
              Today
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(false)}
              className="text-xs hover:scale-110 transition-all duration-200"
            >
              Minimize
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Navigation */}
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              size="sm"
              onClick={viewMode === 'month' ? previousMonth : previousWeek}
              className="flex items-center gap-1 hover:scale-105 transition-all duration-200"
            >
              <ChevronLeft className="w-4 h-4" />
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={viewMode === 'month' ? nextMonth : nextWeek}
              className="flex items-center gap-1 hover:scale-105 transition-all duration-200"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>

          {/* Calendar Grid */}
          {viewMode === 'month' ? (
            <div className="grid grid-cols-7 gap-1">
              {/* Day headers */}
              {dayNames.map(day => (
                <div key={day} className="text-center text-xs font-medium text-muted-foreground p-2">
                  {day}
                </div>
              ))}
              
              {/* Calendar days */}
              {renderCalendarDays()}
            </div>
          ) : (
            <div className="space-y-2">
              {/* Week View */}
              {getWeekDays().map((date, index) => {
                const dayEvents = getWeekEvents(date);
                const isToday = date.toDateString() === new Date().toDateString();
                
                return (
                  <div
                    key={date.toISOString()}
                    className={cn(
                      "flex items-center gap-4 p-3 rounded-lg border cursor-pointer transition-all duration-200 hover:scale-[1.02] hover:shadow-md",
                      isToday && "bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-600"
                    )}
                    onClick={() => onDateClick?.(date)}
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="flex flex-col items-center min-w-[60px]">
                      <div className="text-xs text-muted-foreground uppercase">
                        {dayNames[date.getDay()]}
                      </div>
                      <div className={cn(
                        "text-lg font-semibold transition-all duration-200",
                        isToday && "text-blue-600 dark:text-blue-400"
                      )}>
                        {date.getDate()}
                      </div>
                    </div>
                    
                    <div className="flex-1 space-y-1">
                      {dayEvents.length > 0 ? (
                        dayEvents.map((event, idx) => (
                          <div
                            key={idx}
                            className={cn(
                              "flex items-center gap-2 p-2 rounded-md transition-all duration-200 hover:scale-105",
                              event.type === 'medication' && "bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-300",
                              event.type === 'appointment' && "bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300",
                              event.type === 'reminder' && "bg-yellow-100 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-300"
                            )}
                          >
                            <div className={cn(
                              "w-2 h-2 rounded-full",
                              event.type === 'medication' && "bg-green-500",
                              event.type === 'appointment' && "bg-blue-500",
                              event.type === 'reminder' && "bg-yellow-500"
                            )} />
                            <span className="text-sm">{event.title}</span>
                          </div>
                        ))
                      ) : (
                        <div className="text-sm text-muted-foreground py-2">
                          No events
                        </div>
                      )}
                    </div>
                    
                    <button
                      className="w-6 h-6 bg-blue-500 hover:bg-blue-600 text-white rounded-full opacity-0 hover:opacity-100 transition-all duration-200 flex items-center justify-center hover:scale-110 hover:rotate-90"
                      onClick={(e) => {
                        e.stopPropagation();
                        onAddEvent?.(date);
                      }}
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* Legend */}
          <div className="flex items-center gap-4 pt-2 border-t">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-green-500 rounded-full" />
              <span className="text-xs">Medication</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-blue-500 rounded-full" />
              <span className="text-xs">Appointment</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-yellow-500 rounded-full" />
              <span className="text-xs">Reminder</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}