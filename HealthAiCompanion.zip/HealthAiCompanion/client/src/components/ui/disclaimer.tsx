import { Card, CardContent } from "@/components/ui/card";
import { Shield, AlertTriangle } from "lucide-react";

export default function Disclaimer() {
  return (
    <Card className="mb-8 border-l-4 border-l-coral border-border/30 bg-coral/5 shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <div className="w-12 h-12 bg-coral/20 rounded-full flex items-center justify-center flex-shrink-0">
            <Shield className="w-6 h-6 text-coral" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-coral mb-2 text-lg">Professional Medical Disclaimer</h3>
            <p className="text-sm text-charcoal leading-relaxed">
              This platform provides general health information for educational purposes only. All content is not intended to replace professional medical advice, diagnosis, or treatment. Always consult qualified healthcare providers for medical concerns. In emergency situations, contact local emergency services immediately.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
