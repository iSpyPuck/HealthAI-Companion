import { useState } from 'react';
import { cn } from '@/lib/utils';

interface MoodTrackerProps {
  onMoodSelect?: (mood: string, level: number) => void;
  className?: string;
}

const moods = [
  { emoji: '😢', label: 'Terrible', level: 1, color: 'bg-red-500', borderColor: 'border-red-500' },
  { emoji: '😟', label: 'Bad', level: 2, color: 'bg-orange-500', borderColor: 'border-orange-500' },
  { emoji: '😐', label: 'Okay', level: 3, color: 'bg-yellow-500', borderColor: 'border-yellow-500' },
  { emoji: '😊', label: 'Good', level: 4, color: 'bg-green-500', borderColor: 'border-green-500' },
  { emoji: '😄', label: 'Great', level: 5, color: 'bg-blue-500', borderColor: 'border-blue-500' },
];

export function MoodTracker({ onMoodSelect, className }: MoodTrackerProps) {
  const [selectedMood, setSelectedMood] = useState<number | null>(null);

  const handleMoodSelect = (mood: typeof moods[0]) => {
    setSelectedMood(mood.level);
    onMoodSelect?.(mood.label, mood.level);
  };

  return (
    <div className={cn("space-y-6", className)}>
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">How are you feeling today?</h3>
        <div className="w-16 h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mx-auto mb-4"></div>
      </div>
      
      {/* Modern feeling bar */}
      <div className="relative">
        <div className="flex justify-between items-center mb-4">
          <span className="text-xs text-muted-foreground font-medium">Terrible</span>
          <span className="text-xs text-muted-foreground font-medium">Great</span>
        </div>
        
        <div className="relative bg-gradient-to-r from-red-200 via-yellow-200 via-green-200 to-blue-200 dark:from-red-800/30 dark:via-yellow-800/30 dark:via-green-800/30 dark:to-blue-800/30 rounded-full h-4 border-2 border-white dark:border-gray-700 shadow-inner">
          <div className="absolute inset-0 bg-gradient-to-r from-red-400 via-yellow-400 via-green-400 to-blue-400 opacity-20 rounded-full"></div>
          
          {/* Mood indicators */}
          <div className="flex justify-between items-center h-full px-2">
            {moods.map((mood, index) => (
              <button
                key={mood.level}
                className={cn(
                  "relative w-12 h-12 rounded-full transition-all duration-300 transform",
                  "hover:scale-125 hover:shadow-lg hover:-translate-y-1",
                  "bg-white dark:bg-gray-800 border-3 shadow-lg",
                  "flex items-center justify-center group",
                  selectedMood === mood.level 
                    ? `${mood.borderColor} scale-125 -translate-y-1 shadow-xl ${mood.color}/20` 
                    : "border-gray-300 dark:border-gray-600 hover:border-primary/50",
                  "animate-bounce-in"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => handleMoodSelect(mood)}
              >
                <span className="text-2xl group-hover:scale-110 transition-transform duration-200">
                  {mood.emoji}
                </span>
                
                {/* Glow effect for selected mood */}
                {selectedMood === mood.level && (
                  <div className={cn(
                    "absolute inset-0 rounded-full animate-pulse",
                    mood.color,
                    "opacity-30 blur-sm"
                  )}></div>
                )}
                
                {/* Tooltip */}
                <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-black dark:bg-white text-white dark:text-black px-3 py-1 rounded-lg text-xs opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none shadow-lg">
                  {mood.label}
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-2 border-r-2 border-t-2 border-transparent border-t-black dark:border-t-white"></div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {selectedMood && (
        <div className="text-center animate-fade-in">
          <div className="inline-flex items-center space-x-2 bg-primary/10 dark:bg-primary/20 px-4 py-2 rounded-full border border-primary/20">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
            <p className="text-sm text-primary font-medium">
              Thanks for sharing! Your mood helps us provide better health insights.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}