import React from 'react';

interface BodyMapProps {
  selectedParts: string[];
  onPartSelect: (partId: string) => void;
  className?: string;
}

function BodyMap({ selectedParts, onPartSelect, className = "" }: BodyMapProps) {
  const bodyParts = [
    { id: 'head', name: 'Head', x: 45, y: 8, width: 10, height: 12 },
    { id: 'neck', name: 'Neck', x: 48, y: 20, width: 4, height: 6 },
    { id: 'left_shoulder', name: 'Left Shoulder', x: 35, y: 26, width: 12, height: 8 },
    { id: 'right_shoulder', name: 'Right Shoulder', x: 53, y: 26, width: 12, height: 8 },
    { id: 'chest', name: 'Chest', x: 42, y: 26, width: 16, height: 20 },
    { id: 'left_arm', name: 'Left Arm', x: 25, y: 34, width: 8, height: 25 },
    { id: 'right_arm', name: 'Right Arm', x: 67, y: 34, width: 8, height: 25 },
    { id: 'abdomen', name: 'Abdomen', x: 42, y: 46, width: 16, height: 18 },
    { id: 'left_hand', name: 'Left Hand', x: 20, y: 59, width: 8, height: 10 },
    { id: 'right_hand', name: 'Right Hand', x: 72, y: 59, width: 8, height: 10 },
    { id: 'pelvis', name: 'Pelvis', x: 42, y: 64, width: 16, height: 12 },
    { id: 'left_thigh', name: 'Left Thigh', x: 40, y: 76, width: 8, height: 20 },
    { id: 'right_thigh', name: 'Right Thigh', x: 52, y: 76, width: 8, height: 20 },
    { id: 'left_knee', name: 'Left Knee', x: 40, y: 96, width: 8, height: 6 },
    { id: 'right_knee', name: 'Right Knee', x: 52, y: 96, width: 8, height: 6 },
    { id: 'left_calf', name: 'Left Calf', x: 40, y: 102, width: 8, height: 18 },
    { id: 'right_calf', name: 'Right Calf', x: 52, y: 102, width: 8, height: 18 },
    { id: 'left_foot', name: 'Left Foot', x: 38, y: 120, width: 10, height: 8 },
    { id: 'right_foot', name: 'Right Foot', x: 52, y: 120, width: 10, height: 8 },
  ];

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-4">
        <h3 className="text-lg font-semibold text-center mb-4 text-foreground">Select Affected Body Parts</h3>
        <div className="relative inline-block">
          {/* Human body photo as background */}
          <img 
            src="/body-diagram.png"
            alt="Human body diagram" 
            className="w-80 h-auto rounded-lg border border-gray-200 dark:border-gray-700 filter dark:invert dark:contrast-150"
            style={{ maxWidth: '320px' }}
            onError={(e) => {
              console.error('Failed to load body diagram image');
              // Fallback to a theme-aware SVG diagram
              const isDark = document.documentElement.classList.contains('dark');
              const strokeColor = isDark ? '%23ffffff' : '%23000000';
              e.currentTarget.src = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 140'%3E%3Cg stroke='${strokeColor}' stroke-width='2' fill='none'%3E%3Cellipse cx='50' cy='15' rx='8' ry='10'/%3E%3Cline x1='50' y1='25' x2='50' y2='35'/%3E%3Cline x1='50' y1='35' x2='35' y2='45'/%3E%3Cline x1='50' y1='35' x2='65' y2='45'/%3E%3Cline x1='35' y1='45' x2='25' y2='70'/%3E%3Cline x1='65' y1='45' x2='75' y2='70'/%3E%3Cline x1='50' y1='35' x2='50' y2='75'/%3E%3Cline x1='50' y1='75' x2='42' y2='110'/%3E%3Cline x1='50' y1='75' x2='58' y2='110'/%3E%3Cline x1='42' y1='110' x2='38' y2='130'/%3E%3Cline x1='58' y1='110' x2='62' y2='130'/%3E%3C/g%3E%3C/svg%3E`;
            }}
          />
          
          {/* Invisible clickable hitboxes overlaying the image */}
          <svg 
            className="absolute top-0 left-0 w-full h-full"
            viewBox="0 0 100 130"
            preserveAspectRatio="none"
          >
            {bodyParts.map((part) => (
              <rect
                key={part.id}
                x={part.x}
                y={part.y}
                width={part.width}
                height={part.height}
                className={`cursor-pointer transition-all duration-200 ${
                  selectedParts?.includes(part.id) 
                    ? 'fill-red-300 stroke-red-500 opacity-60' 
                    : 'fill-transparent stroke-transparent hover:fill-blue-200 hover:stroke-blue-400 hover:opacity-30'
                }`}
                strokeWidth="2"
                onClick={() => onPartSelect(part.id)}
              />
            ))}
            
            {/* Labels for selected parts */}
            {bodyParts.map((part) => {
              if (!selectedParts?.includes(part.id)) return null;
              
              const labelX = part.x + part.width / 2;
              const labelY = part.y + part.height / 2;
              
              return (
                <g key={`${part.id}-label`}>
                  <rect
                    x={labelX - 15}
                    y={labelY - 4}
                    width="30"
                    height="8"
                    fill="#dc2626"
                    rx="2"
                    className="pointer-events-none"
                  />
                  <text
                    x={labelX}
                    y={labelY + 1}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fontSize="3"
                    fill="#ffffff"
                    className="pointer-events-none font-medium"
                  >
                    {part.name}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>
      
      {/* Selected parts display */}
      {selectedParts && selectedParts.length > 0 && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 w-full max-w-md">
          <h4 className="font-medium text-red-800 dark:text-red-200 mb-2">Selected Areas:</h4>
          <div className="flex flex-wrap gap-2">
            {selectedParts?.map((partId) => {
              const part = bodyParts.find(p => p.id === partId);
              return (
                <span 
                  key={partId}
                  className="px-3 py-1 bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-200 rounded-full text-sm border border-red-200 dark:border-red-700"
                >
                  {part?.name || partId}
                </span>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default BodyMap;
export { BodyMap };