import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface TypewriterTextProps {
  text: string;
  className?: string;
  delay?: number;
  speed?: number;
  onComplete?: () => void;
}

export function TypewriterText({ 
  text, 
  className, 
  delay = 0, 
  speed = 60,
  onComplete 
}: TypewriterTextProps) {
  const [displayText, setDisplayText] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const [currentText, setCurrentText] = useState('');

  useEffect(() => {
    if (!text || text === currentText) return;
    
    setCurrentText(text);
    setDisplayText('');
    setIsComplete(false);

    const timeout = setTimeout(() => {
      // Split text into words for word-by-word typing
      const words = text.split(' ');
      let currentWordIndex = 0;
      let currentCharIndex = 0;
      
      const interval = setInterval(() => {
        if (currentWordIndex < words.length) {
          const currentWord = words[currentWordIndex];
          
          // Type current word character by character
          if (currentCharIndex < currentWord.length) {
            const partialText = words.slice(0, currentWordIndex).join(' ') + 
              (currentWordIndex > 0 ? ' ' : '') + 
              currentWord.slice(0, currentCharIndex + 1);
            setDisplayText(partialText);
            currentCharIndex++;
          } else {
            // Move to next word
            currentWordIndex++;
            currentCharIndex = 0;
            
            // Add space after completing a word (except for the last word)
            if (currentWordIndex < words.length) {
              const completeWords = words.slice(0, currentWordIndex).join(' ') + ' ';
              setDisplayText(completeWords);
            }
          }
        } else {
          // Finished typing all words
          clearInterval(interval);
          setDisplayText(text);
          setIsComplete(true);
          onComplete?.();
        }
      }, speed);

      return () => clearInterval(interval);
    }, delay);

    return () => clearTimeout(timeout);
  }, [text, delay, speed, onComplete, currentText]);

  // Function to parse **text** and make it bold while typing
  const parseAiMessage = (text: string) => {
    if (!text) return text;
    
    // Split by **text** patterns and create JSX elements
    const parts = text.split(/\*\*(.*?)\*\*/g);
    
    return parts.map((part, index) => {
      // Every odd index is the text between **
      if (index % 2 === 1) {
        return <strong key={index} className="font-bold text-foreground">{part}</strong>;
      }
      return part;
    });
  };

  return (
    <span className={cn(className)}>
      {parseAiMessage(displayText)}
      {!isComplete && (
        <span className="animate-pulse text-primary ml-1">|</span>
      )}
    </span>
  );
}