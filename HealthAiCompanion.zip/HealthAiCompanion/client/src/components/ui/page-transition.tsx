import { ReactNode, useEffect, useState } from 'react';
import { useLocation } from 'wouter';

interface PageTransitionProps {
  children: ReactNode;
}

export default function PageTransition({ children }: PageTransitionProps) {
  const [location] = useLocation();
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [currentChildren, setCurrentChildren] = useState(children);

  useEffect(() => {
    // Start transition
    setIsTransitioning(true);
    
    // Update children after fade out
    const timer = setTimeout(() => {
      setCurrentChildren(children);
      setIsTransitioning(false);
    }, 150);

    return () => clearTimeout(timer);
  }, [location, children]);

  return (
    <div className={`transition-all duration-300 ease-in-out ${
      isTransitioning ? 'opacity-0 translate-y-2' : 'opacity-100 translate-y-0'
    }`}>
      {currentChildren}
    </div>
  );
}