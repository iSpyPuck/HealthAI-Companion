import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bell, BellOff, Check, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface NotificationSystemProps {
  className?: string;
}

export default function NotificationSystem({ className = "" }: NotificationSystemProps) {
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = async () => {
    if ('Notification' in window) {
      try {
        const result = await Notification.requestPermission();
        setPermission(result);
        
        if (result === 'granted') {
          toast({
            title: "Notifications enabled",
            description: "You'll now receive medication reminders and health alerts.",
          });
        } else {
          toast({
            title: "Notifications blocked",
            description: "You won't receive browser notifications. You can enable them in your browser settings.",
            variant: "destructive",
          });
        }
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to request notification permission.",
          variant: "destructive",
        });
      }
    } else {
      toast({
        title: "Not supported",
        description: "Your browser doesn't support notifications.",
        variant: "destructive",
      });
    }
  };

  const sendTestNotification = () => {
    if (permission === 'granted') {
      const notification = new Notification('HealthAI Companion Test', {
        body: 'This is a test notification from your health companion app.',
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        tag: 'test-notification'
      });

      notification.onclick = () => {
        window.focus();
        notification.close();
      };

      toast({
        title: "Test notification sent",
        description: "Check your browser for the notification.",
      });
    } else {
      toast({
        title: "Notifications disabled",
        description: "Please enable notifications first.",
        variant: "destructive",
      });
    }
  };

  const scheduleMedicationReminder = (medicationName: string, time: string) => {
    if (permission === 'granted') {
      const [hours, minutes] = time.split(':').map(Number);
      const now = new Date();
      const reminderTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes);
      
      // If the time has passed today, schedule for tomorrow
      if (reminderTime <= now) {
        reminderTime.setDate(reminderTime.getDate() + 1);
      }
      
      const timeUntilReminder = reminderTime.getTime() - now.getTime();
      
      setTimeout(() => {
        const notification = new Notification(`Medication Reminder: ${medicationName}`, {
          body: `It's time to take your ${medicationName}. Don't forget!`,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: `medication-${medicationName}`,
          requireInteraction: true
        });

        notification.onclick = () => {
          window.focus();
          notification.close();
        };
      }, timeUntilReminder);

      toast({
        title: "Reminder scheduled",
        description: `You'll be reminded to take ${medicationName} at ${time}.`,
      });
    }
  };

  const getPermissionStatus = () => {
    switch (permission) {
      case 'granted':
        return { text: 'Enabled', color: 'bg-green-500', icon: <Bell className="w-4 h-4" /> };
      case 'denied':
        return { text: 'Blocked', color: 'bg-red-500', icon: <BellOff className="w-4 h-4" /> };
      default:
        return { text: 'Not Set', color: 'bg-gray-500', icon: <Bell className="w-4 h-4" /> };
    }
  };

  const status = getPermissionStatus();

  return (
    <Card className={`card-modern ${className}`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Notification Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Status:</span>
            <Badge className={`${status.color} text-white`}>
              {status.icon}
              <span className="ml-1">{status.text}</span>
            </Badge>
          </div>
        </div>

        <div className="space-y-2">
          {permission === 'default' && (
            <Button 
              onClick={requestPermission}
              className="w-full bg-medical-blue hover:bg-blue-700"
            >
              <Bell className="w-4 h-4 mr-2" />
              Enable Notifications
            </Button>
          )}

          {permission === 'granted' && (
            <div className="space-y-2">
              <Button 
                onClick={sendTestNotification}
                variant="outline"
                className="w-full"
              >
                <Check className="w-4 h-4 mr-2" />
                Test Notification
              </Button>
              <p className="text-sm text-muted-foreground">
                Notifications are enabled. You'll receive medication reminders and health alerts.
              </p>
            </div>
          )}

          {permission === 'denied' && (
            <div className="space-y-2">
              <Button 
                onClick={requestPermission}
                variant="outline"
                className="w-full"
              >
                <Bell className="w-4 h-4 mr-2" />
                Try Again
              </Button>
              <p className="text-sm text-muted-foreground">
                Notifications are blocked. Please enable them in your browser settings if you want to receive health reminders.
              </p>
            </div>
          )}
        </div>

        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
          <p className="text-sm text-blue-800 dark:text-blue-200">
            <strong>What you'll receive:</strong> Medication reminders, appointment alerts, and important health notifications.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// Hook to use notification system
export const useNotifications = () => {
  const sendNotification = (title: string, body: string, options?: NotificationOptions) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      const notification = new Notification(title, {
        body,
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        ...options
      });

      notification.onclick = () => {
        window.focus();
        notification.close();
      };

      return notification;
    }
    return null;
  };

  const scheduleMedicationReminder = (medicationName: string, time: string) => {
    if (Notification.permission === 'granted') {
      const [hours, minutes] = time.split(':').map(Number);
      const now = new Date();
      const reminderTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes);
      
      if (reminderTime <= now) {
        reminderTime.setDate(reminderTime.getDate() + 1);
      }
      
      const timeUntilReminder = reminderTime.getTime() - now.getTime();
      
      setTimeout(() => {
        sendNotification(
          `Medication Reminder: ${medicationName}`,
          `It's time to take your ${medicationName}. Don't forget!`,
          {
            tag: `medication-${medicationName}`,
            requireInteraction: true
          }
        );
      }, timeUntilReminder);
    }
  };

  return {
    sendNotification,
    scheduleMedicationReminder,
    isSupported: 'Notification' in window,
    permission: 'Notification' in window ? Notification.permission : 'default'
  };
};