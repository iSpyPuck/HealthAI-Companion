import { useState, useEffect } from 'react';

interface LoadingDotsProps {
  text?: string;
  className?: string;
}

export function LoadingDots({ text = "writing message", className = "" }: LoadingDotsProps) {
  const [dots, setDots] = useState('');

  useEffect(() => {
    const interval = setInterval(() => {
      setDots(prev => {
        if (prev === '...') return '';
        return prev + '.';
      });
    }, 500); // Change dots every 500ms

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`flex items-center ${className}`}>
      <span className="text-sm text-muted-foreground">
        {text}
        <span className="inline-block w-6 text-left">{dots}</span>
      </span>
    </div>
  );
}