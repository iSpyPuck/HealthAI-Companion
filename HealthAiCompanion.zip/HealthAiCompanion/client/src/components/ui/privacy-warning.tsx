import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, X, Shield } from "lucide-react";

interface PrivacyWarningProps {
  storageKey: string;
  title: string;
  message: string;
  showIcon?: boolean;
  variant?: "default" | "destructive" | "warning";
}

export default function PrivacyWarning({ 
  storageKey, 
  title, 
  message, 
  showIcon = true,
  variant = "warning" 
}: PrivacyWarningProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const dismissed = localStorage.getItem(storageKey);
    if (!dismissed) {
      setIsVisible(true);
    }
  }, [storageKey]);

  const handleDismiss = () => {
    setIsVisible(false);
  };

  const handleNeverShowAgain = () => {
    localStorage.setItem(storageKey, 'dismissed');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  const getVariantStyles = () => {
    switch (variant) {
      case "destructive":
        return "border-red-200 bg-red-50";
      case "warning":
        return "border-coral/20 bg-coral/5";
      default:
        return "border-blue-200 bg-blue-50";
    }
  };

  const getIconColor = () => {
    switch (variant) {
      case "destructive":
        return "text-red-600";
      case "warning":
        return "text-coral";
      default:
        return "text-blue-600";
    }
  };

  return (
    <Card className={`mb-6 ${getVariantStyles()}`}>
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          {showIcon && (
            <div className="flex-shrink-0 mt-1">
              {variant === "warning" ? (
                <AlertTriangle className={`w-5 h-5 ${getIconColor()}`} />
              ) : (
                <Shield className={`w-5 h-5 ${getIconColor()}`} />
              )}
            </div>
          )}
          <div className="flex-1">
            <h3 className="font-semibold text-charcoal mb-2">{title}</h3>
            <p className="text-sm text-gray-700 mb-4 leading-relaxed">
              {message}
            </p>
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                size="sm"
                onClick={handleDismiss}
                className="text-sm"
              >
                Got it
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleNeverShowAgain}
                className="text-sm text-gray-600 hover:text-gray-800"
              >
                Never show again
              </Button>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDismiss}
            className="flex-shrink-0 text-gray-400 hover:text-gray-600"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}