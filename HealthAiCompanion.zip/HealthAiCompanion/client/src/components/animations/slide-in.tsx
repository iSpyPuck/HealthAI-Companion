import { ReactNode } from "react";

interface SlideInProps {
  children: ReactNode;
  direction?: "left" | "right" | "up" | "down";
  delay?: number;
  duration?: number;
  className?: string;
}

export function SlideIn({ 
  children, 
  direction = "up", 
  delay = 0, 
  duration = 800,
  className = "" 
}: SlideInProps) {
  const animationClass = {
    left: "animate-slide-in-left",
    right: "animate-slide-in-right",
    up: "animate-slide-in-up",
    down: "animate-slide-in-down"
  }[direction];

  return (
    <div 
      className={`${animationClass} ${className}`}
      style={{ 
        animationDelay: `${delay}ms`,
        animationDuration: `${duration}ms`
      }}
    >
      {children}
    </div>
  );
}