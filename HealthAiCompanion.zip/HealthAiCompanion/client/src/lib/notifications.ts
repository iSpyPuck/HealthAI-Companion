// Browser notification service for medication reminders
export class NotificationService {
  private static instance: NotificationService;
  private permission: NotificationPermission = 'default';

  private constructor() {
    if ('Notification' in window) {
      this.permission = Notification.permission;
    }
  }

  static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService();
    }
    return NotificationService.instance;
  }

  async requestPermission(): Promise<boolean> {
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return false;
    }

    if (this.permission === 'granted') {
      return true;
    }

    if (this.permission === 'denied') {
      return false;
    }

    this.permission = await Notification.requestPermission();
    return this.permission === 'granted';
  }

  async showNotification(title: string, options: {
    body: string;
    icon?: string;
    badge?: string;
    tag?: string;
    requireInteraction?: boolean;
    actions?: Array<{action: string; title: string}>;
  }): Promise<void> {
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return;
    }

    const hasPermission = await this.requestPermission();
    if (!hasPermission) {
      console.log('Notification permission denied');
      return;
    }

    const notification = new Notification(title, {
      body: options.body,
      icon: options.icon || '/favicon.ico',
      badge: options.badge || '/favicon.ico',
      tag: options.tag || 'medication-reminder',
      requireInteraction: options.requireInteraction || true
    });

    // Auto-close after 10 seconds if not requiring interaction
    if (!options.requireInteraction) {
      setTimeout(() => notification.close(), 10000);
    }

    return new Promise((resolve) => {
      notification.onclick = () => {
        window.focus();
        notification.close();
        resolve();
      };
      
      notification.onclose = () => resolve();
    });
  }

  async scheduleMedicationReminder(medicationName: string, time: string): Promise<void> {
    const now = new Date();
    const [hours, minutes] = time.split(':').map(Number);
    
    const reminderTime = new Date(now);
    reminderTime.setHours(hours, minutes, 0, 0);
    
    // If the time has passed today, schedule for tomorrow
    if (reminderTime <= now) {
      reminderTime.setDate(reminderTime.getDate() + 1);
    }
    
    const timeUntilReminder = reminderTime.getTime() - now.getTime();
    
    setTimeout(async () => {
      await this.showNotification(
        '💊 Medication Reminder',
        {
          body: `Time to take your ${medicationName}`,
          tag: `medication-${medicationName}`,
          requireInteraction: true,

        }
      );
    }, timeUntilReminder);
  }

  hasPermission(): boolean {
    return this.permission === 'granted';
  }

  isSupported(): boolean {
    return 'Notification' in window;
  }
}

// Export singleton instance
export const notificationService = NotificationService.getInstance();