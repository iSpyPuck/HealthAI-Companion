import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Pill, Plus, CheckCircle, AlertTriangle, Bot, ShoppingCart, Zap } from "lucide-react";
import MedicationForm from "@/components/medications/medication-form";
import MedicationCalendar from "@/components/medications/medication-calendar";
import EnhancedCalendar from "@/components/medications/enhanced-calendar";
import NotificationSettings from "@/components/medications/notification-settings";
import UpcomingReminders from "@/components/medications/upcoming-reminders";
import PrivacyWarning from "@/components/ui/privacy-warning";
import { notificationService } from "@/lib/notifications";
import { useState, useEffect } from "react";

export default function Medications() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [interactionAnalysis, setInteractionAnalysis] = useState<string | null>(null);
  const [showInteractions, setShowInteractions] = useState(false);

  const { data: medications = [], isLoading } = useQuery<any[]>({
    queryKey: ['/api/medications'],
  });

  // get medicine reminders for calendar
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - 7);
  const endDate = new Date();
  endDate.setDate(endDate.getDate() + 30);

  const { data: reminders = [] } = useQuery({
    queryKey: ['/api/medication-reminders', startDate.toISOString(), endDate.toISOString()],
    queryFn: async () => {
      const response = await fetch(`/api/medication-reminders?startDate=${startDate.toISOString()}&endDate=${endDate.toISOString()}`, {
        credentials: 'include',
      });
      if (!response.ok) return [];
      return response.json();
    },
    retry: false,
  });

  const deleteMedicationMutation = useMutation({
    mutationFn: async (medicationId: number) => {
      await apiRequest('DELETE', `/api/medications/${medicationId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/medications'] });
      toast({
        title: "Medication deleted",
        description: "Medication has been successfully removed.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete medication. Please try again.",
        variant: "destructive",
      });
    },
  });

  const analyzeInteractionsMutation = useMutation({
    mutationFn: async (medicationNames: string[]) => {
      const response = await apiRequest('POST', '/api/medications/analyze-interactions', {
        medications: medicationNames
      });
      return response.json();
    },
    onSuccess: (data) => {
      setInteractionAnalysis(data.analysis);
      setShowInteractions(true);
      toast({
        title: "Interaction analysis complete",
        description: "AI analysis of your medications is ready.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Analysis failed",
        description: "Could not analyze medication interactions. Please try again.",
        variant: "destructive",
      });
    },
  });

  const refillReminderMutation = useMutation({
    mutationFn: async (medicationId: number) => {
      const response = await apiRequest('POST', `/api/medications/${medicationId}/refill-reminder`);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Refill reminder generated",
        description: data.reminder,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to generate reminder",
        description: "Could not create refill reminder. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteMedication = (medicationId: number) => {
    if (window.confirm("Are you sure you want to delete this medication?")) {
      deleteMedicationMutation.mutate(medicationId);
    }
  };

  const handleAnalyzeInteractions = () => {
    if (medications.length < 2) {
      toast({
        title: "Need multiple medications",
        description: "Add at least 2 medications to analyze interactions.",
        variant: "destructive",
      });
      return;
    }
    
    const medicationNames = medications.map((med: any) => med.name);
    analyzeInteractionsMutation.mutate(medicationNames);
  };

  const handleRefillReminder = (medicationId: number) => {
    refillReminderMutation.mutate(medicationId);
  };

  // Schedule notifications for medications
  useEffect(() => {
    const scheduleNotifications = async () => {
      const notificationsEnabled = localStorage.getItem('medication-notifications-enabled') === 'true';
      
      if (notificationsEnabled && notificationService.hasPermission() && medications.length > 0) {
        medications.forEach((medication: any) => {
          if (medication.timeOfDay && medication.timeOfDay.length > 0) {
            medication.timeOfDay.forEach((time: string) => {
              notificationService.scheduleMedicationReminder(medication.name, time);
            });
          }
        });
      }
    };

    scheduleNotifications();
  }, [medications]);

  const getNextDoseInfo = (medication: any) => {
    if (!medication.timeOfDay || medication.timeOfDay.length === 0) {
      return "No schedule set";
    }
    
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    for (const timeStr of medication.timeOfDay) {
      const [hours, minutes] = timeStr.split(':').map(Number);
      const nextDose = new Date(today);
      nextDose.setHours(hours, minutes, 0, 0);
      
      if (nextDose > now) {
        return `Next dose: ${nextDose.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
      }
    }
    
    // If no more doses today, show first dose tomorrow
    const [hours, minutes] = medication.timeOfDay[0].split(':').map(Number);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(hours, minutes, 0, 0);
    
    return `Next dose: Tomorrow at ${tomorrow.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Pill className="w-12 h-12 mx-auto mb-4 text-medical-blue animate-pulse" />
          <p className="text-gray-600">Loading medications...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20 md:pb-8">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold text-charcoal mb-2">Medication Management</h2>
        <p className="text-gray-600">Track your medications and set AI-powered reminders</p>
      </div>

      {/* AI Safety Warning */}
      <PrivacyWarning
        storageKey="medications-ai-safety-warning"
        title="AI Medication Analysis Safety Notice"
        message="Our AI features for medication interaction analysis and refill reminders are designed to help you stay organized. However, AI analysis may not always be accurate and should never replace professional medical advice. Always consult with your doctor, pharmacist, or healthcare provider before making any medication decisions."
        variant="warning"
      />

      {/* Add Medication */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-charcoal">Add New Medication</h3>
            <Button
              onClick={() => setShowForm(!showForm)}
              className="bg-medical-blue hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              {showForm ? 'Cancel' : 'Add Medication'}
            </Button>
          </div>
          
          {showForm && (
            <MedicationForm 
              onSuccess={() => {
                setShowForm(false);
                queryClient.invalidateQueries({ queryKey: ['/api/medications'] });
              }}
            />
          )}
        </CardContent>
      </Card>

      {/* Current Medications & Calendar */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-charcoal mb-4">Current Medications</h3>
            
            {medications.length > 0 ? (
              <div className="space-y-4">
                {medications.map((medication: any) => (
                  <div key={medication.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                          <Pill className="w-6 h-6 text-purple-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-charcoal">{medication.name}</h4>
                          <p className="text-sm text-gray-600">{medication.dosage} • {medication.frequency}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-health-green/10 text-health-green">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Active
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-purple-600 hover:text-purple-700"
                          onClick={() => handleRefillReminder(medication.id)}
                          disabled={refillReminderMutation.isPending}
                        >
                          <ShoppingCart className="w-3 h-3 mr-1" />
                          Refill
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-red-600"
                          onClick={() => handleDeleteMedication(medication.id)}
                          disabled={deleteMedicationMutation.isPending}
                        >
                          Remove
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <span>{getNextDoseInfo(medication)}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <Pill className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-charcoal mb-2">No medications yet</h3>
                <p className="text-gray-600 mb-4">Add your first medication to start tracking</p>
                <Button
                  onClick={() => setShowForm(true)}
                  className="bg-medical-blue hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Medication
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Medication Calendar */}
        <div className="space-y-6">
          <MedicationCalendar />
          
          {/* Enhanced Calendar View */}
          <div className="border-t pt-6">
            <div className="mb-4">
              <h3 className="text-lg font-semibold">Enhanced Calendar View</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Google Calendar-style view with better medication tracking
              </p>
            </div>
            
            <EnhancedCalendar
              reminders={reminders}
              onReminderClick={(reminder) => {
                toast({
                  title: "Medication Reminder",
                  description: `${reminder.medicationName} - ${reminder.dosage}`,
                });
              }}
              onDateClick={(date) => {
                toast({
                  title: "Date Selected",
                  description: `Selected date: ${date.toLocaleDateString()}`,
                });
              }}
            />
          </div>
        </div>
      </div>

      {/* Notification Settings and Upcoming Reminders */}
      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <NotificationSettings />
        <UpcomingReminders medications={medications} />
      </div>

      {/* AI-Powered Features */}
      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Interaction Analysis */}
        <Card className="bg-light-blue">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-medical-blue rounded-full flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-charcoal mb-2">AI Interaction Analysis</h3>
                <p className="text-sm text-gray-700 mb-4">
                  Let AI analyze potential interactions between your medications.
                </p>
                <div className="space-y-2">
                  <Button
                    className="bg-medical-blue hover:bg-blue-700 w-full"
                    onClick={handleAnalyzeInteractions}
                    disabled={analyzeInteractionsMutation.isPending || medications.length < 2}
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    {analyzeInteractionsMutation.isPending ? "Analyzing..." : "Analyze Interactions"}
                  </Button>
                  {medications.length < 2 && (
                    <p className="text-xs text-gray-600">Add at least 2 medications to analyze</p>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Chat Assistant */}
        <Card className="bg-health-green/10">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-health-green rounded-full flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-charcoal mb-2">AI Health Assistant</h3>
                <p className="text-sm text-gray-700 mb-4">
                  Ask questions about your medications, side effects, or general health advice.
                </p>
                <Button
                  className="bg-health-green hover:bg-green-700 w-full"
                  onClick={() => window.location.href = '/chat'}
                >
                  <Bot className="w-4 h-4 mr-2" />
                  Start Health Chat
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Interaction Analysis Results */}
      {showInteractions && interactionAnalysis && (
        <Card className="mt-8 border-coral/20 bg-coral/5">
          <CardContent className="p-6">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-6 h-6 text-coral mt-1" />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-coral">AI Interaction Analysis</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowInteractions(false)}
                  >
                    ×
                  </Button>
                </div>
                <div className="text-sm text-charcoal whitespace-pre-wrap">
                  {interactionAnalysis}
                </div>
                <div className="mt-4 p-3 bg-coral/10 rounded-lg">
                  <p className="text-xs text-charcoal">
                    <strong>Important:</strong> This is AI-generated information and may not be completely accurate. Always consult with your pharmacist or healthcare provider for professional advice about drug interactions.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
