import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Plus, Target, Flame, Star, Trophy, CheckCircle, XCircle, Calendar, TrendingUp } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { FadeIn, SlideIn, ScaleIn } from '@/components/animations';
import { HabitForm } from '@/components/habits/habit-form';
import { CharacterDisplay } from '@/components/habits/character-display';
import { HabitCard } from '@/components/habits/habit-card';
import { AchievementsList } from '@/components/habits/achievements-list';
import type { Habit, UserCharacter, Achievement } from '@shared/schema';

export default function HabitTracker() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'habits' | 'character' | 'achievements'>('habits');

  const { data: habits = [], isLoading: habitsLoading } = useQuery({
    queryKey: ['/api/habits'],
    enabled: !!user,
  });

  const { data: character, isLoading: characterLoading } = useQuery({
    queryKey: ['/api/character'],
    enabled: !!user,
  });

  const { data: achievements = [], isLoading: achievementsLoading } = useQuery({
    queryKey: ['/api/achievements'],
    enabled: !!user,
  });

  const { data: habitLogs = [] } = useQuery({
    queryKey: ['/api/habits/logs'],
    enabled: !!user,
  });

  const createHabitMutation = useMutation({
    mutationFn: async (habitData: any) => {
      const res = await apiRequest('POST', '/api/habits', habitData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
      setIsFormOpen(false);
      toast({
        title: "Habit Created!",
        description: "Your new habit has been added to your tracker.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logHabitMutation = useMutation({
    mutationFn: async ({ habitId, notes }: { habitId: number; notes?: string }) => {
      const res = await apiRequest('POST', `/api/habits/${habitId}/log`, { notes });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/habits/logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/character'] });
      toast({
        title: "Great job! 🎉",
        description: "Habit logged successfully! You earned 10 XP.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getTodaysProgress = () => {
    const today = new Date().toDateString();
    const todaysLogs = habitLogs.filter((log: any) => 
      new Date(log.completedAt).toDateString() === today
    );
    
    const completedHabits = new Set(todaysLogs.map((log: any) => log.habitId));
    const totalHabits = habits.length;
    const completedCount = completedHabits.size;
    
    return {
      completed: completedCount,
      total: totalHabits,
      percentage: totalHabits > 0 ? (completedCount / totalHabits) * 100 : 0
    };
  };

  const progress = getTodaysProgress();

  if (habitsLoading || characterLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your habit tracker...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 dark:from-purple-950 dark:via-pink-950 dark:to-orange-950">
      <div className="container mx-auto px-4 py-8">
        <FadeIn>
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">
              Habit Tracker 🌟
            </h1>
            <p className="text-muted-foreground text-lg">
              Build healthy habits with your adorable companion
            </p>
          </div>
        </FadeIn>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-1 shadow-lg">
            {[
              { id: 'habits', label: 'My Habits', icon: Target },
              { id: 'character', label: 'My Character', icon: Star },
              { id: 'achievements', label: 'Achievements', icon: Trophy }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <Button
                  key={tab.id}
                  variant={selectedTab === tab.id ? 'default' : 'ghost'}
                  onClick={() => setSelectedTab(tab.id as any)}
                  className="gap-2"
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </Button>
              );
            })}
          </div>
        </div>

        {selectedTab === 'habits' && (
          <div className="space-y-6">
            {/* Progress Overview */}
            <SlideIn>
              <Card className="card-modern">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-primary" />
                        Today's Progress
                      </CardTitle>
                      <CardDescription>
                        {progress.completed} of {progress.total} habits completed
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">
                        {Math.round(progress.percentage)}%
                      </div>
                      <div className="text-sm text-muted-foreground">Complete</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Progress value={progress.percentage} className="h-3" />
                  <div className="flex justify-between text-sm text-muted-foreground mt-2">
                    <span>Keep going!</span>
                    <span>{progress.total - progress.completed} remaining</span>
                  </div>
                </CardContent>
              </Card>
            </SlideIn>

            {/* Add Habit Button */}
            <SlideIn delay={100}>
              <Card className="card-modern border-dashed border-2 border-primary/20 hover:border-primary/40 transition-colors">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <Button
                      onClick={() => setIsFormOpen(true)}
                      className="gap-2 gradient-button"
                      size="lg"
                    >
                      <Plus className="w-5 h-5" />
                      Add New Habit
                    </Button>
                    <p className="text-sm text-muted-foreground mt-2">
                      Create a healthy habit and watch your character grow!
                    </p>
                  </div>
                </CardContent>
              </Card>
            </SlideIn>

            {/* Habits List */}
            <div className="grid gap-4">
              {habits.map((habit: Habit, index: number) => (
                <SlideIn key={habit.id} delay={200 + index * 50}>
                  <HabitCard
                    habit={habit}
                    onLog={(notes) => logHabitMutation.mutate({ habitId: habit.id, notes })}
                    isLogging={logHabitMutation.isPending}
                    isCompleted={habitLogs.some((log: any) => 
                      log.habitId === habit.id && 
                      new Date(log.completedAt).toDateString() === new Date().toDateString()
                    )}
                  />
                </SlideIn>
              ))}
            </div>

            {habits.length === 0 && (
              <SlideIn>
                <Card className="card-modern">
                  <CardContent className="py-12 text-center">
                    <div className="text-6xl mb-4">🌱</div>
                    <h3 className="text-lg font-semibold mb-2">Start Your Journey!</h3>
                    <p className="text-muted-foreground mb-4">
                      Create your first habit to begin building a healthier lifestyle.
                    </p>
                    <Button
                      onClick={() => setIsFormOpen(true)}
                      className="gap-2 gradient-button"
                    >
                      <Plus className="w-4 h-4" />
                      Create First Habit
                    </Button>
                  </CardContent>
                </Card>
              </SlideIn>
            )}
          </div>
        )}

        {selectedTab === 'character' && (
          <SlideIn>
            <CharacterDisplay 
              character={character}
              isLoading={characterLoading}
            />
          </SlideIn>
        )}

        {selectedTab === 'achievements' && (
          <SlideIn>
            <AchievementsList 
              achievements={achievements}
              isLoading={achievementsLoading}
            />
          </SlideIn>
        )}

        {/* Habit Form Modal */}
        {isFormOpen && (
          <HabitForm
            onClose={() => setIsFormOpen(false)}
            onSubmit={createHabitMutation.mutate}
            isLoading={createHabitMutation.isPending}
          />
        )}
      </div>
    </div>
  );
}