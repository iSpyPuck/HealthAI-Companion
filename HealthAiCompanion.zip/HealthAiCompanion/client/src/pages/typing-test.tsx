import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CSSTypewriter } from '@/components/ui/css-typewriter';
import { LoadingDots } from '@/components/ui/loading-dots';
import { RefreshCw, Bot } from 'lucide-react';

const testMessages = [
  "Hello! I'm your AI health assistant. How can I help you today?",
  "Remember to stay **hydrated** throughout the day by drinking at least 8 glasses of water.",
  "Regular exercise is crucial for maintaining good health. Even a **10-minute walk** after meals can make a significant difference!",
  "**Important reminder:** This AI provides general health information and should not replace professional medical advice. Always consult with a healthcare provider for specific medical concerns.",
  "Here are some quick tips for better sleep: maintain a **consistent bedtime**, avoid screens **1 hour before sleep**, and keep your bedroom **cool and dark**."
];

export default function TypingTest() {
  const [currentMessage, setCurrentMessage] = useState(testMessages[0]);
  const [messageIndex, setMessageIndex] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSimulatingChat, setIsSimulatingChat] = useState(false);
  const [showLoadingDots, setShowLoadingDots] = useState(false);

  const getNextMessage = () => {
    setIsRefreshing(true);
    
    setTimeout(() => {
      const nextIndex = (messageIndex + 1) % testMessages.length;
      setCurrentMessage(testMessages[nextIndex]);
      setMessageIndex(nextIndex);
      setIsRefreshing(false);
    }, 300);
  };

  const simulateChat = () => {
    setIsSimulatingChat(true);
    setShowLoadingDots(true);
    
    // Show loading dots for 2 seconds
    setTimeout(() => {
      setShowLoadingDots(false);
      const nextIndex = (messageIndex + 1) % testMessages.length;
      setCurrentMessage(testMessages[nextIndex]);
      setMessageIndex(nextIndex);
      setIsSimulatingChat(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Bot className="w-6 h-6 text-primary" />
              CSS Typewriter Effect Test
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">
              This page tests the CSS Typewriter effect used in chat messages. 
              Click "Next Message" to see the typing animation with different text samples.
            </p>
            
            <div className="flex gap-3 mb-6">
              <Button 
                onClick={getNextMessage} 
                disabled={isRefreshing}
                className="flex items-center gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
                Next Message
              </Button>
              <Button 
                onClick={simulateChat} 
                disabled={isSimulatingChat}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Bot className={`w-4 h-4 ${isSimulatingChat ? 'animate-pulse' : ''}`} />
                Simulate Chat Flow
              </Button>
              <span className="text-sm text-muted-foreground py-2">
                Message {messageIndex + 1} of {testMessages.length}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Test Message Display */}
        <Card className="bg-gradient-to-br from-muted/20 to-muted/10">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="w-6 h-6 text-primary-foreground" />
              </div>
              
              <div className="flex-1 bg-muted rounded-lg p-4">
                {showLoadingDots ? (
                  <LoadingDots text="writing message" />
                ) : isRefreshing ? (
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  </div>
                ) : (
                  <CSSTypewriter 
                    text={currentMessage}
                    className="text-sm leading-relaxed"
                    speed={80} // 80ms between chunks
                    chunkSize={4} // 4 characters per chunk
                    onComplete={() => {
                      console.log("Typing animation completed!");
                    }}
                  />
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Info Panel */}
        <Card className="mt-6">
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">Typewriter Configuration</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="bg-muted/50 p-3 rounded-lg">
                <div className="font-medium">Speed</div>
                <div className="text-muted-foreground">80ms per chunk</div>
              </div>
              <div className="bg-muted/50 p-3 rounded-lg">
                <div className="font-medium">Chunk Size</div>
                <div className="text-muted-foreground">4 characters</div>
              </div>
              <div className="bg-muted/50 p-3 rounded-lg">
                <div className="font-medium">Bold Text</div>
                <div className="text-muted-foreground">**text** format supported</div>
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="text-sm">
                <div className="font-medium text-blue-900 dark:text-blue-100">Loading Animation:</div>
                <div className="text-blue-800 dark:text-blue-200 mt-1">
                  Progressive dots: "writing message" → "writing message." → "writing message.." → "writing message..." (repeating every 500ms)
                </div>
                <div className="font-medium text-blue-900 dark:text-blue-100 mt-2">Typewriter Effect:</div>
                <div className="text-blue-800 dark:text-blue-200 mt-1">
                  Text appears in chunks of 4 characters every 80ms with a blinking cursor. 
                  Bold formatting works with **text** syntax.
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}