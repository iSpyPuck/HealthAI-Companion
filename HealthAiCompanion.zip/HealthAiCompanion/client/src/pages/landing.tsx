import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Heart, Shield, Zap, MessageCircle, FileText, Clock, Users, CheckCircle, Sparkles } from "lucide-react";
import { FadeIn } from "@/components/animations/fade-in";
import { SlideIn } from "@/components/animations/slide-in";
import { ScaleIn } from "@/components/animations/scale-in";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <FadeIn delay={0}>
          <nav className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center shadow-lg">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                HealthAI Companion
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" asChild className="text-muted-foreground hover:text-primary transition-colors font-medium">
                <a href="/auth">Login</a>
              </Button>
              <Button asChild className="btn-modern bg-gradient-primary hover:shadow-xl">
                <a href="/auth">Get Started</a>
              </Button>
            </div>
          </nav>
        </FadeIn>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-24 text-center">
        <FadeIn delay={200}>
          <Badge variant="secondary" className="mb-6 px-4 py-2 text-sm font-medium bg-primary/10 text-primary border-primary/20">
            <Sparkles className="w-4 h-4 mr-2" />
            AI-Powered Health Intelligence
          </Badge>
        </FadeIn>
        
        <FadeIn delay={400}>
          <h1 className="text-6xl md:text-7xl font-bold mb-8 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent leading-tight">
            Your AI Health
            <br />
            Companion
          </h1>
        </FadeIn>
        
        <FadeIn delay={600}>
          <p className="text-xl text-muted-foreground mb-12 max-w-3xl mx-auto leading-relaxed">
            Transform your health management with intelligent AI assistance. Secure record storage, smart medication tracking, and personalized insights - all in one beautiful platform.
          </p>
        </FadeIn>
        
        <FadeIn delay={800}>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button size="lg" asChild className="btn-modern bg-gradient-primary hover:shadow-2xl text-lg px-10 py-7 h-auto">
              <a href="/auth">
                Start Your Health Journey
                <ArrowRight className="ml-3 h-5 w-5" />
              </a>
            </Button>
            <Button size="lg" variant="outline" className="btn-modern text-lg px-10 py-7 h-auto border-2 hover:bg-primary/5">
              Learn More
            </Button>
          </div>
        </FadeIn>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-24">
        <FadeIn delay={1000}>
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Everything you need for better health</h2>
            <p className="text-muted-foreground text-xl max-w-2xl mx-auto">
              Comprehensive tools designed with modern technology to keep you healthy and informed
            </p>
          </div>
        </FadeIn>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              icon: <MessageCircle className="h-8 w-8 text-primary" />,
              title: "AI Health Chat",
              description: "Get instant, intelligent answers to your health questions from our advanced AI assistant",
              delay: 1200,
              gradient: "from-primary/20 to-primary/5"
            },
            {
              icon: <FileText className="h-8 w-8 text-accent" />,
              title: "Health Records",
              description: "Securely store, organize, and access your medical documents with military-grade encryption",
              delay: 1300,
              gradient: "from-accent/20 to-accent/5"
            },
            {
              icon: <Clock className="h-8 w-8 text-primary" />,
              title: "Medication Tracking",
              description: "Smart reminders, interaction checking, and dosage management with AI-powered insights",
              delay: 1400,
              gradient: "from-primary/20 to-primary/5"
            },
            {
              icon: <Users className="h-8 w-8 text-accent" />,
              title: "Appointment Scheduling",
              description: "Effortlessly book and manage healthcare appointments with calendar integration",
              delay: 1500,
              gradient: "from-accent/20 to-accent/5"
            },
            {
              icon: <Shield className="h-8 w-8 text-primary" />,
              title: "Privacy First",
              description: "Your health data is protected with end-to-end encryption and HIPAA compliance",
              delay: 1600,
              gradient: "from-primary/20 to-primary/5"
            },
            {
              icon: <Zap className="h-8 w-8 text-accent" />,
              title: "Smart Insights",
              description: "Personalized health recommendations powered by advanced machine learning",
              delay: 1700,
              gradient: "from-accent/20 to-accent/5"
            }
          ].map((feature, index) => (
            <ScaleIn key={index} delay={feature.delay}>
              <Card className="card-modern h-full group">
                <CardHeader className="pb-4">
                  <div className={`w-14 h-14 bg-gradient-to-br ${feature.gradient} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    {feature.icon}
                  </div>
                  <CardTitle className="text-xl font-semibold">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base leading-relaxed">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            </ScaleIn>
          ))}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container mx-auto px-4 py-24">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <SlideIn direction="left" delay={1800}>
            <div>
              <h2 className="text-4xl font-bold mb-8">Why choose HealthAI Companion?</h2>
              <div className="space-y-6">
                {[
                  "24/7 AI-powered health support",
                  "Secure, HIPAA-compliant data storage",
                  "Advanced medication interaction checking",
                  "Personalized health insights & recommendations",
                  "Seamless appointment scheduling",
                  "Comprehensive health tracking & analytics"
                ].map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="h-4 w-4 text-white" />
                    </div>
                    <span className="text-lg text-muted-foreground">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
          </SlideIn>
          
          <SlideIn direction="right" delay={2000}>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/30 to-accent/30 rounded-3xl blur-3xl"></div>
              <Card className="card-modern relative bg-card/80 backdrop-blur-sm border-2">
                <CardContent className="p-10">
                  <div className="text-center space-y-6">
                    <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center mx-auto shadow-2xl">
                      <Heart className="h-10 w-10 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold">Start Your Health Journey Today</h3>
                    <p className="text-muted-foreground text-lg leading-relaxed">
                      Join thousands of users who trust HealthAI Companion with their health management and experience the future of healthcare.
                    </p>
                    <Button asChild className="btn-modern w-full bg-gradient-primary hover:shadow-2xl text-lg py-6 h-auto">
                      <a href="/auth">Get Started Free</a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </SlideIn>
        </div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-4 py-12 border-t border-border/50">
        <FadeIn delay={2200}>
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-3">
              <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-semibold">HealthAI Companion</span>
            </div>
            <p className="text-muted-foreground">&copy; 2025 HealthAI Companion. Your health, our priority.<br />Created by Quinn Bradley.</p>
          </div>
        </FadeIn>
      </footer>
    </div>
  );
}