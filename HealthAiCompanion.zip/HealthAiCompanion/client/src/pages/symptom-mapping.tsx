import { FadeIn } from '@/components/animations/fade-in';
import { InteractiveBodyMap } from '@/components/body-map/interactive-body-map';

export default function SymptomMapping() {
  return (
    <FadeIn>
      <div className="container mx-auto py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Visual Symptom Body
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Click anywhere on the body diagram to log symptoms. Track pain, discomfort, 
              and other health concerns with precise location mapping.
            </p>
            <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <p className="text-sm text-amber-800 dark:text-amber-200">
                <strong>Medical Disclaimer:</strong> This tool is for tracking purposes only. 
                Always consult with healthcare professionals for proper medical diagnosis and treatment.
              </p>
            </div>
          </div>
          
          <InteractiveBodyMap />
        </div>
      </div>
    </FadeIn>
  );
}