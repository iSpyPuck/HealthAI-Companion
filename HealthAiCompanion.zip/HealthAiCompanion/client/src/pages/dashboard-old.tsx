import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Calendar, 
  FileText, 
  Pill, 
  MessageCircle, 
  Heart,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  Activity,
  Users,
  Zap,
  Shield,
  BarChart3,
  PieChart,
  LineChart,
  Sparkles,
  ArrowRight,
  Bot,
  Bell
} from "lucide-react";
import { FadeIn } from "@/components/animations/fade-in";
import { SlideIn } from "@/components/animations/slide-in";
import { ScaleIn } from "@/components/animations/scale-in";
import { HealthTipOfDay } from "@/components/health/health-tip-of-day";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { LoadingDots } from "@/components/ui/loading-dots";

export default function Dashboard() {
  const { user } = useAuth();

  const { data: conversations = [] } = useQuery({
    queryKey: ['/api/conversations'],
  });

  const { data: medications = [] } = useQuery({
    queryKey: ['/api/medications'],
  });

  const { data: healthRecords = [] } = useQuery({
    queryKey: ['/api/health-records'],
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['/api/appointments'],
  });

  // AI Dashboard Message with direct API call approach
  const [aiMessage, setAiMessage] = useState("Welcome to your health dashboard! I'm here to help you manage your health journey.");
  const [isLoadingAI, setIsLoadingAI] = useState(false);

  const fetchAIMessage = async () => {
    try {
      setIsLoadingAI(true);
      const response = await fetch('/api/ai/dashboard-message', {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.message) {
          setAiMessage(data.message);
        }
      }
    } catch (error) {
      console.error('Failed to fetch AI message:', error);
    } finally {
      setIsLoadingAI(false);
    }
  };

  // Fetch AI message on component mount and when user changes
  useEffect(() => {
    if (user) {
      fetchAIMessage();
    }
  }, [user]);

  const stats = [
    {
      title: "Total Conversations",
      value: conversationsArray.length,
      icon: MessageCircle,
      color: "text-primary",
      bgColor: "bg-primary/10",
      change: "+12%",
      changeType: "positive"
    },
    {
      title: "Active Medications",
      value: medicationsArray.filter((med: any) => med.isActive).length,
      icon: Pill,
      color: "text-accent",
      bgColor: "bg-accent/10",
      change: "+5%",
      changeType: "positive"
    },
    {
      title: "Health Records",
      value: healthRecordsArray.length,
      icon: FileText,
      color: "text-primary",
      bgColor: "bg-primary/10",
      change: "+8%",
      changeType: "positive"
    },
    {
      title: "Upcoming Appointments",
      value: appointmentsArray.filter((apt: any) => new Date(apt.dateTime) > new Date()).length,
      icon: Calendar,
      color: "text-accent",
      bgColor: "bg-accent/10",
      change: "+3%",
      changeType: "positive"
    }
  ];

  const quickActions = [
    {
      title: "AI Health Chat",
      description: "Get instant AI-powered health insights and answers to your medical questions",
      icon: MessageCircle,
      href: "/chat",
      gradient: "from-primary/20 to-primary/5",
      iconColor: "text-primary"
    },
    {
      title: "Health Records",
      description: "Manage and view your medical documents securely",
      icon: FileText,
      href: "/records",
      gradient: "from-accent/20 to-accent/5",
      iconColor: "text-accent"
    },
    {
      title: "Medications",
      description: "Track your medications with smart reminders and interaction checking",
      icon: Pill,
      href: "/medications",
      gradient: "from-primary/20 to-primary/5",
      iconColor: "text-primary"
    },
    {
      title: "Appointments",
      description: "Schedule and manage your healthcare appointments",
      icon: Calendar,
      href: "/appointments",
      gradient: "from-accent/20 to-accent/5",
      iconColor: "text-accent"
    }
  ];

  // Type-safe array access with defaults
  const conversationsArray = Array.isArray(conversations) ? conversations : [];
  const medicationsArray = Array.isArray(medications) ? medications : [];
  const healthRecordsArray = Array.isArray(healthRecords) ? healthRecords : [];
  const appointmentsArray = Array.isArray(appointments) ? appointments : [];

  // Weekly health streak
  const weeklyStreak = medicationsArray.filter((med: any) => {
    const today = new Date();
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    return med.createdAt && new Date(med.createdAt) >= weekAgo;
  }).length;

  // Health score calculation
  const healthScore = Math.min(100, 
    (conversationsArray.length * 5) + 
    (medicationsArray.length * 10) + 
    (healthRecordsArray.length * 15) + 
    (appointmentsArray.length * 20)
  );

  return (
    <div className="min-h-screen p-6 pb-20 md:pb-6 space-y-8">
      {/* Welcome Section */}
      <FadeIn delay={0}>
        <div className="mb-8">
          <div className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-accent/10 rounded-3xl p-8 border border-border/50">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 opacity-50"></div>
            <div className="relative z-10">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-primary/10 text-primary border-primary/20">
                      <Sparkles className="w-3 h-3 mr-1" />
                      Welcome back
                    </Badge>
                  </div>
                  <h1 className="text-4xl font-bold">
                    Hello, {(user as any)?.firstName || 'there'}!
                  </h1>
                  <p className="text-xl text-muted-foreground">
                    Ready to take control of your health today?
                  </p>
                </div>
                <div className="hidden md:block">
                  <div className="w-24 h-24 bg-gradient-primary rounded-2xl flex items-center justify-center shadow-xl animate-float">
                    <Heart className="w-12 h-12 text-white" />
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full blur-3xl -z-0"></div>
          </div>
        </div>
      </FadeIn>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <ScaleIn key={stat.title} delay={200 + index * 100}>
            <Card className="card-modern">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">
                      {stat.title}
                    </p>
                    <p className="text-3xl font-bold">{stat.value}</p>
                    <div className="flex items-center mt-2">
                      <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                      <span className="text-sm text-green-500 font-medium">
                        {stat.change}
                      </span>
                    </div>
                  </div>
                  <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </ScaleIn>
        ))}
      </div>

      {/* Quick Actions */}
      <FadeIn delay={600}>
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickActions.map((action, index) => (
              <SlideIn key={action.title} delay={700 + index * 100} direction="up">
                <Link href={action.href}>
                  <Card className="card-modern h-full group cursor-pointer">
                    <CardContent className="p-6">
                      <div className={`w-14 h-14 bg-gradient-to-br ${action.gradient} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                        <action.icon className={`w-7 h-7 ${action.iconColor}`} />
                      </div>
                      <h3 className="text-lg font-semibold mb-2">{action.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {action.description}
                      </p>
                      <div className="flex items-center mt-4 text-primary group-hover:translate-x-1 transition-transform duration-300">
                        <span className="text-sm font-medium">Get started</span>
                        <ArrowRight className="w-4 h-4 ml-1" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </SlideIn>
            ))}
          </div>
        </div>
      </FadeIn>

      {/* AI Assistant Message */}
      <FadeIn delay={900}>
        <div className="mb-8">
          <Card className="card-modern bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-primary rounded-2xl flex items-center justify-center flex-shrink-0">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="text-lg font-semibold">HealthAI Companion</h3>
                    <Badge className="bg-green-100 text-green-700 border-green-200">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                      Online
                    </Badge>
                  </div>
                  <div className="text-muted-foreground leading-relaxed">
                    {isLoadingAI ? (
                      <LoadingDots text="Generating personalized message" />
                    ) : (
                      <p>{aiMessage}</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-4 mt-4">
                    <Link href="/chat">
                      <Button size="sm" className="bg-gradient-primary hover:opacity-90">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Start Chat
                      </Button>
                    </Link>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={fetchAIMessage}
                      disabled={isLoadingAI}
                    >
                      <Bot className="w-4 h-4 mr-2" />
                      {isLoadingAI ? "Loading..." : "Refresh AI"}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </FadeIn>

      {/* Health Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <SlideIn delay={1100} direction="left">
          <Card className="card-modern">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="w-5 h-5 mr-2 text-primary" />
                Health Overview
              </CardTitle>
              <CardDescription>
                Your health status at a glance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Medication Adherence</span>
                  <span className="text-sm text-muted-foreground">92%</span>
                </div>
                <Progress value={92} className="h-2" />
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Health Records Complete</span>
                  <span className="text-sm text-muted-foreground">{healthRecordsArray.length > 0 ? '85%' : '0%'}</span>
                </div>
                <Progress value={healthRecordsArray.length > 0 ? 85 : 0} className="h-2" />
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Weekly Health Score</span>
                  <span className="text-sm text-muted-foreground">{healthScore}%</span>
                </div>
                <Progress value={healthScore} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </SlideIn>

        <SlideIn delay={1200} direction="right">
          <Card className="card-modern">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="w-5 h-5 mr-2 text-accent" />
                Recent Activity
              </CardTitle>
              <CardDescription>
                Your latest health interactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {conversationsArray.length > 0 ? (
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <MessageCircle className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">AI Health Chat</p>
                      <p className="text-sm text-muted-foreground">Started new conversation</p>
                    </div>
                    <Badge variant="secondary">Recent</Badge>
                  </div>
                ) : null}
                
                {medicationsArray.length > 0 ? (
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-accent/10 rounded-full flex items-center justify-center">
                      <Pill className="w-5 h-5 text-accent" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">Medication Added</p>
                      <p className="text-sm text-muted-foreground">New medication in your list</p>
                    </div>
                    <Badge variant="secondary">Active</Badge>
                  </div>
                ) : null}
                
                {healthRecordsArray.length > 0 ? (
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <FileText className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">Health Record</p>
                      <p className="text-sm text-muted-foreground">Document uploaded</p>
                    </div>
                    <Badge variant="secondary">Stored</Badge>
                  </div>
                ) : null}
                
                {conversationsArray.length === 0 && medicationsArray.length === 0 && healthRecordsArray.length === 0 ? (
                  <div className="text-center py-8">
                    <Activity className="w-12 h-12 mx-auto mb-3 text-muted-foreground/50" />
                    <p className="text-sm text-muted-foreground">No recent activity</p>
                    <p className="text-xs text-muted-foreground">Start using the app to see your activity here!</p>
                  </div>
                ) : null}
              </div>
            </CardContent>
          </Card>
        </SlideIn>
      </div>

      {/* Health Tip and Emergency Features */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <FadeIn delay={1300}>
          <HealthTipOfDay />
        </FadeIn>

        <SlideIn delay={1400} direction="up">
          <Card className="card-modern bg-gradient-to-br from-red-50 to-pink-50 dark:from-red-950/20 dark:to-pink-950/20 border-red-200 dark:border-red-800">
            <CardHeader>
              <CardTitle className="flex items-center text-red-700 dark:text-red-300">
                <Shield className="w-5 h-5 mr-2" />
                Emergency Resources
              </CardTitle>
              <CardDescription className="text-red-600 dark:text-red-400">
                Quick access to emergency services and contacts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Link href="/emergency">
                  <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                    <AlertCircle className="w-4 h-4 mr-2" />
                    Emergency Services
                  </Button>
                </Link>
                <Link href="/symptom-analysis">
                  <Button variant="outline" className="w-full border-red-200 text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-300 dark:hover:bg-red-950/20">
                    <Activity className="w-4 h-4 mr-2" />
                    Symptom Analysis
                  </Button>
                </Link>
                <div className="pt-2 border-t border-red-200 dark:border-red-800">
                  <p className="text-xs text-red-600 dark:text-red-400 leading-relaxed">
                    <AlertCircle className="w-3 h-3 inline mr-1" />
                    For medical emergencies, always call emergency services immediately.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </SlideIn>
      </div>

      {/* Habit Tracker Integration */}
      <FadeIn delay={1500}>
        <Card className="card-modern bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/20 dark:to-indigo-950/20 border-purple-200 dark:border-purple-800">
          <CardHeader>
            <CardTitle className="flex items-center text-purple-700 dark:text-purple-300">
              <Zap className="w-5 h-5 mr-2" />
              Habit Tracking & Gamification
            </CardTitle>
            <CardDescription className="text-purple-600 dark:text-purple-400">
              Build healthy habits with your AI companion character
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-indigo-500 rounded-full flex items-center justify-center">
                    <Heart className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-purple-900 dark:text-purple-100">Health Streak</p>
                    <p className="text-sm text-purple-600 dark:text-purple-400">{weeklyStreak} activities this week</p>
                  </div>
                </div>
                <Link href="/habit-tracker">
                  <Button className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white">
                    <Users className="w-4 h-4 mr-2" />
                    Manage Habits
                  </Button>
                </Link>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-purple-700 dark:text-purple-300">{healthScore}</div>
                <div className="text-sm text-purple-600 dark:text-purple-400">Health Score</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </FadeIn>
    </div>
  );
}
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Appointment Attendance</span>
                  <span className="text-sm text-muted-foreground">95%</span>
                </div>
                <Progress value={95} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </SlideIn>

        <SlideIn delay={1200} direction="right">
          <Card className="card-modern">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="w-5 h-5 mr-2 text-accent" />
                Today's Reminders
              </CardTitle>
              <CardDescription>
                Don't forget these important tasks
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <p className="text-sm font-medium">Take morning medication</p>
                    <p className="text-xs text-muted-foreground">Due in 30 minutes</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <p className="text-sm font-medium">Upload lab results</p>
                    <p className="text-xs text-muted-foreground">From yesterday's visit</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <p className="text-sm font-medium">Cardiology appointment</p>
                    <p className="text-xs text-muted-foreground">Tomorrow at 2:00 PM</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </SlideIn>
      </div>

      {/* AI Assistant CTA */}
      {/* AI Assistant and Health Tip Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <FadeIn delay={1300}>
          <Card className="card-modern bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Bot className="w-6 h-6 text-primary" />
                  <Badge className="bg-primary/10 text-primary border-primary/20">
                    AI Assistant
                  </Badge>
                </div>
                <h3 className="text-xl font-bold">Need health guidance?</h3>
                <p className="text-muted-foreground">
                  Our AI assistant is here to help with medical questions, medication information, and health insights.
                </p>
                <Button asChild className="btn-modern bg-gradient-primary hover:shadow-xl w-full">
                  <Link href="/chat">
                    Start Conversation
                    <MessageCircle className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </FadeIn>

        {/* Health Tip of the Day */}
        <HealthTipOfDay />
      </div>
    </div>
  );
}