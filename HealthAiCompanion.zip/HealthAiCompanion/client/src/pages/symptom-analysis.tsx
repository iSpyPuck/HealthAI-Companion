import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, Clock, CheckCircle, XCircle, User, Brain, Lightbulb, Stethoscope } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { FadeIn, SlideIn } from '@/components/animations';
import BodyMap from '@/components/ui/body-map';

interface BodyPart {
  id: string;
  name: string;
  region: string;
  coordinates: { x: number; y: number; width: number; height: number };
}

interface SymptomAnalysis {
  id: number;
  selectedBodyParts: string[];
  symptoms: string;
  severity: number;
  duration: string;
  analysis: string;
  recommendations: string[];
  urgencyLevel: 'low' | 'medium' | 'high' | 'urgent';
  possibleConditions: string[];
  createdAt: string;
}

const BODY_PARTS: BodyPart[] = [
  { id: 'head', name: 'Head', region: 'upper', coordinates: { x: 45, y: 5, width: 10, height: 8 } },
  { id: 'neck', name: 'Neck', region: 'upper', coordinates: { x: 47, y: 13, width: 6, height: 4 } },
  { id: 'left_shoulder', name: 'Left Shoulder', region: 'upper', coordinates: { x: 35, y: 17, width: 8, height: 6 } },
  { id: 'right_shoulder', name: 'Right Shoulder', region: 'upper', coordinates: { x: 57, y: 17, width: 8, height: 6 } },
  { id: 'left_arm', name: 'Left Arm', region: 'upper', coordinates: { x: 25, y: 23, width: 6, height: 15 } },
  { id: 'right_arm', name: 'Right Arm', region: 'upper', coordinates: { x: 69, y: 23, width: 6, height: 15 } },
  { id: 'chest', name: 'Chest', region: 'upper', coordinates: { x: 43, y: 17, width: 14, height: 12 } },
  { id: 'abdomen', name: 'Abdomen', region: 'core', coordinates: { x: 43, y: 29, width: 14, height: 10 } },
  { id: 'left_hand', name: 'Left Hand', region: 'upper', coordinates: { x: 20, y: 38, width: 8, height: 6 } },
  { id: 'right_hand', name: 'Right Hand', region: 'upper', coordinates: { x: 72, y: 38, width: 8, height: 6 } },
  { id: 'lower_back', name: 'Lower Back', region: 'core', coordinates: { x: 43, y: 39, width: 14, height: 8 } },
  { id: 'left_hip', name: 'Left Hip', region: 'lower', coordinates: { x: 40, y: 47, width: 8, height: 6 } },
  { id: 'right_hip', name: 'Right Hip', region: 'lower', coordinates: { x: 52, y: 47, width: 8, height: 6 } },
  { id: 'left_thigh', name: 'Left Thigh', region: 'lower', coordinates: { x: 38, y: 53, width: 8, height: 15 } },
  { id: 'right_thigh', name: 'Right Thigh', region: 'lower', coordinates: { x: 54, y: 53, width: 8, height: 15 } },
  { id: 'left_knee', name: 'Left Knee', region: 'lower', coordinates: { x: 38, y: 68, width: 8, height: 6 } },
  { id: 'right_knee', name: 'Right Knee', region: 'lower', coordinates: { x: 54, y: 68, width: 8, height: 6 } },
  { id: 'left_calf', name: 'Left Calf', region: 'lower', coordinates: { x: 38, y: 74, width: 8, height: 15 } },
  { id: 'right_calf', name: 'Right Calf', region: 'lower', coordinates: { x: 54, y: 74, width: 8, height: 15 } },
  { id: 'left_foot', name: 'Left Foot', region: 'lower', coordinates: { x: 35, y: 89, width: 10, height: 8 } },
  { id: 'right_foot', name: 'Right Foot', region: 'lower', coordinates: { x: 55, y: 89, width: 10, height: 8 } },
];

const DURATION_OPTIONS = [
  { value: 'less_than_day', label: 'Less than a day' },
  { value: '1-3_days', label: '1-3 days' },
  { value: '4-7_days', label: '4-7 days' },
  { value: '1-2_weeks', label: '1-2 weeks' },
  { value: '2-4_weeks', label: '2-4 weeks' },
  { value: 'over_month', label: 'Over a month' },
  { value: 'chronic', label: 'Chronic (ongoing)' },
];

const getUrgencyColor = (level: string) => {
  switch (level) {
    case 'urgent': return 'bg-red-500';
    case 'high': return 'bg-orange-500';
    case 'medium': return 'bg-yellow-500';
    case 'low': return 'bg-green-500';
    default: return 'bg-gray-500';
  }
};

const getUrgencyIcon = (level: string) => {
  switch (level) {
    case 'urgent': return <AlertTriangle className="w-4 h-4" />;
    case 'high': return <AlertTriangle className="w-4 h-4" />;
    case 'medium': return <Clock className="w-4 h-4" />;
    case 'low': return <CheckCircle className="w-4 h-4" />;
    default: return <Clock className="w-4 h-4" />;
  }
};

export default function SymptomAnalysis() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedBodyParts, setSelectedBodyParts] = useState<string[]>([]);
  const [symptoms, setSymptoms] = useState('');
  const [severity, setSeverity] = useState([5]);
  const [duration, setDuration] = useState('');
  const [analysisResult, setAnalysisResult] = useState<SymptomAnalysis | null>(null);

  const { data: previousAnalyses } = useQuery<SymptomAnalysis[]>({
    queryKey: ['/api/symptom-analyses'],
  });

  const analyzeMutation = useMutation({
    mutationFn: async (data: {
      bodyParts: string[];
      symptoms: string;
      severity: number;
      duration: string;
    }) => {
      const response = await fetch('/api/symptom-analysis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    },
    onSuccess: (result: SymptomAnalysis) => {
      setAnalysisResult(result);
      queryClient.invalidateQueries({ queryKey: ['/api/symptom-analyses'] });
      toast({
        title: 'Analysis Complete',
        description: 'Your symptom analysis has been generated successfully.',
      });
    },
    onError: (error: Error) => {
      console.error('Analysis error:', error);
      toast({
        title: 'Analysis Failed',
        description: 'Unable to analyze symptoms. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const handleBodyPartClick = (bodyPartId: string) => {
    setSelectedBodyParts(prev => 
      prev.includes(bodyPartId) 
        ? prev.filter(id => id !== bodyPartId)
        : [...prev, bodyPartId]
    );
  };

  const handleAnalyze = async () => {
    if (selectedBodyParts.length === 0) {
      toast({
        title: 'Missing Information',
        description: 'Please select at least one body part.',
        variant: 'destructive',
      });
      return;
    }

    if (!symptoms.trim()) {
      toast({
        title: 'Missing Information',
        description: 'Please describe your symptoms.',
        variant: 'destructive',
      });
      return;
    }

    if (!duration) {
      toast({
        title: 'Missing Information',
        description: 'Please select how long you\'ve had these symptoms.',
        variant: 'destructive',
      });
      return;
    }

    const selectedBodyPartNames = selectedBodyParts.map(id => 
      BODY_PARTS.find(bp => bp.id === id)?.name
    ).filter((name): name is string => Boolean(name));

    analyzeMutation.mutate({
      bodyParts: selectedBodyPartNames,
      symptoms,
      severity: severity[0],
      duration,
    });
  };

  const resetForm = () => {
    setSelectedBodyParts([]);
    setSymptoms('');
    setSeverity([5]);
    setDuration('');
    setAnalysisResult(null);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <FadeIn>
        <div className="text-center space-y-4">
          <h1 className="text-3xl font-bold gradient-text">AI Symptom Analysis</h1>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Select the areas of your body where you're experiencing symptoms, describe them, and get AI-powered insights.
          </p>
          <Alert className="max-w-2xl mx-auto">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> This analysis is for informational purposes only and should not replace professional medical advice. 
              Always consult with qualified healthcare professionals for proper diagnosis and treatment.
            </AlertDescription>
          </Alert>
        </div>
      </FadeIn>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Body Map Section */}
        <SlideIn direction="left">
          <Card className="card-modern">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Body Map
              </CardTitle>
              <CardDescription>
                Click on the body parts where you're experiencing symptoms
              </CardDescription>
            </CardHeader>
            <CardContent>
              <BodyMap 
                selectedParts={selectedBodyParts}
                onPartSelect={handleBodyPartClick}
                className="w-full"
              />
            </CardContent>
          </Card>
        </SlideIn>

        {/* Symptom Input Section */}
        <SlideIn direction="right">
          <Card className="card-modern">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Stethoscope className="w-5 h-5" />
                Symptom Details
              </CardTitle>
              <CardDescription>
                Provide detailed information about your symptoms
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="symptoms">Describe your symptoms</Label>
                <Textarea
                  id="symptoms"
                  placeholder="Describe what you're experiencing in detail..."
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  rows={4}
                  className="resize-none"
                />
              </div>

              <div className="space-y-2">
                <Label>Severity Level: {severity[0]}/10</Label>
                <Slider
                  value={severity}
                  onValueChange={setSeverity}
                  max={10}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                  <span>Mild</span>
                  <span>Moderate</span>
                  <span>Severe</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Duration</Label>
                <Select value={duration} onValueChange={setDuration}>
                  <SelectTrigger>
                    <SelectValue placeholder="How long have you had these symptoms?" />
                  </SelectTrigger>
                  <SelectContent>
                    {DURATION_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleAnalyze}
                  disabled={analyzeMutation.isPending}
                  className="button-primary flex-1"
                >
                  {analyzeMutation.isPending ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4 mr-2" />
                      Analyze Symptoms
                    </>
                  )}
                </Button>
                <Button variant="outline" onClick={resetForm}>
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>
        </SlideIn>
      </div>

      {/* Analysis Results */}
      {analysisResult && (
        <FadeIn delay={0.3}>
          <Card className="card-modern">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5" />
                Analysis Results
              </CardTitle>
              <CardDescription>
                AI-powered analysis of your symptoms
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Urgency Level */}
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${getUrgencyColor(analysisResult.urgencyLevel)} text-white`}>
                  {getUrgencyIcon(analysisResult.urgencyLevel)}
                </div>
                <div>
                  <p className="font-medium">Urgency Level</p>
                  <p className="text-sm text-gray-600 dark:text-gray-300 capitalize">
                    {analysisResult.urgencyLevel}
                  </p>
                </div>
              </div>

              {/* Analysis */}
              <div className="space-y-2">
                <Label className="text-base font-medium">Analysis</Label>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                  {analysisResult.analysis}
                </p>
              </div>

              {/* Possible Conditions */}
              <div className="space-y-2">
                <Label className="text-base font-medium">Possible Conditions</Label>
                <div className="flex flex-wrap gap-2">
                  {analysisResult.possibleConditions.map((condition, index) => (
                    <Badge key={index} variant="secondary">
                      {condition}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Recommendations */}
              <div className="space-y-2">
                <Label className="text-base font-medium flex items-center gap-2">
                  <Lightbulb className="w-4 h-4" />
                  Recommendations
                </Label>
                <ul className="space-y-2">
                  {analysisResult.recommendations.map((rec, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Disclaimer:</strong> This analysis is generated by AI and should not replace professional medical advice. 
                  If you're experiencing severe symptoms or your condition worsens, please seek immediate medical attention.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </FadeIn>
      )}

      {/* Previous Analyses */}
      {previousAnalyses && previousAnalyses.length > 0 && (
        <FadeIn delay={0.5}>
          <Card className="card-modern">
            <CardHeader>
              <CardTitle>Previous Analyses</CardTitle>
              <CardDescription>
                Your recent symptom analysis history
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {previousAnalyses.slice(0, 3).map((analysis: SymptomAnalysis) => (
                  <div key={analysis.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`p-1 rounded-full ${getUrgencyColor(analysis.urgencyLevel)} text-white`}>
                          {getUrgencyIcon(analysis.urgencyLevel)}
                        </div>
                        <span className="text-sm text-gray-500">
                          {new Date(analysis.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <Badge variant="outline" className="capitalize">
                        {analysis.urgencyLevel}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                      <strong>Areas:</strong> {analysis.selectedBodyParts.join(', ')}
                    </p>
                    <p className="text-sm text-gray-700 dark:text-gray-300 line-clamp-2">
                      {analysis.symptoms}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </FadeIn>
      )}
    </div>
  );
}