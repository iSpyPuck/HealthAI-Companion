import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { MessageCircle, Send, Plus, Bot, User, Paperclip } from "lucide-react";
import ChatInterface from "@/components/chat/chat-interface";
import PrivacyWarning from "@/components/ui/privacy-warning";

export default function Chat() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const [newChatTitle, setNewChatTitle] = useState("");

  const { data: conversations = [], isLoading: conversationsLoading } = useQuery<any[]>({
    queryKey: ['/api/conversations'],
    refetchInterval: 5000, // Refresh every 5 seconds to get new conversations
  });

  const createConversationMutation = useMutation({
    mutationFn: async (title: string) => {
      const response = await apiRequest('POST', '/api/conversations', { title });
      return response.json();
    },
    onSuccess: (newConversation) => {
      // Immediately update the conversations list
      queryClient.setQueryData(['/api/conversations'], (old: any[]) => {
        return old ? [newConversation, ...old] : [newConversation];
      });
      // Also invalidate to ensure we get server state
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      setSelectedConversation(newConversation.id);
      setNewChatTitle("");
      toast({
        title: "New conversation created",
        description: "You can now start chatting with the AI assistant.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/auth";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create conversation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateConversation = () => {
    const title = newChatTitle.trim() || `New Chat ${new Date().toLocaleString()}`;
    createConversationMutation.mutate(title);
  };

  const handleConversationSelect = (conversationId: number) => {
    setSelectedConversation(conversationId);
  };

  if (conversationsLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Bot className="w-12 h-12 mx-auto mb-4 text-primary animate-pulse" />
          <p className="text-muted-foreground">Loading conversations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20 md:pb-8">
      {/* AI Chat Safety Warning */}
      <PrivacyWarning
        storageKey="ai-chat-safety-warning"
        title="AI Health Chat Safety Notice"
        message="This AI assistant is designed to provide general health information and support. It should never replace professional medical advice, diagnosis, or treatment. Always consult with qualified healthcare professionals for medical concerns. AI responses may not always be accurate - use your judgment and seek professional help when needed."
        variant="warning"
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-12rem)]">
        {/* Conversations Sidebar */}
        <Card className="lg:col-span-1">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 mb-4">
              <MessageCircle className="w-5 h-5 text-primary" />
              <h3 className="font-semibold text-foreground">Conversations</h3>
            </div>

            {/* New Conversation */}
            <div className="mb-4">
              <div className="flex space-x-2">
                <Input
                  placeholder="New conversation title..."
                  value={newChatTitle}
                  onChange={(e) => setNewChatTitle(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleCreateConversation()}
                  className="flex-1"
                />
                <Button
                  size="sm"
                  onClick={handleCreateConversation}
                  disabled={createConversationMutation.isPending}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Conversations List */}
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {conversations.length > 0 ? (
                conversations.map((conversation: any) => (
                  <Button
                    key={conversation.id}
                    variant={selectedConversation === conversation.id ? "default" : "ghost"}
                    className={`w-full justify-start text-left p-3 h-auto ${
                      selectedConversation === conversation.id 
                        ? "bg-primary text-primary-foreground" 
                        : "hover:bg-muted"
                    }`}
                    onClick={() => handleConversationSelect(conversation.id)}
                  >
                    <div className="truncate">
                      <div className="font-medium">{conversation.title}</div>
                      <div className="text-xs opacity-75">
                        {new Date(conversation.updatedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </Button>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageCircle className="w-12 h-12 mx-auto mb-2 text-muted-foreground/50" />
                  <p className="text-sm">No conversations yet</p>
                  <p className="text-xs">Create your first conversation above</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Chat Interface */}
        <div className="lg:col-span-3">
          {selectedConversation ? (
            <ChatInterface conversationId={selectedConversation} />
          ) : (
            <Card className="h-full">
              <CardContent className="p-8 flex items-center justify-center h-full">
                <div className="text-center">
                  <Bot className="w-24 h-24 mx-auto mb-6 text-primary" />
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    Welcome to HealthAI Companion
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    Select a conversation or create a new one to start chatting with your AI health assistant.
                  </p>
                  <div className="bg-warning/10 border border-warning/20 rounded-lg p-4 max-w-md mx-auto">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-warning rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white text-xs font-bold">!</span>
                      </div>
                      <div className="text-left">
                        <h4 className="font-semibold text-warning mb-1">Medical Disclaimer</h4>
                        <p className="text-sm text-foreground">
                          This AI provides general health information only. Always consult healthcare professionals for medical advice.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
