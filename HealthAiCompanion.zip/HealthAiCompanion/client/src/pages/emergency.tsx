import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Phone, 
  Plus, 
  Edit, 
  Trash2, 
  Heart, 
  AlertTriangle, 
  Users, 
  Shield,
  Clock,
  MapPin,
  Mail,
  User,
  PhoneCall,
  Stethoscope,
  Building,
  MessageCircle,
  Star,
  CheckCircle
} from "lucide-react";
import { FadeIn } from "@/components/animations/fade-in";
import { SlideIn } from "@/components/animations/slide-in";
import { ScaleIn } from "@/components/animations/scale-in";

import { insertEmergencyContactSchema, type EmergencyContact } from '@shared/schema';

export default function Emergency() {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null);

  const { register, handleSubmit, reset, setValue, watch } = useForm<Omit<EmergencyContact, 'id' | 'createdAt' | 'updatedAt' | 'userId'>>();

  const { data: contacts = [] } = useQuery<EmergencyContact[]>({
    queryKey: ['/api/emergency-contacts'],
  });

  const addContactMutation = useMutation({
    mutationFn: async (contact: Omit<EmergencyContact, 'id' | 'createdAt' | 'updatedAt'>) => {
      const response = await fetch('/api/emergency-contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(contact),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-contacts'] });
      setShowForm(false);
      reset();
      toast({
        title: "Contact added",
        description: "Emergency contact has been added successfully.",
      });
    },
  });

  const updateContactMutation = useMutation({
    mutationFn: async (contact: EmergencyContact) => {
      const response = await fetch(`/api/emergency-contacts/${contact.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(contact),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-contacts'] });
      setEditingContact(null);
      setShowForm(false);
      reset();
      toast({
        title: "Contact updated",
        description: "Emergency contact has been updated successfully.",
      });
    },
  });

  const deleteContactMutation = useMutation({
    mutationFn: async (id: number) => {
      await fetch(`/api/emergency-contacts/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-contacts'] });
      toast({
        title: "Contact deleted",
        description: "Emergency contact has been removed.",
      });
    },
  });

  const onSubmit = (data: Omit<EmergencyContact, 'id' | 'createdAt' | 'updatedAt' | 'userId'>) => {
    if (editingContact) {
      updateContactMutation.mutate({ ...data, id: editingContact.id });
    } else {
      addContactMutation.mutate(data);
    }
  };

  const handleEdit = (contact: EmergencyContact) => {
    setEditingContact(contact);
    setShowForm(true);
    setValue('name', contact.name);
    setValue('relationship', contact.relationship);
    setValue('phone', contact.phone);
    setValue('email', contact.email || '');
    setValue('address', contact.address || '');
    setValue('isPrimary', contact.isPrimary);
    setValue('medicalContact', contact.medicalContact);
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingContact(null);
    reset();
  };

  const emergencyServices = [
    { name: "Emergency Services", number: "911", description: "Police, Fire, Medical Emergency" },
    { name: "Poison Control", number: "1-800-222-1222", description: "24/7 poison emergency hotline" },
    { name: "Crisis Text Line", number: "Text HOME to 741741", description: "24/7 crisis support via text" },
    { name: "National Suicide Prevention", number: "988", description: "24/7 mental health crisis support" },
  ];

  const primaryContact = contacts.find(c => c.isPrimary);
  const medicalContacts = contacts.filter(c => c.medicalContact);
  const personalContacts = contacts.filter(c => !c.medicalContact);

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <FadeIn delay={0}>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-3 text-foreground">
              <Heart className="w-8 h-8 text-red-500" />
              Emergency Contacts
            </h1>
            <p className="text-muted-foreground">
              Manage your emergency contacts and important medical information
            </p>
          </div>
          <Button
            onClick={() => setShowForm(true)}
            className="gap-2 mt-4 sm:mt-0"
          >
            <Plus className="w-4 h-4" />
            Add Contact
          </Button>
        </div>
      </FadeIn>
      {/* Emergency Alert */}
      <SlideIn delay={200}>
        <Alert className="mb-8 border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950">
          <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
          <AlertDescription className="text-red-800 dark:text-red-200">
            <strong>Medical Emergency:</strong> Call 911 immediately for life-threatening situations.
            Keep this information updated and easily accessible.
          </AlertDescription>
        </Alert>
      </SlideIn>
      <div className="grid gap-8">
        {/* Emergency Services */}
        <SlideIn delay={300}>
          <Card className="card-modern border-red-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-700">
                <Phone className="w-5 h-5" />
                Emergency Services
              </CardTitle>
              <CardDescription>
                Important emergency phone numbers - call immediately in crisis situations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {emergencyServices.map((service, index) => (
                  <div key={service.name} className="flex items-center gap-4 p-4 rounded-lg border border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-950/50">
                    <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-red-800 dark:text-red-200">{service.name}</div>
                      <div className="text-lg font-bold text-red-600 dark:text-red-400">{service.number}</div>
                      <div className="text-sm text-red-600 dark:text-red-400">{service.description}</div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950"
                      onClick={() => window.open(`tel:${service.number}`, '_self')}
                    >
                      <PhoneCall className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </SlideIn>

        {/* Primary Contact */}
        {primaryContact && (
          <SlideIn delay={400}>
            <Card className="card-modern border-green-200 bg-green-50/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-700">
                  <Star className="w-5 h-5" />
                  Primary Emergency Contact
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 p-4 rounded-lg border border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-950/50">
                  <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                    <User className="w-8 h-8 text-green-600 dark:text-green-400" />
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-lg">{primaryContact.name}</div>
                    <div className="text-muted-foreground">{primaryContact.relationship}</div>
                    <div className="flex items-center gap-4 mt-2">
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-green-600 dark:text-green-400" />
                        <span className="font-medium">{primaryContact.phone}</span>
                      </div>
                      {primaryContact.email && (
                        <div className="flex items-center gap-2">
                          <Mail className="w-4 h-4 text-green-600 dark:text-green-400" />
                          <span>{primaryContact.email}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => window.open(`tel:${primaryContact.phone}`, '_self')}
                      className="gap-2"
                    >
                      <PhoneCall className="w-4 h-4" />
                      Call
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(primaryContact)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </SlideIn>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Medical Contacts */}
          <SlideIn delay={500}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Stethoscope className="w-5 h-5 text-blue-600" />
                  Medical Contacts
                </CardTitle>
                <CardDescription>Healthcare providers and medical professionals</CardDescription>
              </CardHeader>
              <CardContent>
                {medicalContacts.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Stethoscope className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                    <p>No medical contacts added yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {medicalContacts.map((contact) => (
                      <div key={contact.id} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                              <Stethoscope className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                            </div>
                            <div>
                              <div className="font-medium">{contact.name}</div>
                              <div className="text-sm text-muted-foreground">{contact.relationship}</div>
                              <div className="text-sm font-medium text-blue-600 dark:text-blue-400">{contact.phone}</div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => window.open(`tel:${contact.phone}`, '_self')}
                            >
                              <PhoneCall className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleEdit(contact)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => deleteContactMutation.mutate(contact.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </SlideIn>

          {/* Personal Contacts */}
          <SlideIn delay={600}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-600" />
                  Personal Contacts
                </CardTitle>
                <CardDescription>Family members, friends, and personal emergency contacts</CardDescription>
              </CardHeader>
              <CardContent>
                {personalContacts.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                    <p>No personal contacts added yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {personalContacts.map((contact) => (
                      <div key={contact.id} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-purple-600" />
                            </div>
                            <div>
                              <div className="font-medium">{contact.name}</div>
                              <div className="text-sm text-muted-foreground">{contact.relationship}</div>
                              <div className="text-sm font-medium text-purple-600">{contact.phone}</div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => window.open(`tel:${contact.phone}`, '_self')}
                            >
                              <PhoneCall className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleEdit(contact)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => deleteContactMutation.mutate(contact.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </SlideIn>
        </div>

        {/* Add/Edit Contact Form */}
        {showForm && (
          <SlideIn delay={700}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle>
                  {editingContact ? 'Edit Contact' : 'Add Emergency Contact'}
                </CardTitle>
                <CardDescription>
                  {editingContact ? 'Update contact information' : 'Add a new emergency contact to your list'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Name *</Label>
                      <Input
                        id="name"
                        {...register('name', { required: true })}
                        placeholder="Full name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="relationship">Relationship *</Label>
                      <Input
                        id="relationship"
                        {...register('relationship', { required: true })}
                        placeholder="e.g., Spouse, Doctor, Friend"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        {...register('phone', { required: true })}
                        placeholder="(555) 123-4567"
                        type="tel"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        {...register('email')}
                        placeholder="email@example.com"
                        type="email"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      {...register('address')}
                      placeholder="123 Main St, City, State 12345"
                    />
                  </div>

                  <div className="flex items-center gap-6">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        {...register('isPrimary')}
                        className="rounded border-gray-300"
                      />
                      <span>Primary emergency contact</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        {...register('medicalContact')}
                        className="rounded border-gray-300"
                      />
                      <span>Medical professional</span>
                    </label>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <Button
                      type="submit"
                      disabled={addContactMutation.isPending || updateContactMutation.isPending}
                    >
                      {editingContact ? 'Update Contact' : 'Add Contact'}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleCancel}
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </SlideIn>
        )}
      </div>
    </div>
  );
}