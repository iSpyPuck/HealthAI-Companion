import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { TypewriterText } from '@/components/ui/typewriter-text';
import { useQuery } from '@tanstack/react-query';
import { ProgressRing } from '@/components/ui/progress-ring';
import { BodyMap } from '@/components/ui/body-map';
import { MoodTracker } from '@/components/ui/mood-tracker';
import { CalendarWidget } from '@/components/ui/calendar-widget';
import { SeverityBar } from '@/components/ui/severity-bar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  Heart, 
  Brain, 
  Activity, 
  Calendar, 
  Pill, 
  FileText, 
  Sparkles,
  Sun,
  Moon,
  Cloud,
  Clock,
  MessageCircle,
  BarChart3,
  TrendingUp,
  User,
  Shield,
  Star,
  Plus,
  ArrowRight,
  Bot
} from 'lucide-react';
import { FadeIn, SlideIn } from '@/components/ui/animations';

interface WellnessTip {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: string;
}

export default function HomePage() {
  const { user } = useAuth();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [aiMessage, setAiMessage] = useState('');
  const [isGeneratingMessage, setIsGeneratingMessage] = useState(false);
  const [messageKey, setMessageKey] = useState(0);
  const [showWellnessTips, setShowWellnessTips] = useState(false);
  const [selectedSymptom, setSelectedSymptom] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (user) {
      console.log('User loaded, generating AI message...');
      generatePersonalizedMessage();
    }
  }, [user]); // Generate AI message when user loads

  const generatePersonalizedMessage = async () => {
    const hour = new Date().getHours(); // Use current time instead of state
    let timeOfDay = '';
    
    if (hour < 12) {
      timeOfDay = 'morning';
    } else if (hour < 17) {
      timeOfDay = 'afternoon';
    } else {
      timeOfDay = 'evening';
    }

    setIsGeneratingMessage(true);

    try {
      console.log('Generating AI message for user:', user?.firstName || 'unknown');
      
      // Use the emergency AI endpoint that bypasses authentication
      const response = await fetch('/api/ai/dashboard-message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          timeOfDay,
          userName: user?.firstName || user?.email?.split('@')[0] || 'Friend'
        }),
      });

      console.log('AI message response status:', response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log('AI message received:', data.message);
        setAiMessage(data.message);
        
        // Force component re-render with new key
        setMessageKey(prev => prev + 1);
        setCurrentTime(new Date());
      } else {
        const errorText = await response.text();
        console.error('Failed to generate AI message:', response.status, errorText);
        
        // Fallback to static message if AI fails
        const firstName = user?.firstName || user?.email?.split('@')[0] || 'there';
        const fallbackMessage = `Good ${timeOfDay}, ${firstName}! Welcome to your **HealthAI Companion** dashboard. Let's make today a great day for your wellness journey!`;
        setAiMessage(fallbackMessage);
        setMessageKey(prev => prev + 1);
      }
    } catch (error) {
      console.error('Error generating personalized message:', error);
      // Fallback to static message if AI fails
      const firstName = user?.firstName || user?.email?.split('@')[0] || 'there';
      const fallbackMessage = `Good ${timeOfDay}, ${firstName}! Welcome to your **HealthAI Companion** dashboard. Let's make today a great day for your wellness journey!`;
      setAiMessage(fallbackMessage);
      setMessageKey(prev => prev + 1);
    } finally {
      setIsGeneratingMessage(false);
    }
  };

  const getTimeIcon = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return <Sun className="h-5 w-5 text-yellow-500" />;
    if (hour < 17) return <Cloud className="h-5 w-5 text-blue-500" />;
    return <Moon className="h-5 w-5 text-purple-500" />;
  };

  const wellnessTips: WellnessTip[] = [
    {
      icon: <Heart className="h-5 w-5" />,
      title: "Heart Health",
      description: "Take 5 minutes for deep breathing exercises to support cardiovascular wellness.",
      color: "text-red-500"
    },
    {
      icon: <Brain className="h-5 w-5" />,
      title: "Mental Clarity",
      description: "Try a quick mindfulness practice to enhance focus and reduce stress.",
      color: "text-purple-500"
    },
    {
      icon: <Activity className="h-5 w-5" />,
      title: "Stay Active",
      description: "Even 10 minutes of movement can boost your energy and mood significantly.",
      color: "text-green-500"
    },
    {
      icon: <Sparkles className="h-5 w-5" />,
      title: "Hydration",
      description: "Your body needs water - aim for 8 glasses throughout the day.",
      color: "text-blue-500"
    }
  ];

  const handleBodyPartClick = (bodyPart: string) => {
    setSelectedSymptom(bodyPart);
  };

  const handleMoodSelect = (mood: string, level: number) => {
    console.log('Mood selected:', mood, level);
    // Here you could save the mood to the database
  };

  // Function to parse **text** and make it bold
  const parseAiMessage = (text: string) => {
    if (!text) return text;
    
    // Split by **text** patterns and create JSX elements
    const parts = text.split(/\*\*(.*?)\*\*/g);
    
    return parts.map((part, index) => {
      // Every odd index is the text between **
      if (index % 2 === 1) {
        return <strong key={index} className="font-bold text-foreground">{part}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-blue-900">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Welcome Header */}
        <FadeIn>
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-2">
              {getTimeIcon()}
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Hello, {user?.firstName || 'there'}!
              </h1>
            </div>
            
            <div className="max-w-2xl mx-auto">
              {aiMessage ? (
                <div key={messageKey} className="text-lg text-muted-foreground leading-relaxed">
                  <TypewriterText 
                    text={aiMessage} 
                    speed={15}
                    className="text-lg text-muted-foreground leading-relaxed"
                  />
                </div>
              ) : (
                <TypewriterText
                  text="Loading your personalized health message..."
                  className="text-lg text-muted-foreground leading-relaxed"
                  speed={20}
                  onComplete={() => setShowWellnessTips(true)}
                />
              )}
              {isGeneratingMessage && (
                <div className="mt-2 flex items-center justify-center text-xs text-muted-foreground">
                  <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-primary mr-2"></div>
                  Updating your message...
                </div>
              )}
            </div>
          </div>
        </FadeIn>

        {/* Quick Stats */}
        <SlideIn delay={500}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="card-modern">
              <CardHeader className="text-center">
                <CardTitle className="text-lg">Health Score</CardTitle>
                <CardDescription>Overall wellness rating</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <ProgressRing 
                  progress={85} 
                  label="Great!"
                  color="hsl(var(--primary))"
                  showCelebration={true}
                />
              </CardContent>
            </Card>

            <Card className="card-modern">
              <CardHeader className="text-center">
                <CardTitle className="text-lg">Activity Level</CardTitle>
                <CardDescription>Daily movement goal</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <ProgressRing 
                  progress={65} 
                  label="Active"
                  color="hsl(142, 76%, 36%)"
                />
              </CardContent>
            </Card>

            <Card className="card-modern">
              <CardHeader className="text-center">
                <CardTitle className="text-lg">Hydration</CardTitle>
                <CardDescription>Water intake today</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <ProgressRing 
                  progress={40} 
                  label="Needs work"
                  color="hsl(221, 83%, 53%)"
                />
              </CardContent>
            </Card>
          </div>
        </SlideIn>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Body Map */}
          <SlideIn delay={800}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>Symptom Checker</span>
                </CardTitle>
                <CardDescription>
                  Click on any body part to log symptoms or get insights
                </CardDescription>
              </CardHeader>
              <CardContent>
                <BodyMap 
                  selectedParts={selectedSymptom ? [selectedSymptom] : []}
                  onPartSelect={handleBodyPartClick}
                />
                {selectedSymptom && (
                  <div className="mt-4 p-4 bg-primary/10 rounded-lg animate-fade-in">
                    <p className="text-sm text-primary font-medium">
                      Selected: {selectedSymptom}
                    </p>
                    <div className="mt-3 space-y-2">
                      <SeverityBar 
                        level={7} 
                        size="sm"
                        showLabel={true}
                        showValue={true}
                      />
                      <Button size="sm" className="w-full mt-2">
                        Log Symptom
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </SlideIn>

          {/* Mood Tracker */}
          <SlideIn delay={1000}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="h-5 w-5" />
                  <span>Mood Check-in</span>
                </CardTitle>
                <CardDescription>
                  Track your emotional wellbeing throughout the day
                </CardDescription>
              </CardHeader>
              <CardContent>
                <MoodTracker onMoodSelect={handleMoodSelect} />
              </CardContent>
            </Card>
          </SlideIn>

          {/* Calendar Widget */}
          <SlideIn delay={1200}>
            <CalendarWidget 
              events={[
                { date: new Date(), title: 'Take Morning Medication', type: 'medication' },
                { date: new Date(Date.now() + 86400000), title: 'Doctor Appointment', type: 'appointment' },
                { date: new Date(Date.now() + 2 * 86400000), title: 'Health Check Reminder', type: 'reminder' },
              ]}
              onDateClick={(date) => console.log('Date clicked:', date)}
              onAddEvent={(date) => console.log('Add event for:', date)}
            />
          </SlideIn>
        </div>

        {/* Wellness Tips */}
        {showWellnessTips && (
          <SlideIn delay={1200}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Sparkles className="h-5 w-5" />
                  <span>Personalized Wellness Tips</span>
                </CardTitle>
                <CardDescription>
                  AI-powered recommendations just for you
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {wellnessTips.map((tip, index) => (
                    <div
                      key={index}
                      className="group p-4 rounded-lg bg-gradient-to-r from-white to-gray-50 dark:from-gray-800 dark:to-gray-700 border hover:shadow-md transition-all duration-300 hover:scale-105"
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`${tip.color} group-hover:scale-110 transition-transform duration-200`}>
                          {tip.icon}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{tip.title}</h4>
                          <p className="text-xs text-muted-foreground mt-1">
                            {tip.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </SlideIn>
        )}

        {/* Quick Actions */}
        <SlideIn delay={1400}>
          <Card className="card-modern">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>
                Access your most used features
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button variant="outline" className="h-20 flex-col space-y-2 group hover:bg-primary/10 animate-bounce-in border-2 border-gray-200 dark:border-gray-700">
                  <Pill className="h-6 w-6 group-hover:scale-110 transition-transform animate-wiggle" />
                  <span className="text-sm">Medications</span>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2 group hover:bg-primary/10 animate-bounce-in border-2 border-gray-200 dark:border-gray-700" style={{ animationDelay: '100ms' }}>
                  <Calendar className="h-6 w-6 group-hover:scale-110 transition-transform" />
                  <span className="text-sm">Appointments</span>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2 group hover:bg-primary/10 animate-bounce-in border-2 border-gray-200 dark:border-gray-700" style={{ animationDelay: '200ms' }}>
                  <FileText className="h-6 w-6 group-hover:scale-110 transition-transform" />
                  <span className="text-sm">Records</span>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2 group hover:bg-primary/10 animate-bounce-in border-2 border-gray-200 dark:border-gray-700" style={{ animationDelay: '300ms' }}>
                  <Heart className="h-6 w-6 group-hover:scale-110 transition-transform animate-heartbeat" />
                  <span className="text-sm">Chat</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </SlideIn>

        {/* Health Insights Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <SlideIn delay={1600}>
            <Card className="card-modern border-2 border-purple-200 dark:border-purple-800">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="h-5 w-5 text-purple-500 animate-rotate-slow" />
                  <span>AI Health Insights</span>
                </CardTitle>
                <CardDescription>
                  Personalized health recommendations powered by AI
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-lg animate-fade-in border border-purple-200 dark:border-purple-700">
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center animate-bounce-in">
                        <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                      </div>
                      <div>
                        <h4 className="font-medium text-purple-900 dark:text-purple-100">Sleep Quality</h4>
                        <p className="text-sm text-purple-700 dark:text-purple-300">Your sleep patterns show improvement this week. Consider maintaining your current bedtime routine.</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 bg-gradient-to-r from-green-50 to-teal-50 dark:from-green-900/20 dark:to-teal-900/20 rounded-lg animate-fade-in border border-green-200 dark:border-green-700" style={{ animationDelay: '200ms' }}>
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center animate-bounce-in">
                        <Activity className="w-4 h-4 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <h4 className="font-medium text-green-900 dark:text-green-100">Activity Level</h4>
                        <p className="text-sm text-green-700 dark:text-green-300">Great job staying active! You're 15% above your weekly goal.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </SlideIn>

          <SlideIn delay={1800}>
            <Card className="card-modern border-2 border-blue-200 dark:border-blue-800">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-blue-500 animate-wiggle" />
                  <span>Upcoming Reminders</span>
                </CardTitle>
                <CardDescription>
                  Important health events and medication reminders
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg animate-slide-in-left border border-blue-200 dark:border-blue-700">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                    <div className="flex-1">
                      <p className="font-medium text-blue-900 dark:text-blue-100">Morning medication</p>
                      <p className="text-sm text-blue-700 dark:text-blue-300">8:00 AM today</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg animate-slide-in-left border border-orange-200 dark:border-orange-700" style={{ animationDelay: '100ms' }}>
                    <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                    <div className="flex-1">
                      <p className="font-medium text-orange-900 dark:text-orange-100">Doctor appointment</p>
                      <p className="text-sm text-orange-700 dark:text-orange-300">Tomorrow at 2:30 PM</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg animate-slide-in-left border border-purple-200 dark:border-purple-700" style={{ animationDelay: '200ms' }}>
                    <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
                    <div className="flex-1">
                      <p className="font-medium text-purple-900 dark:text-purple-100">Health check-up</p>
                      <p className="text-sm text-purple-700 dark:text-purple-300">Next week</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </SlideIn>
        </div>

        {/* Activity and Progress Section */}
        <SlideIn delay={2000}>
          <Card className="card-modern border-2 border-green-200 dark:border-green-800">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Activity className="h-5 w-5 text-green-500 animate-heartbeat" />
                <span>Weekly Health Progress</span>
              </CardTitle>
              <CardDescription>
                Track your health journey and achievements
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center space-y-2 animate-zoom-in">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center mx-auto animate-float">
                    <span className="text-white font-bold text-lg">7</span>
                  </div>
                  <div>
                    <p className="font-medium text-green-900 dark:text-green-100">Days Active</p>
                    <p className="text-sm text-green-700 dark:text-green-300">This week</p>
                  </div>
                </div>
                <div className="text-center space-y-2 animate-zoom-in" style={{ animationDelay: '200ms' }}>
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full flex items-center justify-center mx-auto animate-float">
                    <span className="text-white font-bold text-lg">12</span>
                  </div>
                  <div>
                    <p className="font-medium text-blue-900 dark:text-blue-100">Health Goals</p>
                    <p className="text-sm text-blue-700 dark:text-blue-300">Achieved</p>
                  </div>
                </div>
                <div className="text-center space-y-2 animate-zoom-in" style={{ animationDelay: '400ms' }}>
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full flex items-center justify-center mx-auto animate-float">
                    <span className="text-white font-bold text-lg">3</span>
                  </div>
                  <div>
                    <p className="font-medium text-purple-900 dark:text-purple-100">Medications</p>
                    <p className="text-sm text-purple-700 dark:text-purple-300">On track</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </SlideIn>

        {/* Health Stats Overview */}
        <SlideIn delay={2200}>
          <Card className="card-modern border-2 border-indigo-200 dark:border-indigo-800">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5 text-indigo-500 animate-bounce-in" />
                <span>Health Statistics</span>
              </CardTitle>
              <CardDescription>
                Your health metrics and trends over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-gradient-to-br from-red-50 to-pink-50 dark:from-red-900/20 dark:to-pink-900/20 p-4 rounded-lg border border-red-200 dark:border-red-800 animate-scale-in">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center animate-pulse">
                      <Heart className="w-6 h-6 text-red-500 animate-heartbeat" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-red-900 dark:text-red-100">72</p>
                      <p className="text-sm text-red-700 dark:text-red-300">BPM</p>
                    </div>
                  </div>
                  <p className="text-xs text-red-600 dark:text-red-400 mt-2">Heart Rate</p>
                </div>
                
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800 animate-scale-in" style={{ animationDelay: '100ms' }}>
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center animate-wiggle">
                      <Moon className="w-6 h-6 text-blue-500" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">7.5</p>
                      <p className="text-sm text-blue-700 dark:text-blue-300">Hours</p>
                    </div>
                  </div>
                  <p className="text-xs text-blue-600 dark:text-blue-400 mt-2">Sleep</p>
                </div>
                
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800 animate-scale-in" style={{ animationDelay: '200ms' }}>
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center animate-bounce-in">
                      <Activity className="w-6 h-6 text-green-500 animate-pulse" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-green-900 dark:text-green-100">8.2k</p>
                      <p className="text-sm text-green-700 dark:text-green-300">Steps</p>
                    </div>
                  </div>
                  <p className="text-xs text-green-600 dark:text-green-400 mt-2">Daily Average</p>
                </div>
                
                <div className="bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-900/20 dark:to-violet-900/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800 animate-scale-in" style={{ animationDelay: '300ms' }}>
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center animate-rotate-slow">
                      <Brain className="w-6 h-6 text-purple-500" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">85%</p>
                      <p className="text-sm text-purple-700 dark:text-purple-300">Score</p>
                    </div>
                  </div>
                  <p className="text-xs text-purple-600 dark:text-purple-400 mt-2">Wellness</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </SlideIn>

        {/* Recent Activity Feed */}
        <SlideIn delay={2400}>
          <Card className="card-modern border-2 border-teal-200 dark:border-teal-800">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-teal-500 animate-rotate-slow" />
                <span>Recent Activity</span>
              </CardTitle>
              <CardDescription>
                Latest health updates and activities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-4 p-3 bg-gradient-to-r from-teal-50 to-cyan-50 dark:from-teal-900/20 dark:to-cyan-900/20 rounded-lg border border-teal-200 dark:border-teal-700 animate-slide-in-left">
                  <div className="w-10 h-10 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center animate-bounce-in">
                    <Pill className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-teal-900 dark:text-teal-100">Medication taken</p>
                    <p className="text-sm text-teal-700 dark:text-teal-300">Vitamin D supplement - 2 hours ago</p>
                  </div>
                  <div className="w-2 h-2 bg-teal-500 rounded-full animate-pulse"></div>
                </div>
                
                <div className="flex items-center space-x-4 p-3 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-lg border border-indigo-200 dark:border-indigo-700 animate-slide-in-left" style={{ animationDelay: '100ms' }}>
                  <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900 rounded-full flex items-center justify-center animate-wiggle">
                    <MessageCircle className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-indigo-900 dark:text-indigo-100">AI Chat session</p>
                    <p className="text-sm text-indigo-700 dark:text-indigo-300">Discussed sleep quality improvements - 4 hours ago</p>
                  </div>
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></div>
                </div>
                
                <div className="flex items-center space-x-4 p-3 bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 rounded-lg border border-orange-200 dark:border-orange-700 animate-slide-in-left" style={{ animationDelay: '200ms' }}>
                  <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center animate-heartbeat">
                    <Activity className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-orange-900 dark:text-orange-100">Exercise logged</p>
                    <p className="text-sm text-orange-700 dark:text-orange-300">30-minute walk in the park - Yesterday</p>
                  </div>
                  <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        </SlideIn>
      </div>
    </div>
  );
}