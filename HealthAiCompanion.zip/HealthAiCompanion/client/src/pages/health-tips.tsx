import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { 
  Heart, 
  Droplets, 
  Activity, 
  Brain, 
  Shield, 
  Moon, 
  Utensils, 
  Award,
  Search,
  Filter,
  Clock,
  Star,
  CheckCircle,
  Plus,
  Target,
  TrendingUp,
  Sparkles,
  Crown,
  Trophy,
  Gift,
  Zap
} from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { FadeIn } from '@/components/animations/fade-in';
import { SlideIn } from '@/components/animations/slide-in';
import { ScaleIn } from '@/components/animations/scale-in';
import DailyHealthTip from '@/components/health-tips/daily-tip';
import { apiRequest } from '@/lib/queryClient';

interface HealthTip {
  id: number;
  title: string;
  content: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
  tags: string[];
  estimatedTime: number;
  isActive: boolean;
  createdAt: string;
}

interface UserHealthTipCompletion {
  id: number;
  userId: number;
  healthTipId: number;
  completedAt: string;
  pointsEarned: number;
}

const categoryIcons = {
  completed: { icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50 dark:bg-green-950/20' },
  incomplete: { icon: Clock, color: 'text-red-600', bg: 'bg-red-50 dark:bg-red-950/20' },
  hydration: { icon: Droplets, color: 'text-blue-500', bg: 'bg-blue-50 dark:bg-blue-950/20' },
  nutrition: { icon: Utensils, color: 'text-green-500', bg: 'bg-green-50 dark:bg-green-950/20' },
  exercise: { icon: Activity, color: 'text-red-500', bg: 'bg-red-50 dark:bg-red-950/20' },
  sleep: { icon: Moon, color: 'text-purple-500', bg: 'bg-purple-50 dark:bg-purple-950/20' },
  mental: { icon: Brain, color: 'text-indigo-500', bg: 'bg-indigo-50 dark:bg-indigo-950/20' },
  preventive: { icon: Shield, color: 'text-orange-500', bg: 'bg-orange-50 dark:bg-orange-950/20' },
  advanced: { icon: Star, color: 'text-yellow-500', bg: 'bg-yellow-50 dark:bg-yellow-950/20' },
  habits: { icon: Target, color: 'text-pink-500', bg: 'bg-pink-50 dark:bg-pink-950/20' },
  specialized: { icon: Award, color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-950/20' },
  wellness: { icon: Sparkles, color: 'text-cyan-500', bg: 'bg-cyan-50 dark:bg-cyan-950/20' },
  monitoring: { icon: TrendingUp, color: 'text-teal-500', bg: 'bg-teal-50 dark:bg-teal-950/20' },
  hygiene: { icon: Heart, color: 'text-rose-500', bg: 'bg-rose-50 dark:bg-rose-950/20' },
  recovery: { icon: Zap, color: 'text-violet-500', bg: 'bg-violet-50 dark:bg-violet-950/20' },
  safety: { icon: Shield, color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-950/20' },
  ergonomics: { icon: Target, color: 'text-stone-500', bg: 'bg-stone-50 dark:bg-stone-950/20' }
};

const difficultyColors = {
  easy: 'bg-green-100 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300',
  medium: 'bg-yellow-100 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-300',
  hard: 'bg-red-100 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300'
};

export default function HealthTipsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  // Fetch all health tips (for filtering and counting)
  const { data: allHealthTips = [], isLoading: loadingAllTips } = useQuery<HealthTip[]>({
    queryKey: ['/api/health-tips/all'],
    queryFn: async () => {
      const response = await fetch('/api/health-tips?limit=1000', {
        credentials: 'include'
      });
      if (!response.ok) {
        throw new Error('Failed to fetch health tips');
      }
      const result = await response.json();
      return result.tips || result; // Handle both new and old API formats
    }
  });

  // Fetch categories
  const { data: categories = [] } = useQuery<string[]>({
    queryKey: ['/api/health-tips/categories'],
    queryFn: async () => {
      const response = await fetch('/api/health-tips/categories', {
        credentials: 'include'
      });
      if (!response.ok) {
        return [];
      }
      return response.json();
    }
  });

  const healthTips = allHealthTips;

  // Fetch user's completed tips
  const { data: completedTips = [] } = useQuery<UserHealthTipCompletion[]>({
    queryKey: ['/api/health-tips/completed'],
    enabled: !!user,
  });

  // Fetch user's total points
  const { data: userPointsData } = useQuery<{ totalPoints: number }>({
    queryKey: ['/api/health-tips/user/points'],
    enabled: !!user,
  });

  

  // Reload health tips mutation
  const reloadTipsMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', '/api/health-tips/reload');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/health-tips'] });
      queryClient.invalidateQueries({ queryKey: ['/api/health-tips/completed'] });
      queryClient.invalidateQueries({ queryKey: ['/api/health-tips/user/points'] });
      toast({
        title: "Health Tips Reloaded",
        description: "All health tips have been refreshed successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to reload",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Complete health tip mutation
  const completeTipMutation = useMutation({
    mutationFn: async (tipId: number) => {
      await apiRequest('POST', `/api/health-tips/${tipId}/complete`);
    },
    onSuccess: (data, tipId) => {
      const tip = healthTips.find(t => t.id === tipId);
      queryClient.invalidateQueries({ queryKey: ['/api/health-tips/completed'] });
      queryClient.invalidateQueries({ queryKey: ['/api/health-tips/user/points'] });
      queryClient.invalidateQueries({ queryKey: ['/api/character'] });
      
      toast({
        title: "Tip Completed! 🎉",
        description: `You earned ${tip?.points || 0} points! Your character gained XP too!`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Oops!",
        description: error.message || "This tip was already completed or there was an error.",
        variant: "destructive",
      });
    },
  });

  // Get completed tip IDs for quick lookup
  const completedTipIds = new Set(completedTips.map(ct => ct.healthTipId));

  // Create enhanced categories with completion status
  const enhancedCategories = [
    { value: 'all', label: 'All Tips', count: healthTips.length },
    { value: 'completed', label: 'Completed', count: completedTips.length },
    { value: 'incomplete', label: 'Incomplete', count: healthTips.length - completedTips.length },
    ...categories.map(cat => ({
      value: cat,
      label: cat.charAt(0).toUpperCase() + cat.slice(1),
      count: healthTips.filter(tip => tip.category === cat).length
    }))
  ];

  // Filter tips based on search and category
  const filteredTips = healthTips.filter((tip: HealthTip) => {
    const matchesSearch = searchTerm === '' || 
      tip.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tip.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tip.tags?.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    let matchesCategory = true;
    if (selectedCategory === 'completed') {
      matchesCategory = completedTipIds.has(tip.id);
    } else if (selectedCategory === 'incomplete') {
      matchesCategory = !completedTipIds.has(tip.id);
    } else if (selectedCategory !== 'all') {
      matchesCategory = tip.category === selectedCategory;
    }
    
    return matchesSearch && matchesCategory;
  }).sort((a: HealthTip, b: HealthTip) => b.points - a.points); // Sort by points

  // Pagination
  const totalFilteredTips = filteredTips.length;
  const totalPages = Math.ceil(totalFilteredTips / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedTips = filteredTips.slice(startIndex, startIndex + itemsPerPage);

  // Reset page when category or search changes
  React.useEffect(() => {
    setCurrentPage(1);
  }, [selectedCategory, searchTerm]);

  const totalPoints = userPointsData?.totalPoints || 0;
  const completedCount = completedTips.length;
  const totalTipsCount = healthTips.length;
  const completionPercentage = totalTipsCount > 0 ? (completedCount / totalTipsCount) * 100 : 0;

  return (
    <div className="min-h-screen p-6 pb-20 md:pb-6 space-y-8">
      {/* Header Section */}
      <FadeIn delay={0}>
        <div className="text-center space-y-4 mb-8">
          <div className="flex items-center justify-center space-x-2">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center">
              <Heart className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Health Tips & Rewards
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Complete health tips to earn points and level up your character! Over 150+ expert-curated tips to improve your wellness journey.
          </p>
          
          <Button 
            onClick={() => reloadTipsMutation.mutate()}
            disabled={reloadTipsMutation.isPending}
            variant="outline"
            className="mt-4"
          >
            {reloadTipsMutation.isPending ? "Reloading..." : "Reload Health Tips"}
          </Button>
          
          
        </div>
      </FadeIn>

      {/* Daily Health Tip Feature */}
      <div className="mb-8">
        <FadeIn delay={100}>
          <DailyHealthTip />
        </FadeIn>
      </div>

      {/* Stats Cards */}
      {user && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <ScaleIn delay={200}>
            <Card className="card-modern text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Trophy className="w-6 h-6 text-primary" />
                </div>
                <div className="text-2xl font-bold text-primary">{totalPoints}</div>
                <div className="text-sm text-muted-foreground">Total Points</div>
              </CardContent>
            </Card>
          </ScaleIn>

          <ScaleIn delay={300}>
            <Card className="card-modern text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <div className="text-2xl font-bold text-green-600">{completedCount}</div>
                <div className="text-sm text-muted-foreground">Tips Completed</div>
              </CardContent>
            </Card>
          </ScaleIn>

          <ScaleIn delay={400}>
            <Card className="card-modern text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Target className="w-6 h-6 text-blue-600" />
                </div>
                <div className="text-2xl font-bold text-blue-600">{totalTipsCount}</div>
                <div className="text-sm text-muted-foreground">Total Available</div>
              </CardContent>
            </Card>
          </ScaleIn>

          <ScaleIn delay={500}>
            <Card className="card-modern text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Crown className="w-6 h-6 text-purple-600" />
                </div>
                <div className="text-2xl font-bold text-purple-600">{Math.round(completionPercentage)}%</div>
                <div className="text-sm text-muted-foreground">Completion Rate</div>
              </CardContent>
            </Card>
          </ScaleIn>
        </div>
      )}

      {/* Progress Bar */}
      {user && totalTipsCount > 0 && (
        <FadeIn delay={600}>
          <Card className="card-modern">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold">Overall Progress</h3>
                <Badge variant="secondary">
                  {completedCount}/{totalTipsCount}
                </Badge>
              </div>
              <Progress value={completionPercentage} className="h-3" />
              <div className="flex justify-between text-sm text-muted-foreground mt-2">
                <span>Keep going!</span>
                <span>{Math.round(completionPercentage)}% complete</span>
              </div>
            </CardContent>
          </Card>
        </FadeIn>
      )}

      {/* Category Bar */}
      <SlideIn delay={600} direction="up">
        <Card className="card-modern">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Heart className="w-5 h-5 mr-2" />
              Browse by Category
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              {enhancedCategories.map((cat) => {
                const IconComponent = categoryIcons[cat.value]?.icon || Heart;
                const isSelected = selectedCategory === cat.value;
                return (
                  <Button
                    key={cat.value}
                    variant={isSelected ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(cat.value)}
                    className="transition-all duration-300 hover:scale-105"
                  >
                    <IconComponent className="w-4 h-4 mr-2" />
                    {cat.label}
                    <Badge variant="secondary" className="ml-2">
                      {cat.count}
                    </Badge>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </SlideIn>

      {/* Search Bar */}
      <SlideIn delay={700} direction="up">
        <div className="max-w-md mx-auto">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
            <Input
              placeholder="Search health tips..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 text-lg"
            />
          </div>
        </div>
      </SlideIn>

      {/* Results Info */}
      <div className="text-center text-muted-foreground">
        Showing {paginatedTips.length} of {totalFilteredTips} tips
        {selectedCategory !== 'all' && (
          <span className="ml-2">in {enhancedCategories.find(c => c.value === selectedCategory)?.label}</span>
        )}
      </div>

      {/* Health Tips Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {paginatedTips.map((tip: HealthTip, index: number) => {
          const categoryInfo = categoryIcons[tip.category as keyof typeof categoryIcons] || categoryIcons.habits;
          const IconComponent = categoryInfo.icon;
          const isCompleted = completedTipIds.has(tip.id);

          return (
            <ScaleIn key={tip.id} delay={800 + index * 50}>
              <Card className={`card-modern h-full transition-all duration-300 ${
                isCompleted ? 'border-green-200 bg-green-50/50 dark:border-green-800 dark:bg-green-950/20' : 
                'hover:shadow-lg hover:scale-105'
              }`}>
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className={`w-12 h-12 ${categoryInfo.bg} rounded-xl flex items-center justify-center`}>
                      <IconComponent className={`w-6 h-6 ${categoryInfo.color}`} />
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      <Badge className={`text-xs ${difficultyColors[tip.difficulty]}`}>
                        {tip.difficulty}
                      </Badge>
                      {isCompleted && (
                        <Badge className="bg-green-100 text-green-700 border-green-200">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Completed
                        </Badge>
                      )}
                    </div>
                  </div>
                  <CardTitle className="text-lg leading-tight">{tip.title}</CardTitle>
                </CardHeader>

                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {tip.content}
                  </p>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{tip.estimatedTime} min</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Gift className="w-3 h-3" />
                      <span className="font-medium text-primary">{tip.points} points</span>
                    </div>
                  </div>

                  {tip.tags && tip.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {tip.tags.slice(0, 3).map((tag, tagIndex) => (
                        <Badge key={tagIndex} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  <Separator />

                  <div className="flex justify-center">
                    {user ? (
                      <Button
                        onClick={() => completeTipMutation.mutate(tip.id)}
                        disabled={isCompleted || completeTipMutation.isPending}
                        className={`w-full ${isCompleted 
                          ? 'bg-green-100 text-green-700 border-green-200 cursor-not-allowed' 
                          : 'bg-gradient-to-r from-primary to-accent text-white hover:shadow-lg'
                        }`}
                        variant={isCompleted ? 'outline' : 'default'}
                      >
                        {isCompleted ? (
                          <>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Completed
                          </>
                        ) : (
                          <>
                            <Plus className="w-4 h-4 mr-2" />
                            Complete (+{tip.points} pts)
                          </>
                        )}
                      </Button>
                    ) : (
                      <Alert>
                        <AlertDescription className="text-center">
                          Please log in to complete health tips and earn points!
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </CardContent>
              </Card>
            </ScaleIn>
          );
        })}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center space-x-4 mt-8">
          <Button
            variant="outline"
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          
          <div className="flex items-center space-x-2">
            {[...Array(Math.min(5, totalPages))].map((_, i) => {
              const pageNum = currentPage <= 3 ? i + 1 : 
                             currentPage >= totalPages - 2 ? totalPages - 4 + i :
                             currentPage - 2 + i;
              
              if (pageNum < 1 || pageNum > totalPages) return null;
              
              return (
                <Button
                  key={pageNum}
                  variant={currentPage === pageNum ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(pageNum)}
                  className="w-10 h-10"
                >
                  {pageNum}
                </Button>
              );
            })}
          </div>
          
          <Button
            variant="outline"
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={currentPage === totalPages}
          >
            Next
          </Button>
        </div>
      )}

      {/* Empty State */}
      {filteredTips.length === 0 && healthTips.length > 0 && (
        <FadeIn delay={800}>
          <Card className="card-modern">
            <CardContent className="p-12 text-center">
              <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Tips Found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your search criteria or filters to find more health tips.
              </p>
              <Button onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
              }}>
                Clear All Filters
              </Button>
            </CardContent>
          </Card>
        </FadeIn>
      )}

      {/* Loading State */}
      {loadingAllTips && (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="card-modern">
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-xl"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-full"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}