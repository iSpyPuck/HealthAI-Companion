import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  HelpCircle, 
  MessageCircle, 
  Book, 
  Video, 
  Mail, 
  Phone,
  Search,
  ChevronRight,
  ExternalLink,
  Star,
  ThumbsUp,
  Clock,
  Users,
  Shield,
  Zap,
  Heart,
  FileText,
  Send
} from "lucide-react";
import { FadeIn } from "@/components/animations/fade-in";
import { SlideIn } from "@/components/animations/slide-in";
import { ScaleIn } from "@/components/animations/scale-in";

export default function Help() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const { toast } = useToast();

  const submitTicketMutation = useMutation({
    mutationFn: async (ticketData: {subject: string, message: string}) => {
      const response = await fetch('/api/support-tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          subject: ticketData.subject,
          message: ticketData.message,
          category: 'general',
          priority: 'medium'
        }),
      });
      if (!response.ok) throw new Error('Failed to submit ticket');
      return response.json();
    },
    onSuccess: () => {
      setSubject("");
      setMessage("");
      toast({
        title: "Message sent!",
        description: "Your support ticket has been submitted successfully. We'll get back to you within 24 hours.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again or contact us directly at bradley.quinnm@gmail.com",
        variant: "destructive",
      });
    },
  });

  const categories = [
    { id: "all", name: "All Topics", icon: Book },
    { id: "getting-started", name: "Getting Started", icon: Zap },
    { id: "account", name: "Account & Security", icon: Shield },
    { id: "health", name: "Health Features", icon: Heart },
    { id: "privacy", name: "Privacy & Data", icon: FileText },
  ];

  const faqs = [
    {
      category: "getting-started",
      question: "How do I get started with Health Chat AI?",
      answer: "Getting started is easy! Simply sign up with your email, verify your account, and you'll be guided through a quick setup process. You can start by having your first AI conversation, uploading health records, or setting up medication reminders."
    },
    {
      category: "health",
      question: "Is the AI medical advice reliable?",
      answer: "Our AI provides general health information and insights, but it should never replace professional medical advice. Always consult with your healthcare provider for serious medical concerns. The AI is designed to help you better understand health topics and track your wellness journey."
    },
    {
      category: "privacy",
      question: "How is my health data protected?",
      answer: "We use military-grade encryption to protect your data. All health information is encrypted both in transit and at rest. We never sell your data to third parties, and you have complete control over who can access your information."
    },
    {
      category: "account",
      question: "How do I change my password?",
      answer: "You can change your password by going to Profile & Settings, then clicking on 'Security Settings'. We recommend using a strong, unique password and enabling two-factor authentication for extra security."
    },
    {
      category: "health",
      question: "Can I share my health data with my doctor?",
      answer: "Yes! You can generate and export comprehensive health reports that include your medication history, symptoms tracking, and conversation summaries. These reports can be shared with your healthcare provider to improve your care."
    },
    {
      category: "getting-started",
      question: "What types of files can I upload?",
      answer: "You can upload PDF documents, images (JPEG, PNG), and Word documents (.doc, .docx). We support medical records, lab results, prescription images, and other health-related documents up to 10MB per file."
    },
    {
      category: "privacy",
      question: "Can I delete my account and data?",
      answer: "Yes, you have complete control over your data. You can delete your account and all associated data at any time from the Profile & Settings page. This action is permanent and cannot be undone."
    },
    {
      category: "health",
      question: "How do medication reminders work?",
      answer: "Set up your medications with dosage and timing information. We'll send you browser notifications, email reminders, or SMS alerts (if enabled) when it's time to take your medication. You can also view your medication calendar and track adherence."
    }
  ];

  const quickLinks = [
    { title: "User Guide", description: "Complete guide to all features", icon: Book, href: "#" },
    { title: "Video Tutorials", description: "Step-by-step video guides", icon: Video, href: "#" },
    { title: "API Documentation", description: "For developers and integrations", icon: FileText, href: "#" },
    { title: "Community Forum", description: "Connect with other users", icon: Users, href: "#" },
  ];

  const filteredFaqs = faqs.filter(faq => {
    const matchesCategory = selectedCategory === "all" || faq.category === selectedCategory;
    const matchesSearch = searchQuery === "" || 
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <FadeIn delay={0}>
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 text-foreground">Help & Support</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Find answers to your questions and learn how to make the most of HealthAI Companion
          </p>
        </div>
      </FadeIn>
      {/* Search */}
      <SlideIn delay={200}>
        <Card className="card-modern mb-8">
          <CardContent className="p-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                placeholder="Search for help topics..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 text-lg"
              />
            </div>
          </CardContent>
        </Card>
      </SlideIn>
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {quickLinks.map((link, index) => (
          <ScaleIn key={link.title} delay={300 + index * 100}>
            <Card className="card-modern hover:shadow-lg transition-all duration-300 cursor-pointer group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <link.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold mb-2">{link.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{link.description}</p>
                <Button variant="ghost" size="sm" className="gap-2">
                  Learn More <ChevronRight className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>
          </ScaleIn>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Categories Sidebar */}
        <SlideIn delay={600}>
          <Card className="card-modern h-fit">
            <CardHeader>
              <CardTitle className="text-lg">Categories</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-1">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/50 transition-colors ${
                      selectedCategory === category.id ? 'bg-primary/10 text-primary border-r-2 border-primary' : ''
                    }`}
                  >
                    <category.icon className="w-5 h-5" />
                    <span className="font-medium">{category.name}</span>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </SlideIn>

        {/* FAQ Content */}
        <div className="lg:col-span-3 space-y-6">
          <SlideIn delay={700}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
                <CardDescription>
                  Find answers to the most common questions about Health Chat AI
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="space-y-4">
                  {filteredFaqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg px-4">
                      <AccordionTrigger className="hover:no-underline py-4">
                        <div className="flex items-center gap-3 text-left">
                          <HelpCircle className="w-5 h-5 text-primary flex-shrink-0" />
                          <span className="font-medium">{faq.question}</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pb-4">
                        <p className="text-muted-foreground leading-relaxed ml-8">
                          {faq.answer}
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>

                {filteredFaqs.length === 0 && (
                  <div className="text-center py-8">
                    <HelpCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      No results found. Try adjusting your search or category filter.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </SlideIn>

          {/* Contact Support */}
          <SlideIn delay={800}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-primary" />
                  Still Need Help?
                </CardTitle>
                <CardDescription>
                  Can't find what you're looking for? Contact our support team
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Mail className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-medium">Email Support</div>
                      <div className="text-sm text-muted-foreground">bradley.quinnm@gmail.com</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <MessageCircle className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <div className="font-medium">Live Chat</div>
                      <div className="text-sm text-muted-foreground">Available 24/7</div>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h4 className="font-medium mb-4">Send us a message</h4>
                  <div className="space-y-4">
                    <Input 
                      placeholder="Subject" 
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                    />
                    <Textarea 
                      placeholder="Describe your issue or question..." 
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                    />
                    <Button 
                      className="gap-2"
                      onClick={() => {
                        if (subject.trim() && message.trim()) {
                          submitTicketMutation.mutate({ subject: subject.trim(), message: message.trim() });
                        } else {
                          toast({
                            title: "Missing information",
                            description: "Please fill in both subject and message fields.",
                            variant: "destructive",
                          });
                        }
                      }}
                      disabled={submitTicketMutation.isPending}
                    >
                      <Send className="w-4 h-4" />
                      {submitTicketMutation.isPending ? 'Sending...' : 'Send Message'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </SlideIn>

          {/* Support Stats */}
          <SlideIn delay={900}>
            <Card className="card-modern bg-gradient-to-r from-primary/5 to-accent/5">
              <CardContent className="p-6">
                <div className="grid grid-cols-3 gap-6 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">24/7</div>
                    <div className="text-sm text-muted-foreground">Support Available</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-primary">&lt; 2h</div>
                    <div className="text-sm text-muted-foreground">Average Response</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-primary">98%</div>
                    <div className="text-sm text-muted-foreground">Satisfaction Rate</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </SlideIn>
        </div>
      </div>
    </div>
  );
}