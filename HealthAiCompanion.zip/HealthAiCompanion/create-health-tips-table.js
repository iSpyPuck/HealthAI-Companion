#!/usr/bin/env node
import { spawn } from 'child_process';

const child = spawn('npx', ['drizzle-kit', 'push', '--config=drizzle.config.ts'], {
  stdio: ['pipe', 'inherit', 'inherit']
});

// Send the table creation choice
child.stdin.write('+ health_tips\n');
child.stdin.end();

child.on('close', (code) => {
  console.log(`Database migration completed with exit code ${code}`);
  process.exit(code);
});